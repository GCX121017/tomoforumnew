import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // 注意：Netlify 部署时不要使用 output: "standalone"，由 @netlify/plugin-nextjs 处理
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**.supabase.co',
        pathname: '/storage/v1/object/public/**',
      },
    ],
  },
};

export default nextConfig;
