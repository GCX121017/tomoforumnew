import { supabase } from '@/lib/supabase'
import { getLevelFromPoints } from '@/lib/levels'

// Simple in-memory TTL cache (server-side only)
const CACHE_TTL = 60_000 // 60 seconds
const pointsCache = new Map<string, { points: number; level: number; ts: number }>()

/**
 * Recalculate user points from actual activity counts and update the User record.
 * Results are cached for 60 seconds to avoid excessive DB queries.
 */
export async function recalculateUserPoints(userId: string): Promise<{ points: number; level: number }> {
  // Check cache first
  const cached = pointsCache.get(userId)
  if (cached && Date.now() - cached.ts < CACHE_TTL) {
    return { points: cached.points, level: cached.level }
  }

  // Count posts by this user
  const { count: postCount } = await supabase
    .from('Post')
    .select('*', { count: 'exact', head: true })
    .eq('authorId', userId)

  // Get post IDs for this user
  const { data: userPosts } = await supabase
    .from('Post')
    .select('id')
    .eq('authorId', userId)

  const postIds = (userPosts || []).map((p) => p.id)

  let likeCount = 0
  let commentCount = 0
  let bookmarkCount = 0

  if (postIds.length > 0) {
    // Count likes received on user's posts
    const { count: lc } = await supabase
      .from('PostLike')
      .select('*', { count: 'exact', head: true })
      .in('postId', postIds)
    likeCount = lc || 0

    // Count comments on user's posts (from Comment table, not the user's own comments)
    const { count: cc } = await supabase
      .from('Comment')
      .select('*', { count: 'exact', head: true })
      .in('postId', postIds)
    commentCount = cc || 0

    // Count bookmarks on user's posts
    const { count: bc } = await supabase
      .from('PostBookmark')
      .select('*', { count: 'exact', head: true })
      .in('postId', postIds)
    bookmarkCount = bc || 0
  }

  const totalPosts = postCount || 0
  const newPoints = totalPosts * 10 + likeCount * 2 + commentCount * 3 + bookmarkCount * 5
  const { level } = getLevelFromPoints(newPoints)

  await supabase
    .from('User')
    .update({ points: newPoints, level })
    .eq('id', userId)

  // Store in cache
  pointsCache.set(userId, { points: newPoints, level, ts: Date.now() })

  // Prune cache if too large (keep under 100 entries)
  if (pointsCache.size > 100) {
    const entries = [...pointsCache.entries()].sort((a, b) => a[1].ts - b[1].ts)
    for (let i = 0; i < 20; i++) pointsCache.delete(entries[i][0])
  }

  return { points: newPoints, level }
}
