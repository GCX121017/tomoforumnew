// Base64URL encode/decode for non-ASCII usernames stored in Supabase
// - ASCII usernames: stored as-is in `username` field
// - Non-ASCII usernames (Chinese, etc.): Base64URL encoded in `username`, original text in `displayName`
// - Virtual email: `{encoded_username}@forum.local` (ensures UNIQUE constraint on email column)

// ─── Encode / Decode ───────────────────────────────────────────

export function base64UrlEncode(str: string): string {
  const encoded = Buffer.from(str, 'utf-8').toString('base64')
  return encoded.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}

export function base64UrlDecode(str: string): string {
  let padded = str.replace(/-/g, '+').replace(/_/g, '/')
  while (padded.length % 4 !== 0) padded += '='
  return Buffer.from(padded, 'base64').toString('utf-8')
}

// Check if a string contains non-ASCII characters (Chinese, special symbols, etc.)
export function hasNonASCII(str: string): boolean {
  return /[^\x00-\x7F]/.test(str)
}

/**
 * Encode a display username for database storage.
 * - ASCII-only → returned as-is
 * - Contains non-ASCII → Base64URL encoded
 */
export function encodeUsername(displayName: string): string {
  if (!hasNonASCII(displayName)) return displayName
  return base64UrlEncode(displayName)
}

/**
 * Generate a virtual email from the (possibly encoded) stored username.
 * Format: `{encoded_username}@forum.local`
 * This guarantees uniqueness per user for the email UNIQUE constraint.
 */
export function generateVirtualEmail(storedUsername: string): string {
  // Ensure the local part is Base64URL (safe for email local-part per RFC)
  const localPart = hasNonASCII(storedUsername) ? base64UrlEncode(storedUsername) : storedUsername
  return `${localPart}@forum.local`
}

// ─── Normalize (decode for display) ────────────────────────────

export interface NormalizedUser {
  id: string
  username: string      // always the displayable text
  displayName: string   // same as username after normalization
  email: string
  avatar: string
  avatarColor: string
  avatarType: string
  bio: string
  role: string
  level: number
  points: number
  createdAt: string
  updatedAt: string
}

/**
 * Normalize a single user object from Supabase.
 * Ensures `username` and `displayName` are always displayable text.
 */
export function normalizeUser(user: Record<string, any> | null | undefined): NormalizedUser | null {
  if (!user) return null

  const rawUsername = user.username || ''
  const displayName = user.displayName || ''

  // If displayName is already set (e.g. Chinese name), it's the authoritative display text
  if (displayName) {
    return {
      ...user,
      username: displayName,
      displayName,
    } as NormalizedUser
  }

  // Try to decode rawUsername as Base64URL (might be encoded non-ASCII text)
  try {
    const decoded = base64UrlDecode(rawUsername)
    if (decoded && hasNonASCII(decoded)) {
      return {
        ...user,
        username: decoded,
        displayName: decoded,
      } as NormalizedUser
    }
  } catch {
    // Not valid Base64URL, use as-is
  }

  // Default: ASCII username, displayName = username
  return {
    ...user,
    displayName: rawUsername,
  } as NormalizedUser
}

/**
 * Normalize an array of user objects from Supabase.
 */
export function normalizeUsers(users: Record<string, any>[]): NormalizedUser[] {
  return (users || []).map(normalizeUser)
}
