import { createClient, SupabaseClient } from '@supabase/supabase-js'

// Lazy singleton — only creates client on first actual use, not at import time.
// This prevents build-time crashes when env vars are absent (e.g. Netlify build).
let _supabase: SupabaseClient | null = null

export function getSupabase(): SupabaseClient {
  if (_supabase) return _supabase

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

  if (!url || !key) {
    throw new Error(
      'Missing NEXT_PUBLIC_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_ANON_KEY. ' +
      'Please set these environment variables.'
    )
  }

  _supabase = createClient(url, key)
  return _supabase
}

// Convenience alias (used by most API routes)
export const supabase = new Proxy({} as SupabaseClient, {
  get(_target, prop) {
    return (getSupabase() as unknown as Record<string | symbol, unknown>)[prop]
  },
})
