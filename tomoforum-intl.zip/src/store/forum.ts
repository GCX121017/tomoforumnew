import { create } from 'zustand'

export type Page = 
  | { name: 'home'; categoryId?: string; tag?: string }
  | { name: 'post'; postId: string }
  | { name: 'create' }
  | { name: 'edit'; postId: string }
  | { name: 'user'; userId: string }
  | { name: 'search'; query: string; categoryId?: string; authorId?: string }
  | { name: 'bookmarks'; userId: string }
  | { name: 'admin' }
  | { name: 'legal'; section: 'about' | 'terms' | 'contact' }
  | { name: 'messages'; partnerId?: string }

export interface ForumUser {
  id: string
  username: string
  avatar: string
  avatarColor: string
  avatarType: string
  bio: string
  role: string
  level: number
  points: number
  postCount?: number
  commentCount?: number
}

export interface Category {
  id: string
  name: string
  description: string
  icon: string
  postCount: number
}

export interface Tag {
  id: string
  name: string
}

export interface Author {
  id: string
  username: string
  avatar: string
  bio: string
  role: string
  level: number
  points: number
}

export interface Post {
  id: string
  title: string
  content: string
  categoryId: string
  authorId: string
  viewCount: number
  likeCount: number
  commentCount: number
  isPinned: boolean
  isLocked: boolean
  createdAt: string
  updatedAt: string
  author: Author
  category: Category
  tags: Tag[]
  liked?: boolean
  bookmarked?: boolean
}

export interface Comment {
  id: string
  content: string
  postId: string
  authorId: string
  parentId: string | null
  createdAt: string
  updatedAt: string
  author: Author
  replies: Comment[]
  likeCount?: number
  commentLiked?: boolean
}

export interface Notification {
  id: string
  type: string
  userId: string
  fromUserId: string
  postId: string | null
  commentId: string | null
  content: string
  isRead: boolean
  createdAt: string
  fromUser: { id: string; username: string; avatar: string }
}

export interface Friend {
  id: string
  friendshipId: string
  username: string
  avatar: string
  level: number
  points: number
  online: boolean
}

export interface FriendRequest {
  id: string
  fromUserId: string
  toUserId: string
  status: string
  message: string
  createdAt: string
  fromUser: {
    id: string
    username: string
    avatar: string
    level: number
    points: number
    bio: string
  }
}

export interface Conversation {
  partner: { id: string; username: string; avatar: string; level: number }
  lastMessage: { content: string; createdAt: string; isMine: boolean; isRead: boolean }
  unreadCount: number
}

export interface ChatMessage {
  id: string
  senderId: string
  receiverId: string
  content: string
  isRead: boolean
  isRecalled: boolean
  createdAt: string
  updatedAt: string
  sender: { id: string; username: string; avatar: string }
}

export type FeedType = 'all' | 'following'

interface ForumState {
  // Navigation
  currentPage: Page
  navigate: (page: Page) => void

  // Feed
  activeFeed: FeedType
  setActiveFeed: (feed: FeedType) => void

  // Current User
  currentUser: ForumUser | null
  setCurrentUser: (user: ForumUser | null) => void

  // Data
  posts: Post[]
  setPosts: (posts: Post[]) => void
  currentPost: Post | null
  setCurrentPost: (post: Post | null) => void
  comments: Comment[]
  setComments: (comments: Comment[]) => void
  categories: Category[]
  setCategories: (categories: Category[]) => void
  totalPosts: number
  setTotalPosts: (total: number) => void

  // Notifications
  notifications: Notification[]
  setNotifications: (notifications: Notification[]) => void
  unreadCount: number
  setUnreadCount: (count: number) => void

  // Friends UI State
  showFriendsPanel: boolean
  setShowFriendsPanel: (show: boolean) => void
  totalUnreadMessages: number
  setTotalUnreadMessages: (count: number) => void

  // UI State
  sidebarOpen: boolean
  setSidebarOpen: (open: boolean) => void
  sidebarCollapsed: boolean
  setSidebarCollapsed: (collapsed: boolean) => void
  showUserMenu: boolean
  setShowUserMenu: (show: boolean) => void
  createPostDialogOpen: boolean
  setCreatePostDialogOpen: (open: boolean) => void
  showLoginDialog: boolean
  setShowLoginDialog: (show: boolean) => void
  showNotifications: boolean
  setShowNotifications: (show: boolean) => void
}

export const useForumStore = create<ForumState>((set) => ({
  // Navigation
  currentPage: { name: 'home' },
  navigate: (page) => set({ currentPage: page }),

  // Feed
  activeFeed: 'all' as FeedType,
  setActiveFeed: (feed) => set({ activeFeed: feed }),

  // Current User
  currentUser: null,
  setCurrentUser: (user) => set({ currentUser: user }),

  // Data
  posts: [],
  setPosts: (posts) => set({ posts }),
  currentPost: null,
  setCurrentPost: (post) => set({ currentPost: post }),
  comments: [],
  setComments: (comments) => set({ comments }),
  categories: [],
  setCategories: (categories) => set({ categories }),
  totalPosts: 0,
  setTotalPosts: (total) => set({ totalPosts: total }),

  // Notifications
  notifications: [],
  setNotifications: (notifications) => set({ notifications }),
  unreadCount: 0,
  setUnreadCount: (count) => set({ unreadCount: count }),

  // Friends
  showFriendsPanel: false,
  setShowFriendsPanel: (show) => set({ showFriendsPanel: show }),
  totalUnreadMessages: 0,
  setTotalUnreadMessages: (count) => set({ totalUnreadMessages: count }),

  // UI State
  sidebarOpen: false,
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  sidebarCollapsed: false,
  setSidebarCollapsed: (collapsed) => set({ sidebarCollapsed: collapsed }),
  showUserMenu: false,
  setShowUserMenu: (show) => set({ showUserMenu: show }),
  createPostDialogOpen: false,
  setCreatePostDialogOpen: (open) => set({ createPostDialogOpen: open }),
  showLoginDialog: false,
  setShowLoginDialog: (show) => set({ showLoginDialog: show }),
  showNotifications: false,
  setShowNotifications: (show) => set({ showNotifications: show }),
}))
