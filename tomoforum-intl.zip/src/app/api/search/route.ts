import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'
import { normalizeUser } from '@/lib/normalizeUser'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const q = searchParams.get('q')?.trim()
    const categoryId = searchParams.get('categoryId')?.trim()
    const authorId = searchParams.get('authorId')?.trim()
    const sort = searchParams.get('sort')?.trim() || 'latest'

    if (!q) {
      return NextResponse.json(
        { error: 'Search query (q) is required' },
        { status: 400 }
      )
    }

    const page = Math.max(1, Number(searchParams.get('page')) || 1)
    const limit = Math.min(50, Math.max(1, Number(searchParams.get('limit')) || 20))

    // Build query with text search
    let query = supabase
      .from('Post')
      .select('*', { count: 'exact' })
      .or(`title.ilike.%${q}%,content.ilike.%${q}%`)

    if (categoryId) {
      query = query.eq('categoryId', categoryId)
    }

    if (authorId) {
      query = query.eq('authorId', authorId)
    }

    // Apply sorting
    if (sort === 'hot') {
      query = query.order('likeCount', { ascending: false }).order('createdAt', { ascending: false })
    } else {
      query = query.order('createdAt', { ascending: false })
    }

    const from = (page - 1) * limit
    const { data: rawPosts, count: total } = await query.range(from, from + limit - 1)

    if (!rawPosts || rawPosts.length === 0) {
      return NextResponse.json({
        posts: [],
        total: 0,
        page,
        limit,
        totalPages: 0,
        query: q,
      })
    }

    // Batch fetch authors and categories
    const authorIds = [...new Set(rawPosts.map((p: any) => p.authorId))]
    const categoryIds = [...new Set(rawPosts.map((p: any) => p.categoryId))]
    const postIds = rawPosts.map((p: any) => p.id)

    const [authorsRes, categoriesRes, postTagsRes] = await Promise.all([
      supabase.from('User').select('id, username, displayName, avatar, level, points').in('id', authorIds),
      supabase.from('Category').select('id, name, icon').in('id', categoryIds),
      supabase.from('PostTag').select('postId, tagId').in('postId', postIds),
    ])

    const authorMap = new Map((authorsRes.data || []).map((a: any) => [a.id, normalizeUser(a)]))
    const categoryMap = new Map((categoriesRes.data || []).map((c: any) => [c.id, c]))

    // Build tags map
    const tagsMap = new Map<string, any[]>()
    if (postTagsRes.data && postTagsRes.data.length > 0) {
      const tagIds = [...new Set(postTagsRes.data.map((pt: any) => pt.tagId))]
      const { data: tags } = await supabase.from('Tag').select('id, name').in('id', tagIds)
      const tagMap = new Map((tags || []).map((t: any) => [t.id, t]))

      for (const pt of postTagsRes.data) {
        const tag = tagMap.get(pt.tagId)
        if (tag) {
          const existing = tagsMap.get(pt.postId) || []
          existing.push(tag)
          tagsMap.set(pt.postId, existing)
        }
      }
    }

    const formattedPosts = rawPosts.map((post: any) => ({
      ...post,
      author: authorMap.get(post.authorId) || null,
      category: categoryMap.get(post.categoryId) || null,
      tags: tagsMap.get(post.id) || [],
    }))

    return NextResponse.json({
      posts: formattedPosts,
      total: total || 0,
      page,
      limit,
      totalPages: Math.ceil((total || 0) / limit),
      query: q,
    })
  } catch (error) {
    console.error('Error searching posts:', error)
    return NextResponse.json(
      { error: 'Failed to search posts' },
      { status: 500 }
    )
  }
}
