import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'
import { normalizeUser } from '@/lib/normalizeUser'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const userId = searchParams.get('userId')
    const unreadOnly = searchParams.get('unread') === 'true'

    if (!userId) {
      return NextResponse.json(
        { error: 'userId is required' },
        { status: 400 }
      )
    }

    // If unreadOnly, return just the count
    if (unreadOnly) {
      const { count } = await supabase
        .from('Notification')
        .select('*', { count: 'exact', head: true })
        .eq('userId', userId)
        .eq('isRead', false)
      return NextResponse.json({ count: count || 0 })
    }

    // Otherwise return the full list
    const { data: notifications } = await supabase
      .from('Notification')
      .select('*')
      .eq('userId', userId)
      .order('createdAt', { ascending: false })
      .limit(50)

    if (!notifications || notifications.length === 0) {
      return NextResponse.json([])
    }

    // Batch fetch fromUser profiles
    const fromUserIds = [...new Set(notifications.map((n: any) => n.fromUserId).filter(Boolean))]
    const { data: fromUsers } = await supabase
      .from('User')
      .select('id, username, avatar, displayName')
      .in('id', fromUserIds)
    const userMap = new Map((fromUsers || []).map((u: any) => [u.id, normalizeUser(u)]))

    const result = notifications.map((n: any) => ({
      ...n,
      fromUser: n.fromUserId ? userMap.get(n.fromUserId) || null : null,
    }))

    return NextResponse.json(result)
  } catch (error) {
    console.error('Error fetching notifications:', error)
    return NextResponse.json(
      { error: 'Failed to fetch notifications' },
      { status: 500 }
    )
  }
}
