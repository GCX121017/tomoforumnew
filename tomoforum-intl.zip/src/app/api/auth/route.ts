import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'
import { hashPassword, verifyPassword } from '@/lib/password'
import { normalizeUser, encodeUsername, generateVirtualEmail, hasNonASCII } from '@/lib/normalizeUser'
import { recalculateUserPoints } from '@/lib/recalcPoints'
import { randomUUID } from 'crypto'

const COOKIE_NAME = 'forum_user_id'
const COOKIE_MAX_AGE = 365 * 24 * 60 * 60 // 1 year

function setCookie(res: NextResponse, userId: string) {
  res.cookies.set(COOKIE_NAME, userId, {
    path: '/',
    maxAge: COOKIE_MAX_AGE,
    httpOnly: false, // allow frontend to read for hydration
    sameSite: 'lax',
    secure: false, // sandbox uses http
  })
}

function clearCookie(res: NextResponse) {
  res.cookies.set(COOKIE_NAME, '', {
    path: '/',
    maxAge: 0,
  })
}

// Helper to get user counts
async function getUserCounts(userId: string) {
  const [postsRes, commentsRes, followersRes, followingRes] = await Promise.all([
    supabase.from('Post').select('id', { count: 'exact', head: true }).eq('authorId', userId),
    supabase.from('Comment').select('id', { count: 'exact', head: true }).eq('authorId', userId),
    supabase.from('Follow').select('id', { count: 'exact', head: true }).eq('followingId', userId),
    supabase.from('Follow').select('id', { count: 'exact', head: true }).eq('followerId', userId),
  ])
  return {
    postCount: postsRes.count || 0,
    commentCount: commentsRes.count || 0,
    followersCount: followersRes.count || 0,
    followingCount: followingRes.count || 0,
  }
}

export async function GET(request: NextRequest) {
  try {
    const userId = request.cookies.get(COOKIE_NAME)?.value
    if (!userId) {
      return NextResponse.json({ user: null })
    }

    const { data: user } = await supabase
      .from('User')
      .select('*')
      .eq('id', userId)
      .single()

    if (!user) {
      const res = NextResponse.json({ user: null })
      clearCookie(res)
      return res
    }

    // Recalculate points if not official
    if (user.role !== 'official') {
      const { points: newPoints, level: newLevel } = await recalculateUserPoints(user.id)
      if (user.points !== newPoints || user.level !== newLevel) {
        user.points = newPoints
        user.level = newLevel
      }
    }

    const counts = await getUserCounts(user.id)
    const normalized = normalizeUser(user)

    return NextResponse.json({
      user: {
        id: normalized.id,
        username: normalized.username,
        displayName: normalized.displayName,
        avatar: normalized.avatar,
        avatarColor: normalized.avatarColor,
        avatarType: normalized.avatarType,
        bio: normalized.bio,
        role: normalized.role,
        level: normalized.level,
        points: normalized.points,
        postCount: counts.postCount,
        commentCount: counts.commentCount,
      },
    })
  } catch (error) {
    console.error('Error fetching auth user:', error)
    return NextResponse.json({ user: null })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { action, username, password, avatar, avatarColor, avatarType, bio } = body

    if (action === 'login') {
      if (!username?.trim() || !password) {
        return NextResponse.json({ error: 'Username and password are required' }, { status: 400 })
      }

      const trimmed = username.trim()
      // Encode username for DB lookup (non-ASCII → Base64URL)
      const dbUsername = encodeUsername(trimmed)

      const { data: user } = await supabase
        .from('User')
        .select('*')
        .eq('username', dbUsername)
        .single()

      if (!user) {
        return NextResponse.json({ error: 'User not found', code: 'NOT_FOUND' }, { status: 404 })
      }

      // Verify password
      if (!user.password) {
        // Legacy user without password — allow login and set password
        const hashedPw = await hashPassword(password)
        await supabase.from('User').update({ password: hashedPw }).eq('id', user.id)
      } else {
        const valid = await verifyPassword(password, user.password)
        if (!valid) {
          return NextResponse.json({ error: 'Wrong password', code: 'WRONG_PASSWORD' }, { status: 401 })
        }
      }

      const counts = await getUserCounts(user.id)
      const normalized = normalizeUser(user)

      const res = NextResponse.json({
        user: {
          id: normalized.id,
          username: normalized.username,
          displayName: normalized.displayName,
          avatar: normalized.avatar,
          avatarColor: normalized.avatarColor,
          avatarType: normalized.avatarType,
          bio: normalized.bio,
          role: normalized.role,
          level: normalized.level,
          points: normalized.points,
          postCount: counts.postCount,
          commentCount: counts.commentCount,
        },
      })
      setCookie(res, user.id)
      return res
    }

    if (action === 'register') {
      if (!username?.trim()) {
        return NextResponse.json({ error: 'Username is required' }, { status: 400 })
      }
      if (!password) {
        return NextResponse.json({ error: 'Password is required' }, { status: 400 })
      }
      if (password.length < 6) {
        return NextResponse.json({ error: 'Password must be at least 6 characters' }, { status: 400 })
      }

      const displayName = username.trim()
      // Encode username for DB storage (non-ASCII → Base64URL)
      const dbUsername = encodeUsername(displayName)
      // Generate unique virtual email to avoid UNIQUE constraint violation
      const virtualEmail = generateVirtualEmail(dbUsername)

      // Check existing user by encoded username
      const { data: existing } = await supabase
        .from('User')
        .select('id')
        .eq('username', dbUsername)
        .single()

      if (existing) {
        return NextResponse.json({ error: 'Username already exists, please log in directly', code: 'ALREADY_EXISTS' }, { status: 409 })
      }

      // Hash password
      const hashedPw = await hashPassword(password)

      // Create new user
      const { data: user } = await supabase
        .from('User')
        .insert({
          id: randomUUID(),
          username: dbUsername,
          displayName: displayName,
          email: virtualEmail,
          avatar: avatar || '',
          avatarColor: avatarColor || '',
          avatarType: avatarType || 'preset',
          bio: bio || '',
          role: 'user',
          level: 0,
          points: 0,
          password: hashedPw,
        })
        .select()
        .single()

      if (!user) {
        return NextResponse.json({ error: 'Registration failed, please try again' }, { status: 500 })
      }

      const normalized = normalizeUser(user)

      const res = NextResponse.json({
        user: {
          id: normalized.id,
          username: normalized.username,
          displayName: normalized.displayName,
          avatar: normalized.avatar,
          avatarColor: normalized.avatarColor,
          avatarType: normalized.avatarType,
          bio: normalized.bio,
          role: normalized.role,
          level: normalized.level,
          points: normalized.points,
          postCount: 0,
          commentCount: 0,
        },
      })

      setCookie(res, user.id)
      return res
    }

    // Check if user exists (for login dialog step 1)
    if (action === 'checkUser') {
      if (!username?.trim()) {
        return NextResponse.json({ error: 'Username is required' }, { status: 400 })
      }
      const trimmed = username.trim()
      // Encode username for DB lookup
      const dbUsername = encodeUsername(trimmed)

      const { data: user } = await supabase
        .from('User')
        .select('id, username, avatar, displayName')
        .eq('username', dbUsername)
        .single()

      if (user) {
        const normalized = normalizeUser(user)
        return NextResponse.json({
          exists: true,
          avatar: normalized.avatar,
          username: normalized.username,
        })
      }
      return NextResponse.json({ exists: false })
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 })
  } catch (error) {
    console.error('Error in auth POST:', error)
    return NextResponse.json({ error: 'Auth failed' }, { status: 500 })
  }
}

export async function DELETE() {
  const res = NextResponse.json({ success: true })
  clearCookie(res)
  return res
}
