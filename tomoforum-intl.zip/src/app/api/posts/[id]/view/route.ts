import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const { userId } = await request.json()

    if (!userId) {
      return NextResponse.json(
        { error: 'userId is required' },
        { status: 400 }
      )
    }

    // Check if user already viewed this post (unique view tracking)
    const { data: existingView } = await supabase
      .from('PostView')
      .select('id')
      .eq('postId', id)
      .eq('userId', userId)
      .maybeSingle()

    if (existingView) {
      // Already viewed, return current count without incrementing
      const { data: post } = await supabase
        .from('Post')
        .select('viewCount')
        .eq('id', id)
        .single()
      return NextResponse.json({
        viewCount: post?.viewCount || 0,
        alreadyViewed: true,
      })
    }

    // Create view record
    await supabase.from('PostView').insert({ postId: id, userId })

    // Increment view count
    const { data: post } = await supabase
      .from('Post')
      .select('viewCount')
      .eq('id', id)
      .single()

    const newViewCount = (post?.viewCount || 0) + 1
    await supabase
      .from('Post')
      .update({ viewCount: newViewCount })
      .eq('id', id)

    return NextResponse.json({
      viewCount: newViewCount,
      alreadyViewed: false,
    })
  } catch (error) {
    console.error('Error recording view:', error)
    return NextResponse.json(
      { error: 'Failed to record view' },
      { status: 500 }
    )
  }
}
