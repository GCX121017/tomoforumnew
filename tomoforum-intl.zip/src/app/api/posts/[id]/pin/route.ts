import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: postId } = await params
    const body = await request.json()
    const { userId } = body

    if (!userId) {
      return NextResponse.json(
        { error: 'userId is required' },
        { status: 400 }
      )
    }

    // Verify post exists
    const { data: post } = await supabase
      .from('Post')
      .select('*')
      .eq('id', postId)
      .single()
    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      )
    }

    // Verify user is official/admin — only admins can pin/unpin
    const { data: user } = await supabase
      .from('User')
      .select('role')
      .eq('id', userId)
      .single()

    if (!user || user.role !== 'official') {
      return NextResponse.json(
        { error: 'Only admins can pin posts' },
        { status: 403 }
      )
    }

    // Toggle isPinned
    const newPinnedState = !post.isPinned
    await supabase
      .from('Post')
      .update({ isPinned: newPinnedState })
      .eq('id', postId)

    return NextResponse.json({
      pinned: newPinnedState,
      message: newPinnedState ? 'Post pinned' : 'Post unpinned',
    })
  } catch (error) {
    console.error('Error toggling pin:', error)
    return NextResponse.json(
      { error: 'Failed to toggle pin' },
      { status: 500 }
    )
  }
}
