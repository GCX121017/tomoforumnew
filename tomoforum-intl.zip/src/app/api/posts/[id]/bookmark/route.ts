import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'
import { recalculateUserPoints } from '@/lib/recalcPoints'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: postId } = await params
    const body = await request.json()
    const { userId } = body

    if (!userId) {
      return NextResponse.json(
        { error: 'userId is required' },
        { status: 400 }
      )
    }

    // Verify post exists
    const { data: post } = await supabase
      .from('Post')
      .select('*')
      .eq('id', postId)
      .single()
    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      )
    }

    // Fetch author role
    const { data: author } = await supabase
      .from('User')
      .select('id, role')
      .eq('id', post.authorId)
      .single()

    // Check if bookmark already exists
    const { data: existingBookmark } = await supabase
      .from('PostBookmark')
      .select('id')
      .eq('postId', postId)
      .eq('userId', userId)
      .maybeSingle()

    if (existingBookmark) {
      // Remove bookmark
      await supabase.from('PostBookmark').delete().eq('id', existingBookmark.id)

      if (post.authorId !== userId && author?.role !== 'official') {
        await recalculateUserPoints(post.authorId)
      }

      return NextResponse.json({ bookmarked: false })
    } else {
      // Add bookmark
      await supabase.from('PostBookmark').insert({ postId, userId })

      if (post.authorId !== userId && author?.role !== 'official') {
        await recalculateUserPoints(post.authorId)
      }

      return NextResponse.json({ bookmarked: true })
    }
  } catch (error) {
    console.error('Error toggling bookmark:', error)
    return NextResponse.json(
      { error: 'Failed to toggle bookmark' },
      { status: 500 }
    )
  }
}
