import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'
import { normalizeUser } from '@/lib/normalizeUser'
import { recalculateUserPoints } from '@/lib/recalcPoints'
import { getLevelFromPoints } from '@/lib/levels'
import { encodeUsername } from '@/lib/normalizeUser'

// Helper: batch fetch authors and categories for posts
async function enrichPosts(rawPosts: any[], includeTags: boolean = true) {
  if (!rawPosts || rawPosts.length === 0) return []

  const authorIds = [...new Set(rawPosts.map((p: any) => p.authorId))]
  const categoryIds = [...new Set(rawPosts.map((p: any) => p.categoryId))]

  const [authorsRes, categoriesRes] = await Promise.all([
    supabase.from('User').select('id, username, avatar, level, points, role, displayName').in('id', authorIds),
    supabase.from('Category').select('id, name, icon').in('id', categoryIds),
  ])

  const authorMap = new Map((authorsRes.data || []).map((a: any) => [a.id, normalizeUser(a)]))
  const categoryMap = new Map((categoriesRes.data || []).map((c: any) => [c.id, c]))

  // Fetch tags for posts if needed
  let tagsMap: Map<string, any[]> = new Map()
  if (includeTags) {
    const postIds = rawPosts.map((p: any) => p.id)
    const { data: postTags } = await supabase
      .from('PostTag')
      .select('postId, tagId')
      .in('postId', postIds)

    if (postTags && postTags.length > 0) {
      const tagIds = [...new Set(postTags.map((pt: any) => pt.tagId))]
      const { data: tags } = await supabase.from('Tag').select('id, name').in('id', tagIds)
      const tagMap = new Map((tags || []).map((t: any) => [t.id, t]))

      for (const pt of postTags) {
        const tag = tagMap.get(pt.tagId)
        if (tag) {
          const existing = tagsMap.get(pt.postId) || []
          existing.push(tag)
          tagsMap.set(pt.postId, existing)
        }
      }
    }
  }

  // Fetch like/comment counts for each post
  const postIds = rawPosts.map((p: any) => p.id)
  let likeCountsMap: Map<string, number> = new Map()
  let commentCountsMap: Map<string, number> = new Map()

  if (postIds.length > 0) {
    const [likeCounts, commentCounts] = await Promise.all([
      supabase.from('PostLike').select('postId').in('postId', postIds),
      supabase.from('Comment').select('postId').in('postId', postIds),
    ])

    for (const lc of (likeCounts.data || [])) {
      likeCountsMap.set(lc.postId, (likeCountsMap.get(lc.postId) || 0) + 1)
    }
    for (const cc of (commentCounts.data || [])) {
      commentCountsMap.set(cc.postId, (commentCountsMap.get(cc.postId) || 0) + 1)
    }
  }

  return rawPosts.map((post: any) => ({
    id: post.id,
    title: post.title,
    content: post.content,
    categoryId: post.categoryId,
    category: categoryMap.get(post.categoryId) || null,
    authorId: post.authorId,
    author: authorMap.get(post.authorId) || null,
    viewCount: post.viewCount,
    likeCount: post.likeCount,
    commentCount: post.commentCount,
    isPinned: post.isPinned,
    isLocked: post.isLocked,
    createdAt: post.createdAt,
    updatedAt: post.updatedAt,
    _count: {
      comments: commentCountsMap.get(post.id) || 0,
      likes: likeCountsMap.get(post.id) || 0,
    },
    tags: tagsMap.get(post.id) || [],
  }))
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const page = Math.max(1, Number(searchParams.get('page')) || 1)
    const limit = Math.min(50, Math.max(1, Number(searchParams.get('limit')) || 20))
    const categoryId = searchParams.get('categoryId')
    const sort = searchParams.get('sort') || 'random'
    const search = searchParams.get('search')?.trim()
    const tag = searchParams.get('tag')?.trim()

    const following = searchParams.get('following') === 'true'
    const isBookmarked = searchParams.get('bookmarked') === 'true'
    const userId = searchParams.get('userId')
    const authorId = searchParams.get('authorId')
    const minLevel = searchParams.get('minLevel') ? Number(searchParams.get('minLevel')) : undefined
    const filterType = searchParams.get('filterType')

    // If requesting bookmarked posts, require userId
    if (isBookmarked && !userId) {
      return NextResponse.json(
        { error: 'userId is required when bookmarked=true' },
        { status: 400 }
      )
    }

    let query = supabase.from('Post').select('*', { count: 'exact' })

    // Following feed: filter posts by followed users
    if (following && userId) {
      const { data: follows } = await supabase
        .from('Follow')
        .select('followingId')
        .eq('followerId', userId)

      if (!follows || follows.length === 0) {
        return NextResponse.json({
          posts: [],
          total: 0,
          page,
          limit,
          totalPages: 0,
        })
      }
      query = query.in('authorId', follows.map((f) => f.followingId))
    }

    // Filter by specific author
    if (authorId) {
      query = query.eq('authorId', authorId)
    }

    // Filter by user level type
    if (filterType === 'highLevel' || filterType === 'official' || (minLevel !== undefined && !isNaN(minLevel))) {
      // Need to query users first, then filter by authorId
      let userQuery = supabase.from('User').select('id')

      if (filterType === 'official') {
        userQuery = userQuery.eq('role', 'official')
      } else if (filterType === 'highLevel') {
        userQuery = userQuery.gte('level', 2)
      } else if (minLevel !== undefined && !isNaN(minLevel)) {
        userQuery = userQuery.gte('level', minLevel)
      }

      const { data: filteredUsers } = await userQuery
      if (!filteredUsers || filteredUsers.length === 0) {
        return NextResponse.json({
          posts: [],
          total: 0,
          page,
          limit,
          totalPages: 0,
        })
      }
      const userIds = filteredUsers.map((u) => u.id)
      // Combine with any existing authorId filter
      if (authorId) {
        if (!userIds.includes(authorId)) {
          return NextResponse.json({
            posts: [],
            total: 0,
            page,
            limit,
            totalPages: 0,
          })
        }
      } else {
        query = query.in('authorId', userIds)
      }
    }

    // Bookmarked posts: filter by PostBookmark table, sorted by bookmark time
    if (isBookmarked && userId) {
      const from = (page - 1) * limit
      const [bookmarksRes, totalRes] = await Promise.all([
        supabase.from('PostBookmark').select('postId, createdAt').eq('userId', userId).order('createdAt', { ascending: false }).range(from, from + limit - 1),
        supabase.from('PostBookmark').select('id', { count: 'exact', head: true }).eq('userId', userId),
      ])

      const bookmarkEntries = bookmarksRes.data || []
      const total = totalRes.count || 0

      if (bookmarkEntries.length === 0) {
        return NextResponse.json({
          posts: [],
          total: 0,
          page,
          limit,
          totalPages: 0,
        })
      }

      const paginatedPostIds = bookmarkEntries.map((b) => b.postId)
      const orderMap = new Map(paginatedPostIds.map((id, i) => [id, i]))

      const { data: rawPosts } = await supabase
        .from('Post')
        .select('*')
        .in('id', paginatedPostIds)

      const posts = await enrichPosts(rawPosts || [])
      const sortedPosts = posts.sort((a, b) => (orderMap.get(a.id) ?? 0) - (orderMap.get(b.id) ?? 0))
        .map((p) => ({ ...p, bookmarked: true }))

      return NextResponse.json({
        posts: sortedPosts,
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      })
    }

    if (categoryId) {
      query = query.eq('categoryId', categoryId)
    }

    if (search) {
      // Supabase uses .or() for OR conditions
      query = query.or(`title.ilike.%${search}%,content.ilike.%${search}%`)
    }

    // Tag filter: first find post IDs with the tag
    if (tag) {
      const { data: tagEntry } = await supabase.from('Tag').select('id').eq('name', tag).single()
      if (tagEntry) {
        const { data: postTags } = await supabase.from('PostTag').select('postId').eq('tagId', tagEntry.id)
        if (postTags && postTags.length > 0) {
          query = query.in('id', postTags.map((pt) => pt.postId))
        } else {
          return NextResponse.json({
            posts: [],
            total: 0,
            page,
            limit,
            totalPages: 0,
          })
        }
      } else {
        return NextResponse.json({
          posts: [],
          total: 0,
          page,
          limit,
          totalPages: 0,
        })
      }
    }

    // Apply sorting
    switch (sort) {
      case 'hot':
        query = query.order('isPinned', { ascending: false }).order('likeCount', { ascending: false }).order('commentCount', { ascending: false })
        break
      case 'pinned':
        query = query.order('isPinned', { ascending: false }).order('createdAt', { ascending: false })
        break
      case 'commented':
        query = query.order('isPinned', { ascending: false }).order('commentCount', { ascending: false }).order('createdAt', { ascending: false })
        break
      case 'viewed':
        query = query.order('isPinned', { ascending: false }).order('viewCount', { ascending: false }).order('createdAt', { ascending: false })
        break
      case 'oldest':
        query = query.order('isPinned', { ascending: false }).order('createdAt', { ascending: true })
        break
      case 'latest':
        query = query.order('isPinned', { ascending: false }).order('createdAt', { ascending: false })
        break
      case 'random':
      default:
        query = query.order('isPinned', { ascending: false }).order('createdAt', { ascending: false })
        break
    }

    // For random sort, fetch all posts and shuffle (pagination is client-side only for random)
    if (sort === 'random') {
      // Fetch all non-paginated posts, pinned first
      const { data: rawPosts, count: total } = await query.range(0, 999)

      let posts = await enrichPosts(rawPosts || [])

      // Shuffle: pinned posts stay on top, non-pinned are shuffled
      const pinnedPosts = posts.filter((p) => p.isPinned)
      const nonPinnedPosts = posts.filter((p) => !p.isPinned)
      for (let i = nonPinnedPosts.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [nonPinnedPosts[i], nonPinnedPosts[j]] = [nonPinnedPosts[j], nonPinnedPosts[i]]
      }
      posts = [...pinnedPosts, ...nonPinnedPosts]
      posts = posts.slice((page - 1) * limit, page * limit)

      return NextResponse.json({
        posts,
        total: total || 0,
        page,
        limit,
        totalPages: Math.ceil((total || 0) / limit),
      })
    }

    // Normal sort: standard pagination
    const from = (page - 1) * limit
    const { data: rawPosts, count: total } = await query.range(from, from + limit - 1)

    let posts = await enrichPosts(rawPosts || [])

    return NextResponse.json({
      posts,
      total: total || 0,
      page,
      limit,
      totalPages: Math.ceil((total || 0) / limit),
    })
  } catch (error) {
    console.error('Error fetching posts:', error)
    return NextResponse.json(
      { error: 'Failed to fetch posts' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { title, content, categoryId, authorId, tags } = body

    if (!title || !categoryId || !authorId) {
      return NextResponse.json(
        { error: 'title, categoryId, and authorId are required' },
        { status: 400 }
      )
    }

    // Verify author exists
    const { data: author } = await supabase
      .from('User')
      .select('id, username, level, points, role')
      .eq('id', authorId)
      .single()
    if (!author) {
      return NextResponse.json(
        { error: 'Author not found' },
        { status: 404 }
      )
    }

    // Verify category exists
    const { data: category } = await supabase
      .from('Category')
      .select('*')
      .eq('id', categoryId)
      .single()
    if (!category) {
      return NextResponse.json(
        { error: 'Category not found' },
        { status: 404 }
      )
    }

    // Process tags if provided
    const tagConnections: string[] = []
    if (Array.isArray(tags) && tags.length > 0) {
      for (const tagName of tags) {
        // Upsert tag
        const { data: existingTag } = await supabase.from('Tag').select('id').eq('name', tagName).single()
        if (existingTag) {
          tagConnections.push(existingTag.id)
        } else {
          const { data: newTag } = await supabase.from('Tag').insert({ name: tagName }).select('id').single()
          if (newTag) tagConnections.push(newTag.id)
        }
      }
    }

    // Create post
    const { data: newPost } = await supabase
      .from('Post')
      .insert({
        title,
        content: content || '',
        categoryId,
        authorId,
      })
      .select()
      .single()

    if (!newPost) {
      return NextResponse.json({ error: 'Failed to create post' }, { status: 500 })
    }

    // Create PostTag connections
    if (tagConnections.length > 0) {
      await supabase.from('PostTag').insert(
        tagConnections.map((tagId) => ({ postId: newPost.id, tagId }))
      )
    }

    // Increment category postCount (read-then-write since Supabase REST doesn't have atomic increment)
    const { data: cat } = await supabase
      .from('Category')
      .select('postCount')
      .eq('id', categoryId)
      .single()
    if (cat) {
      await supabase.from('Category').update({ postCount: (cat.postCount || 0) + 1 }).eq('id', categoryId)
    }

    // Recalculate author points
    if (author.role !== 'official') {
      await recalculateUserPoints(authorId)
    }

    // Parse @mentions in post content and create mention notifications
    try {
      const mentionPattern = /@([\u4e00-\u9fff\w]{2,20})/g
      let match: RegExpExecArray | null
      const mentionedUserIds = new Set<string>()
      while ((match = mentionPattern.exec(content || '')) !== null) {
        const mentionedName = match[1]
        try {
          const encodedName = encodeUsername(mentionedName)
          const { data: mentionedUser } = await supabase
            .from('User')
            .select('id')
            .eq('username', encodedName)
            .neq('id', authorId)
            .single()
          if (mentionedUser) {
            // Verify they are friends
            const { data: friendship } = await supabase
              .from('FriendRequest')
              .select('id')
              .eq('status', 'accepted')
              .or(`and(fromUserId.eq.${authorId},toUserId.eq.${mentionedUser.id}),and(fromUserId.eq.${mentionedUser.id},toUserId.eq.${authorId})`)
              .limit(1)
            if (friendship && friendship.length > 0) {
              mentionedUserIds.add(mentionedUser.id)
            }
          }
        } catch { /* skip */ }
      }
      for (const mentionUserId of mentionedUserIds) {
        await supabase.from('Notification').insert({
          type: 'mention',
          userId: mentionUserId,
          fromUserId: authorId,
          postId: newPost.id,
          content: `mentioned you in "${title}"`,
        })
      }
    } catch { /* Notification creation failure should not affect the post */ }

    // Fetch enriched post data
    const posts = await enrichPosts([newPost], true)

    return NextResponse.json(
      posts[0],
      { status: 201 }
    )
  } catch (error) {
    console.error('Error creating post:', error)
    return NextResponse.json(
      { error: 'Failed to create post' },
      { status: 500 }
    )
  }
}
