import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'
import { normalizeUser, encodeUsername } from '@/lib/normalizeUser'

// GET /api/friends?userId=xxx — Get friends list
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'userId is required' },
        { status: 400 }
      )
    }

    // Get accepted friend requests where user is either from or to
    const { data: fromRequests } = await supabase
      .from('FriendRequest')
      .select('*')
      .eq('fromUserId', userId)
      .eq('status', 'accepted')

    const { data: toRequests } = await supabase
      .from('FriendRequest')
      .select('*')
      .eq('toUserId', userId)
      .eq('status', 'accepted')

    const allRequests = [...(fromRequests || []), ...(toRequests || [])]

    // Collect all other user IDs
    const otherUserIds = [...new Set(
      allRequests.map((fr) => fr.fromUserId === userId ? fr.toUserId : fr.fromUserId)
    )]

    if (otherUserIds.length === 0) {
      return NextResponse.json({ friends: [] })
    }

    // Batch fetch user profiles
    const { data: rawUsers } = await supabase
      .from('User')
      .select('id, username, displayName, avatar, level, points')
      .in('id', otherUserIds)
    const userMap = new Map((rawUsers || []).map((u: any) => [u.id, normalizeUser(u)]))

    // Build friends list
    const friends = allRequests.map((fr) => {
      const isFromMe = fr.fromUserId === userId
      const otherUserId = isFromMe ? fr.toUserId : fr.fromUserId
      const otherUser = userMap.get(otherUserId)
      if (!otherUser) return null
      return {
        friendshipId: fr.id,
        id: otherUser.id,
        username: otherUser.username,
        displayName: otherUser.displayName,
        avatar: otherUser.avatar,
        level: otherUser.level,
        points: otherUser.points,
      }
    }).filter(Boolean)

    return NextResponse.json({ friends })
  } catch (error) {
    console.error('Failed to get friends list:', error)
    return NextResponse.json(
      { error: 'Failed to get friends list' },
      { status: 500 }
    )
  }
}

// POST /api/friends — Send friend request
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, targetUsername, message } = body

    if (!userId || !targetUsername) {
      return NextResponse.json(
        { error: 'Missing required parameters' },
        { status: 400 }
      )
    }

    // Find target user (encode username for DB lookup)
    const dbTargetUsername = encodeUsername(targetUsername)
    const { data: targetUser } = await supabase
      .from('User')
      .select('id, username')
      .eq('username', dbTargetUsername)
      .single()

    if (!targetUser) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    // Cannot add yourself
    if (userId === targetUser.id) {
      return NextResponse.json(
        { error: 'Cannot add yourself as a friend' },
        { status: 400 }
      )
    }

    // Check if record already exists (bidirectional check)
    const { data: existingFrom } = await supabase
      .from('FriendRequest')
      .select('*')
      .eq('fromUserId', userId)
      .eq('toUserId', targetUser.id)
      .in('status', ['pending', 'accepted'])
      .limit(1)

    const { data: existingTo } = await supabase
      .from('FriendRequest')
      .select('*')
      .eq('fromUserId', targetUser.id)
      .eq('toUserId', userId)
      .in('status', ['pending', 'accepted'])
      .limit(1)

    const existingRequest = existingFrom?.[0] || existingTo?.[0]

    if (existingRequest) {
      if (existingRequest.status === 'accepted') {
        return NextResponse.json(
          { error: 'You are already friends' },
          { status: 400 }
        )
      }
      if (existingRequest.status === 'pending') {
        if (existingRequest.fromUserId === userId) {
          return NextResponse.json(
            { error: 'Friend request already sent, please wait for a response' },
            { status: 400 }
          )
        } else {
          return NextResponse.json(
            { error: 'The other user has sent you a friend request, please handle it first' },
            { status: 400 }
          )
        }
      }
    }

    // Create friend request
    const { data: friendRequest } = await supabase
      .from('FriendRequest')
      .insert({
        fromUserId: userId,
        toUserId: targetUser.id,
        message: message || '',
        status: 'pending',
      })
      .select()
      .single()

    // Fetch fromUser for the response
    const { data: fromUser } = await supabase
      .from('User')
      .select('id, username, displayName, avatar')
      .eq('id', userId)
      .single()

    // Create notification
    const notificationContent = message
      ? `sent you a friend request: ${message}`
      : 'sent you a friend request'

    await supabase.from('Notification').insert({
      type: 'friend_request',
      userId: targetUser.id,
      fromUserId: userId,
      content: notificationContent,
    })

    return NextResponse.json({
      request: {
        ...friendRequest,
        fromUser: fromUser ? { ...fromUser, displayName: fromUser.displayName || fromUser.username } : null,
      },
      message: 'Friend request sent',
    })
  } catch (error) {
    console.error('Failed to send friend request:', error)
    return NextResponse.json(
      { error: 'Failed to send friend request' },
      { status: 500 }
    )
  }
}
