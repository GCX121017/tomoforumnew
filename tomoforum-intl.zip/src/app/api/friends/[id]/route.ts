import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'

// PUT /api/friends/[id] — Accept or reject friend request
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { userId, action } = body

    if (!userId || !action) {
      return NextResponse.json(
        { error: 'Missing required parameters' },
        { status: 400 }
      )
    }

    if (action !== 'accept' && action !== 'reject') {
      return NextResponse.json(
        { error: 'Invalid action, must be accept or reject' },
        { status: 400 }
      )
    }

    // Find friend request
    const { data: friendRequest } = await supabase
      .from('FriendRequest')
      .select('*')
      .eq('id', id)
      .single()

    if (!friendRequest) {
      return NextResponse.json(
        { error: 'Friend request not found' },
        { status: 404 }
      )
    }

    // Verify: only the receiver can perform this action
    if (friendRequest.toUserId !== userId) {
      return NextResponse.json(
        { error: 'No permission to operate on this friend request' },
        { status: 403 }
      )
    }

    // Verify: can only operate on pending requests
    if (friendRequest.status !== 'pending') {
      return NextResponse.json(
        { error: 'This friend request has already been processed' },
        { status: 400 }
      )
    }

    if (action === 'accept') {
      // Accept friend request
      await supabase
        .from('FriendRequest')
        .update({ status: 'accepted' })
        .eq('id', id)

      // Notify requester: friend request accepted
      await supabase.from('Notification').insert({
        type: 'friend_accept',
        userId: friendRequest.fromUserId,
        fromUserId: userId,
        content: 'accepted your friend request',
      })

      return NextResponse.json({
        message: 'Friend request accepted',
        friendshipId: id,
      })
    } else {
      // Reject friend request
      await supabase
        .from('FriendRequest')
        .update({ status: 'rejected' })
        .eq('id', id)

      return NextResponse.json({
        message: 'Friend request rejected',
      })
    }
  } catch (error) {
    console.error('Failed to process friend request:', error)
    return NextResponse.json(
      { error: 'Failed to process friend request' },
      { status: 500 }
    )
  }
}

// DELETE /api/friends/[id]?userId=xxx — Delete friend
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { searchParams } = request.nextUrl
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'userId is required' },
        { status: 400 }
      )
    }

    // Find friend request
    const { data: friendRequest } = await supabase
      .from('FriendRequest')
      .select('*')
      .eq('id', id)
      .single()

    if (!friendRequest) {
      return NextResponse.json(
        { error: 'Friendship not found' },
        { status: 404 }
      )
    }

    // Verify: userId must be one of the two parties
    if (friendRequest.fromUserId !== userId && friendRequest.toUserId !== userId) {
      return NextResponse.json(
        { error: 'No permission' },
        { status: 403 }
      )
    }

    // Verify: can only delete accepted friendships
    if (friendRequest.status !== 'accepted') {
      return NextResponse.json(
        { error: 'Can only delete established friendships' },
        { status: 400 }
      )
    }

    // Delete friendship
    await supabase.from('FriendRequest').delete().eq('id', id)

    return NextResponse.json({
      message: 'Friend deleted',
    })
  } catch (error) {
    console.error('Failed to delete friend:', error)
    return NextResponse.json(
      { error: 'Failed to delete friend' },
      { status: 500 }
    )
  }
}
