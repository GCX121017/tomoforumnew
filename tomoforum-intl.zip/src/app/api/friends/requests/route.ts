import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'
import { normalizeUser } from '@/lib/normalizeUser'

// GET /api/friends/requests?userId=xxx — Get pending friend requests
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'userId is required' },
        { status: 400 }
      )
    }

    const { data: requests } = await supabase
      .from('FriendRequest')
      .select('*')
      .eq('toUserId', userId)
      .eq('status', 'pending')
      .order('createdAt', { ascending: false })

    if (!requests || requests.length === 0) {
      return NextResponse.json({ requests: [] })
    }

    // Batch fetch fromUser profiles
    const fromUserIds = [...new Set(requests.map((r: any) => r.fromUserId))]
    const { data: fromUsers } = await supabase
      .from('User')
      .select('id, username, displayName, avatar, level, points, bio')
      .in('id', fromUserIds)
    const userMap = new Map((fromUsers || []).map((u: any) => [u.id, normalizeUser(u)]))

    const result = requests.map((r: any) => ({
      ...r,
      fromUser: userMap.get(r.fromUserId) || null,
    }))

    return NextResponse.json({ requests: result })
  } catch (error) {
    console.error('Failed to get friend request list:', error)
    return NextResponse.json(
      { error: 'Failed to get friend request list' },
      { status: 500 }
    )
  }
}
