import { supabase } from '@/lib/supabase'
import { NextResponse } from 'next/server'
import { hashPassword } from '@/lib/password'
import { encodeUsername, generateVirtualEmail } from '@/lib/normalizeUser'

export async function GET() {
  try {
    // Only seed if User table is empty (safe guard)
    const { count: userCount } = await supabase
      .from('User')
      .select('*', { count: 'exact', head: true })

    if ((userCount || 0) > 0) {
      return NextResponse.json({
        message: 'Database already has data, skipping seed',
        stats: { users: userCount },
      })
    }

    // 1. Create categories
    const categories = [
      { name: 'Tech Discussion', icon: '💻', description: 'Programming, development, tech sharing', sortOrder: 1, postCount: 0 },
      { name: 'Daily Life', icon: '🌤️', description: 'Share your daily moments', sortOrder: 2, postCount: 0 },
      { name: 'Creative Ideas', icon: '✨', description: 'Design, creativity, inspiration', sortOrder: 3, postCount: 0 },
      { name: 'Book Notes', icon: '📚', description: 'Reading notes and book reviews', sortOrder: 4, postCount: 0 },
      { name: 'Help & Support', icon: '🆘', description: 'Ask questions and seek help', sortOrder: 5, postCount: 0 },
      { name: 'Resource Sharing', icon: '🎁', description: 'Curated resource recommendations', sortOrder: 6, postCount: 0 },
    ]

    const { data: insertedCats, error: catError } = await supabase
      .from('Category')
      .insert(categories)
      .select()

    if (catError) {
      console.error('Category insert error:', catError)
      return NextResponse.json({ error: 'Failed to create categories', detail: catError.message }, { status: 500 })
    }

    const techCat = (insertedCats || []).find(c => c.name === 'Tech Discussion')

    // 2. Create official account
    const adminPassword = await hashPassword('GuanChengxu_zl199518@outlook.com_admin_passkey')
    const officialDisplayName = 'TomoForum'
    const officialDbUsername = encodeUsername(officialDisplayName)
    const officialEmail = generateVirtualEmail(officialDbUsername)
    const { data: officialUser, error: userError } = await supabase
      .from('User')
      .insert({
        username: officialDbUsername,
        displayName: officialDisplayName,
        email: officialEmail,
        avatar: 'https://api.dicebear.com/9.x/notionists/svg?seed=official-mth',
        bio: 'TomoForum official account — community management and operations',
        role: 'official',
        level: 99,
        points: 9999,
        password: adminPassword,
      })
      .select()
      .single()

    if (userError) {
      console.error('User insert error:', userError)
      return NextResponse.json({ error: 'Failed to create official user', detail: userError.message }, { status: 500 })
    }

    // 3. Create official pinned post: Community Guidelines and Code of Conduct
    const postContent = `To make TomoForum a friendly and valuable platform for technical exchange, all members are asked to follow these guidelines.

**First, respect others.** Regardless of whether others share your views, please remain polite and respectful. Personal attacks and discriminatory remarks will not be tolerated. Everyone comes from different backgrounds and experiences — diverse voices make the community richer.

**Second, focus on content quality.** Please search for existing discussions before posting to avoid duplicates. For technical issues, provide sufficient context, including code snippets, error messages, and your environment. A good question is often more valuable than a good answer.

**Third, use tags and categories wisely.** Choosing appropriate categories and tags helps others find your posts faster and gives your content more exposure.

**Fourth, no spam or advertising.** Unauthorized commercial promotions, repeated posts, and meaningless content will be deleted. Persistent violators will be muted. Let's protect this clean space for discussion together.

---

## Points & Levels

The community uses a points-based leveling system — the more active you are, the higher your level:

| Level | Points Required | Badge |
|-------|----------------|-------|
| Newbie | 0-49 | 🫧 |
| Beginner | 50-199 | 🌱 |
| Veteran | 200-499 | 🤝 |
| Expert | 500-999 | ⭐ |
| VIP | 1000-2499 | 💎 |
| SVIP | 2500+ | 👑 |

**Ways to earn points:**
- Publishing a post: +10 pts/post
- Receiving a like: +2 pts/like
- Receiving a comment: +3 pts/comment
- Receiving a bookmark: +5 pts/bookmark

---

> Writing tomorrow in black and white. Welcome to TomoForum!`

    const { data: rulesPost, error: postError } = await supabase
      .from('Post')
      .insert({
        title: '📋 Community Guidelines and Code of Conduct',
        content: postContent,
        categoryId: techCat?.id,
        authorId: officialUser.id,
        isPinned: true,
        viewCount: 100,
        likeCount: 0,
        commentCount: 0,
      })
      .select()
      .single()

    if (postError) {
      console.error('Post insert error:', postError)
      return NextResponse.json({ error: 'Failed to create rules post', detail: postError.message }, { status: 500 })
    }

    // Update category post count
    if (techCat?.id) {
      await supabase.from('Category').update({ postCount: 1 }).eq('id', techCat.id)
    }

    return NextResponse.json({
      message: 'Seed completed: official account and community rules created',
      stats: {
        users: 1,
        posts: 1,
        categories: (insertedCats || []).length,
      },
    })
  } catch (error) {
    console.error('Error seeding:', error)
    return NextResponse.json(
      { error: 'Failed to seed database' },
      { status: 500 }
    )
  }
}
