import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const viewerId = searchParams.get('viewerId')
    const targetIdsParam = searchParams.get('targetIds')

    if (!viewerId || !targetIdsParam) {
      return NextResponse.json(
        { error: 'viewerId and targetIds are required' },
        { status: 400 }
      )
    }

    const targetIds = targetIdsParam.split(',').filter(Boolean)

    if (targetIds.length === 0) {
      return NextResponse.json({ statuses: {} })
    }

    // Query all follow relationships for this viewer → target pairs
    const { data: follows } = await supabase
      .from('Follow')
      .select('followingId')
      .eq('followerId', viewerId)
      .in('followingId', targetIds)

    const followingSet = new Set((follows || []).map((f) => f.followingId))

    // Build status map
    const statuses: Record<string, boolean> = {}
    for (const targetId of targetIds) {
      statuses[targetId] = followingSet.has(targetId)
    }

    return NextResponse.json({ statuses })
  } catch (error) {
    console.error('Error checking follow status:', error)
    return NextResponse.json(
      { error: 'Failed to check follow status' },
      { status: 500 }
    )
  }
}
