import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'

/**
 * Resolve @mention display names to user IDs.
 * GET /api/mentions/resolve?names=alice,bob
 *
 * Returns a map: { "alice": { id: "xxx", username: "alice", avatar: "..." }, ... }
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const namesStr = searchParams.get('names')?.trim()

    if (!namesStr) {
      return NextResponse.json({})
    }

    const names = namesStr
      .split(',')
      .map(n => n.trim())
      .filter(n => n.length > 0)
      .slice(0, 20) // limit to 20 names per request

    if (names.length === 0) {
      return NextResponse.json({})
    }

    // Search by displayName column
    const { data: users } = await supabase
      .from('User')
      .select('id, username, displayName, avatar')
      .in('displayName', names)

    const result: Record<string, { id: string; username: string; avatar: string }> = {}

    if (users) {
      for (const user of users) {
        // Use displayName as the key (that's what @mention shows)
        const display = user.displayName || user.username
        result[display] = {
          id: user.id,
          username: display,
          avatar: user.avatar || '',
        }
      }
    }

    return NextResponse.json(result)
  } catch (error) {
    console.error('Error resolving mentions:', error)
    return NextResponse.json({}, { status: 500 })
  }
}
