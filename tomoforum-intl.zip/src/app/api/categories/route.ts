import { supabase } from '@/lib/supabase'
import { NextResponse } from 'next/server'

export async function GET() {
  try {
    const { data: categories } = await supabase
      .from('Category')
      .select('*')
      .order('sortOrder', { ascending: true })

    if (!categories) {
      return NextResponse.json([])
    }

    const formatted = categories.map((cat: any) => ({
      id: cat.id,
      name: cat.name,
      description: cat.description,
      icon: cat.icon,
      sortOrder: cat.sortOrder,
      postCount: cat.postCount,
      createdAt: cat.createdAt,
    }))

    return NextResponse.json(formatted)
  } catch (error) {
    console.error('Error fetching categories:', error)
    return NextResponse.json(
      { error: 'Failed to fetch categories' },
      { status: 500 }
    )
  }
}
