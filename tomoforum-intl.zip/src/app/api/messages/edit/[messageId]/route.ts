import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'

// Recall marker — recalled messages have this content
const RECALLED_MARKER = '[Recalled]'

// PUT /api/messages/edit/[messageId] — Edit message (within 2 minutes)
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ messageId: string }> }
) {
  try {
    const { messageId } = await params
    const body = await request.json()
    const { userId, content } = body

    if (!userId) {
      return NextResponse.json({ error: 'userId is required' }, { status: 400 })
    }

    if (!content || typeof content !== 'string' || content.trim().length === 0) {
      return NextResponse.json({ error: 'Message content is required' }, { status: 400 })
    }

    if (content.length > 2000) {
      return NextResponse.json({ error: 'Message content cannot exceed 2000 characters' }, { status: 400 })
    }

    // Check if message exists
    const { data: existing } = await supabase
      .from('PrivateMessage')
      .select('id, senderId, content, createdAt')
      .eq('id', messageId)
      .single()

    if (!existing) {
      return NextResponse.json({ error: 'Message not found' }, { status: 404 })
    }

    // Can only edit your own messages
    if (existing.senderId !== userId) {
      return NextResponse.json({ error: 'Can only edit your own messages' }, { status: 403 })
    }

    // Recalled messages cannot be edited
    if (existing.content === RECALLED_MARKER) {
      return NextResponse.json({ error: 'Recalled messages cannot be edited' }, { status: 400 })
    }

    // Edit time limit: can edit within 2 minutes
    const createdTime = new Date(existing.createdAt).getTime()
    const now = Date.now()
    const diffMinutes = (now - createdTime) / (1000 * 60)
    if (diffMinutes > 2) {
      return NextResponse.json({ error: 'Message sent over 2 minutes ago, cannot edit' }, { status: 400 })
    }

    // Update message
    const { data: updated } = await supabase
      .from('PrivateMessage')
      .update({ content: content.trim() })
      .eq('id', messageId)
      .select()
      .single()

    if (!updated) {
      return NextResponse.json({ error: 'Edit failed' }, { status: 500 })
    }

    return NextResponse.json(updated)
  } catch (error) {
    console.error('Failed to edit message:', error)
    return NextResponse.json({ error: 'Failed to edit message' }, { status: 500 })
  }
}

// DELETE /api/messages/edit/[messageId]?userId=xxx — Recall message (within 2 minutes)
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ messageId: string }> }
) {
  try {
    const { messageId } = await params
    const { searchParams } = request.nextUrl
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json({ error: 'userId is required' }, { status: 400 })
    }

    // Check if message exists
    const { data: existing } = await supabase
      .from('PrivateMessage')
      .select('id, senderId, content, createdAt')
      .eq('id', messageId)
      .single()

    if (!existing) {
      return NextResponse.json({ error: 'Message not found' }, { status: 404 })
    }

    // Can only recall your own messages
    if (existing.senderId !== userId) {
      return NextResponse.json({ error: 'Can only recall your own messages' }, { status: 403 })
    }

    // Already recalled messages cannot be recalled again
    if (existing.content === RECALLED_MARKER) {
      return NextResponse.json({ error: 'Message already recalled' }, { status: 400 })
    }

    // Recall time limit: can recall within 2 minutes
    const createdTime = new Date(existing.createdAt).getTime()
    const now = Date.now()
    const diffMinutes = (now - createdTime) / (1000 * 60)
    if (diffMinutes > 2) {
      return NextResponse.json({ error: 'Message sent over 2 minutes ago, cannot recall' }, { status: 400 })
    }

    // Soft recall: replace content with recall marker
    const { data: recalled } = await supabase
      .from('PrivateMessage')
      .update({ content: RECALLED_MARKER })
      .eq('id', messageId)
      .select()
      .single()

    if (!recalled) {
      return NextResponse.json({ error: 'Recall failed' }, { status: 500 })
    }

    return NextResponse.json(recalled)
  } catch (error) {
    console.error('Failed to recall message:', error)
    return NextResponse.json({ error: 'Failed to recall message' }, { status: 500 })
  }
}
