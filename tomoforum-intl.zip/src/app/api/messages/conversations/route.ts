import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'
import { normalizeUser } from '@/lib/normalizeUser'

// GET /api/messages/conversations?userId=xxx
// Get all conversation list for the user (including last message, unread count, partner user info)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'userId is required' },
        { status: 400 }
      )
    }

    // 1. Find all private messages the user participated in, get all partner user IDs
    const { data: messages } = await supabase
      .from('PrivateMessage')
      .select('senderId, receiverId')
      .or(`senderId.eq.${userId},receiverId.eq.${userId}`)
      .order('createdAt', { ascending: false })

    // 2. Extract all unique partner user IDs
    const partnerIds = new Set<string>()
    for (const msg of (messages || [])) {
      if (msg.senderId !== userId) partnerIds.add(msg.senderId)
      if (msg.receiverId !== userId) partnerIds.add(msg.receiverId)
    }

    if (partnerIds.size === 0) {
      return NextResponse.json([])
    }

    // 3. For each conversation partner, get user info, last message, unread count
    const conversations = await Promise.all(
      Array.from(partnerIds).map(async (partnerId) => {
        // Get partner user info
        const { data: partner } = await supabase
          .from('User')
          .select('id, username, displayName, avatar, level')
          .eq('id', partnerId)
          .single()

        if (!partner) return null

        // Get last message
        const { data: lastMessages } = await supabase
          .from('PrivateMessage')
          .select('content, createdAt, isRead, senderId')
          .or(`and(senderId.eq.${userId},receiverId.eq.${partnerId}),and(senderId.eq.${partnerId},receiverId.eq.${userId})`)
          .order('createdAt', { ascending: false })
          .limit(1)

        const lastMessage = lastMessages?.[0] || null

        // Get unread message count
        const { count: unreadCount } = await supabase
          .from('PrivateMessage')
          .select('*', { count: 'exact', head: true })
          .eq('senderId', partnerId)
          .eq('receiverId', userId)
          .eq('isRead', false)

        return {
          partner: normalizeUser(partner),
          lastMessage: lastMessage
            ? {
                content: lastMessage.content,
                createdAt: lastMessage.createdAt,
                isRead: lastMessage.isRead,
                isMine: lastMessage.senderId === userId,
              }
            : null,
          unreadCount: unreadCount || 0,
        }
      })
    )

    // 4. Filter null values and sort by last message time (descending)
    const validConversations = conversations.filter(Boolean).sort((a, b) => {
      const aTime = a!.lastMessage?.createdAt ? new Date(a!.lastMessage.createdAt).getTime() : 0
      const bTime = b!.lastMessage?.createdAt ? new Date(b!.lastMessage.createdAt).getTime() : 0
      return bTime - aTime
    })

    return NextResponse.json(validConversations)
  } catch (error) {
    console.error('Failed to get conversation list:', error)
    return NextResponse.json(
      { error: 'Failed to get conversation list' },
      { status: 500 }
    )
  }
}
