import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'
import { normalizeUser } from '@/lib/normalizeUser'

// GET /api/messages/[partnerId]?userId=xxx
// Get chat history with specified user and mark unread messages as read
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ partnerId: string }> }
) {
  try {
    const { partnerId } = await params
    const { searchParams } = request.nextUrl
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'userId is required' },
        { status: 400 }
      )
    }

    if (!partnerId) {
      return NextResponse.json(
        { error: 'Missing chat partner ID' },
        { status: 400 }
      )
    }

    // Get chat history (chronological order, max 200 messages)
    const { data: messages } = await supabase
      .from('PrivateMessage')
      .select('*')
      .or(`and(senderId.eq.${userId},receiverId.eq.${partnerId}),and(senderId.eq.${partnerId},receiverId.eq.${userId})`)
      .order('createdAt', { ascending: true })
      .limit(200)

    if (!messages || messages.length === 0) {
      return NextResponse.json([])
    }

    // Batch fetch sender profiles
    const senderIds = [...new Set(messages.map((m: any) => m.senderId))]
    const { data: senders } = await supabase
      .from('User')
      .select('id, username, displayName, avatar')
      .in('id', senderIds)
    const senderMap = new Map((senders || []).map((u: any) => [u.id, normalizeUser(u)]))

    const result = messages.map((m: any) => ({
      ...m,
      sender: senderMap.get(m.senderId) || null,
    }))

    // Mark all unread messages as read (unread messages sent by partner to current user)
    await supabase
      .from('PrivateMessage')
      .update({ isRead: true })
      .eq('senderId', partnerId)
      .eq('receiverId', userId)
      .eq('isRead', false)

    return NextResponse.json(result)
  } catch (error) {
    console.error('Failed to get chat history:', error)
    return NextResponse.json(
      { error: 'Failed to get chat history' },
      { status: 500 }
    )
  }
}

// POST /api/messages/[partnerId]
// Send private message
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ partnerId: string }> }
) {
  try {
    const { partnerId } = await params
    const body = await request.json()
    const { userId, content } = body

    // Validate parameters
    if (!userId) {
      return NextResponse.json(
        { error: 'Missing sender ID' },
        { status: 400 }
      )
    }

    if (!content || typeof content !== 'string') {
      return NextResponse.json(
        { error: 'Message content is required' },
        { status: 400 }
      )
    }

    if (content.trim().length === 0) {
      return NextResponse.json(
        { error: 'Message content cannot be blank' },
        { status: 400 }
      )
    }

    if (content.length > 2000) {
      return NextResponse.json(
        { error: 'Message content cannot exceed 2000 characters' },
        { status: 400 }
      )
    }

    // Cannot send message to yourself
    if (userId === partnerId) {
      return NextResponse.json(
        { error: 'Cannot send message to yourself' },
        { status: 400 }
      )
    }

    // Verify friendship
    const { data: friendship } = await supabase
      .from('FriendRequest')
      .select('id')
      .eq('status', 'accepted')
      .or(`and(fromUserId.eq.${userId},toUserId.eq.${partnerId}),and(fromUserId.eq.${partnerId},toUserId.eq.${userId})`)
      .limit(1)

    if (!friendship || friendship.length === 0) {
      return NextResponse.json(
        { error: 'Can only send private messages to friends' },
        { status: 403 }
      )
    }

    // Verify partner user exists
    const { data: receiver } = await supabase
      .from('User')
      .select('id')
      .eq('id', partnerId)
      .single()

    if (!receiver) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    // Create private message
    const { data: message } = await supabase
      .from('PrivateMessage')
      .insert({
        senderId: userId,
        receiverId: partnerId,
        content: content.trim(),
      })
      .select()
      .single()

    if (!message) {
      return NextResponse.json({ error: 'Failed to send message' }, { status: 500 })
    }

    // Fetch sender for the response
    const { data: sender } = await supabase
      .from('User')
      .select('id, username, displayName, avatar')
      .eq('id', userId)
      .single()

    // Create notification
    await supabase.from('Notification').insert({
      type: 'private_message',
      userId: partnerId,
      fromUserId: userId,
      content: 'sent you a private message',
    })

    return NextResponse.json({
      ...message,
      sender: sender ? normalizeUser(sender) : null,
    })
  } catch (error) {
    console.error('Failed to send private message:', error)
    return NextResponse.json(
      { error: 'Failed to send private message' },
      { status: 500 }
    )
  }
}
