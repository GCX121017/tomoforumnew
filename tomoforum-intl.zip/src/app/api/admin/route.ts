import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { normalizeUser } from '@/lib/normalizeUser'
import { recalculateUserPoints } from '@/lib/recalcPoints'

const COOKIE_NAME = 'forum_user_id'

async function getOfficialUser(request: NextRequest) {
  const cookieStore = await cookies()
  const userId = cookieStore.get(COOKIE_NAME)?.value
  if (!userId) return null
  const { data: user } = await supabase.from('User').select('*').eq('id', userId).single()
  if (!user || user.role !== 'official') return null
  return user
}

// Helper: enrich posts with author and category
async function enrichPostsForAdmin(rawPosts: any[]) {
  if (!rawPosts || rawPosts.length === 0) return []

  const authorIds = [...new Set(rawPosts.map((p: any) => p.authorId))]
  const categoryIds = [...new Set(rawPosts.map((p: any) => p.categoryId))]
  const postIds = rawPosts.map((p: any) => p.id)

  const [authorsRes, categoriesRes, likeCountsRes, commentCountsRes, bookmarkCountsRes] = await Promise.all([
    supabase.from('User').select('id, username, displayName, avatar, role').in('id', authorIds),
    supabase.from('Category').select('id, name, icon').in('id', categoryIds),
    supabase.from('PostLike').select('postId').in('postId', postIds),
    supabase.from('Comment').select('postId').in('postId', postIds),
    supabase.from('PostBookmark').select('postId').in('postId', postIds),
  ])

  const authorMap = new Map((authorsRes.data || []).map((a: any) => [a.id, normalizeUser(a)]))
  const categoryMap = new Map((categoriesRes.data || []).map((c: any) => [c.id, c]))

  const likeCountsMap = new Map<string, number>()
  for (const lc of (likeCountsRes.data || [])) likeCountsMap.set(lc.postId, (likeCountsMap.get(lc.postId) || 0) + 1)

  const commentCountsMap = new Map<string, number>()
  for (const cc of (commentCountsRes.data || [])) commentCountsMap.set(cc.postId, (commentCountsMap.get(cc.postId) || 0) + 1)

  const bookmarkCountsMap = new Map<string, number>()
  for (const bc of (bookmarkCountsRes.data || [])) bookmarkCountsMap.set(bc.postId, (bookmarkCountsMap.get(bc.postId) || 0) + 1)

  return rawPosts.map((post: any) => ({
    ...post,
    author: authorMap.get(post.authorId) || null,
    category: categoryMap.get(post.categoryId) || null,
    _count: {
      comments: commentCountsMap.get(post.id) || 0,
      likes: likeCountsMap.get(post.id) || 0,
      bookmarks: bookmarkCountsMap.get(post.id) || 0,
    },
  }))
}

// Helper: enrich comments with author and post
async function enrichCommentsForAdmin(rawComments: any[]) {
  if (!rawComments || rawComments.length === 0) return []

  const authorIds = [...new Set(rawComments.map((c: any) => c.authorId))]
  const postIds = [...new Set(rawComments.map((c: any) => c.postId))]

  const [authorsRes, postsRes] = await Promise.all([
    supabase.from('User').select('id, username, displayName, avatar, role').in('id', authorIds),
    supabase.from('Post').select('id, title').in('id', postIds),
  ])

  const authorMap = new Map((authorsRes.data || []).map((a: any) => [a.id, normalizeUser(a)]))
  const postMap = new Map((postsRes.data || []).map((p: any) => [p.id, p]))

  return rawComments.map((comment: any) => ({
    ...comment,
    author: authorMap.get(comment.authorId) || null,
    post: postMap.get(comment.postId) || null,
  }))
}

// Helper: enrich users with counts
async function enrichUsersForAdmin(rawUsers: any[]) {
  if (!rawUsers || rawUsers.length === 0) return []

  const userIds = rawUsers.map((u: any) => u.id)

  const [postCountsRes, commentCountsRes, followersRes] = await Promise.all([
    supabase.from('Post').select('authorId').in('authorId', userIds),
    supabase.from('Comment').select('authorId').in('authorId', userIds),
    supabase.from('Follow').select('followingId').in('followingId', userIds),
  ])

  const postCountsMap = new Map<string, number>()
  for (const pc of (postCountsRes.data || [])) postCountsMap.set(pc.authorId, (postCountsMap.get(pc.authorId) || 0) + 1)

  const commentCountsMap = new Map<string, number>()
  for (const cc of (commentCountsRes.data || [])) commentCountsMap.set(cc.authorId, (commentCountsMap.get(cc.authorId) || 0) + 1)

  const followersCountsMap = new Map<string, number>()
  for (const f of (followersRes.data || [])) followersCountsMap.set(f.followingId, (followersCountsMap.get(f.followingId) || 0) + 1)

  return rawUsers.map((user: any) => ({
    ...user,
    _count: {
      posts: postCountsMap.get(user.id) || 0,
      comments: commentCountsMap.get(user.id) || 0,
      followers: followersCountsMap.get(user.id) || 0,
    },
  }))
}

export async function GET(request: NextRequest) {
  try {
    const official = await getOfficialUser(request)
    if (!official) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const { searchParams } = request.nextUrl
    const section = searchParams.get('section') || 'overview'

    if (section === 'overview') {
      const [userCountRes, postCountRes, commentCountRes] = await Promise.all([
        supabase.from('User').select('id', { count: 'exact', head: true }).eq('role', 'user'),
        supabase.from('Post').select('id', { count: 'exact', head: true }),
        supabase.from('Comment').select('id', { count: 'exact', head: true }),
      ])

      const userCount = userCountRes.count || 0
      const postCount = postCountRes.count || 0
      const commentCount = commentCountRes.count || 0

      // Recent posts
      const { data: rawRecentPosts } = await supabase
        .from('Post')
        .select('*')
        .order('createdAt', { ascending: false })
        .limit(10)
      const recentPosts = await enrichPostsForAdmin(rawRecentPosts || [])

      // Recent users
      const { data: rawRecentUsers } = await supabase
        .from('User')
        .select('*')
        .eq('role', 'user')
        .order('createdAt', { ascending: false })
        .limit(10)
      const recentUsers = await enrichUsersForAdmin(rawRecentUsers || [])

      return NextResponse.json({ userCount, postCount, commentCount, recentPosts, recentUsers })
    }

    if (section === 'posts') {
      const { data: rawPosts } = await supabase
        .from('Post')
        .select('*')
        .order('createdAt', { ascending: false })
        .limit(50)
      const posts = await enrichPostsForAdmin(rawPosts || [])
      return NextResponse.json(posts)
    }

    if (section === 'comments') {
      const { data: rawComments } = await supabase
        .from('Comment')
        .select('*')
        .order('createdAt', { ascending: false })
        .limit(50)
      const comments = await enrichCommentsForAdmin(rawComments || [])
      return NextResponse.json(comments)
    }

    if (section === 'users') {
      const { data: rawUsers } = await supabase
        .from('User')
        .select('*')
        .eq('role', 'user')
        .order('createdAt', { ascending: false })
      const users = await enrichUsersForAdmin(rawUsers || [])
      return NextResponse.json(users)
    }

    return NextResponse.json({ error: 'Invalid section' }, { status: 400 })
  } catch (error) {
    console.error('Admin GET error:', error)
    return NextResponse.json({ error: 'Failed' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const official = await getOfficialUser(request)
    if (!official) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const body = await request.json()
    const { action } = body

    if (action === 'createOfficialPost') {
      const { title, content, categoryId, isPinned } = body
      if (!title || !categoryId) {
        return NextResponse.json({ error: 'title and categoryId required' }, { status: 400 })
      }

      const { data: post } = await supabase
        .from('Post')
        .insert({
          title,
          content: content || '',
          categoryId,
          authorId: official.id,
          isPinned: isPinned || false,
        })
        .select()
        .single()

      if (!post) {
        return NextResponse.json({ error: 'Failed to create post' }, { status: 500 })
      }

      // Increment category postCount
      const { data: cat } = await supabase
        .from('Category')
        .select('postCount')
        .eq('id', categoryId)
        .single()
      if (cat) {
        await supabase.from('Category').update({ postCount: (cat.postCount || 0) + 1 }).eq('id', categoryId)
      }

      // Fetch author and category for response
      const { data: author } = await supabase.from('User').select('id, username, displayName, avatar, role').eq('id', official.id).single()
      const { data: category } = await supabase.from('Category').select('id, name, icon').eq('id', categoryId).single()

      return NextResponse.json({
        ...post,
        author: author ? normalizeUser(author) : null,
        category: category || null,
      }, { status: 201 })
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 })
  } catch (error) {
    console.error('Admin POST error:', error)
    return NextResponse.json({ error: 'Failed' }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const official = await getOfficialUser(request)
    if (!official) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const { searchParams } = request.nextUrl
    const targetType = searchParams.get('type') // 'post' | 'comment' | 'user'
    const targetId = searchParams.get('id')

    if (!targetType || !targetId) {
      return NextResponse.json({ error: 'type and id required' }, { status: 400 })
    }

    if (targetType === 'post') {
      const { data: post } = await supabase
        .from('Post')
        .select('id, categoryId')
        .eq('id', targetId)
        .single()
      if (!post) return NextResponse.json({ error: 'Post not found' }, { status: 404 })

      await supabase.from('Post').delete().eq('id', targetId)

      // Decrement category postCount
      const { data: cat } = await supabase.from('Category').select('postCount').eq('id', post.categoryId).single()
      if (cat) {
        await supabase.from('Category').update({ postCount: Math.max(0, (cat.postCount || 1) - 1) }).eq('id', post.categoryId)
      }
      return NextResponse.json({ success: true })
    }

    if (targetType === 'comment') {
      const { data: comment } = await supabase
        .from('Comment')
        .select('id, postId')
        .eq('id', targetId)
        .single()
      if (!comment) return NextResponse.json({ error: 'Comment not found' }, { status: 404 })

      // Count replies
      const { count: replyCount } = await supabase
        .from('Comment')
        .select('*', { count: 'exact', head: true })
        .eq('parentId', targetId)

      const deleteCount = 1 + (replyCount || 0)

      await supabase.from('Comment').delete().eq('id', targetId)
      if (replyCount && replyCount > 0) {
        await supabase.from('Comment').delete().eq('parentId', targetId)
      }

      const { data: postData } = await supabase.from('Post').select('commentCount').eq('id', comment.postId).single()
      if (postData) {
        await supabase.from('Post').update({ commentCount: Math.max(0, (postData.commentCount || 0) - deleteCount) }).eq('id', comment.postId)
      }
      return NextResponse.json({ success: true })
    }

    if (targetType === 'user') {
      const { data: user } = await supabase
        .from('User')
        .select('*')
        .eq('id', targetId)
        .single()
      if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })
      if (user.role === 'official') {
        return NextResponse.json({ error: 'Cannot delete official user' }, { status: 400 })
      }

      // Get user's posts for category count updates
      const { data: userPosts } = await supabase
        .from('Post')
        .select('id, categoryId')
        .eq('authorId', targetId)

      // Calculate category decrements
      const categoryUpdates: Record<string, number> = {}
      for (const p of (userPosts || [])) {
        categoryUpdates[p.categoryId] = (categoryUpdates[p.categoryId] || 0) + 1
      }

      // Update category counts
      for (const [catId, count] of Object.entries(categoryUpdates)) {
        const { data: cat } = await supabase.from('Category').select('postCount').eq('id', catId).single()
        if (cat) {
          await supabase.from('Category').update({ postCount: Math.max(0, (cat.postCount || 0) - count) }).eq('id', catId)
        }
      }

      // Delete user (cascade should handle related records)
      await supabase.from('User').delete().eq('id', targetId)
      return NextResponse.json({ success: true })
    }

    return NextResponse.json({ error: 'Invalid type' }, { status: 400 })
  } catch (error) {
    console.error('Admin DELETE error:', error)
    return NextResponse.json({ error: 'Failed' }, { status: 500 })
  }
}
