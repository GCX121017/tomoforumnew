import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/supabase'

const MAX_FILE_SIZE = 20 * 1024 * 1024 // 20MB

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get('file') as File | null

    if (!file) {
      return NextResponse.json({ error: 'No file selected' }, { status: 400 })
    }

    if (file.size > MAX_FILE_SIZE) {
      return NextResponse.json({ error: 'File size cannot exceed 20MB' }, { status: 400 })
    }

    // Generate unique path
    const timestamp = Date.now()
    const randomStr = Math.random().toString(36).substring(2, 8)
    const ext = file.name.split('.').pop() || 'bin'
    const sanitized = file.name.replace(/[^a-zA-Z0-9._\-\u4e00-\u9fa5]/g, '_')
    const filePath = `${timestamp}_${randomStr}_${sanitized}`

    // Upload to Supabase Storage Post-Files bucket
    const { error: uploadError } = await supabase.storage
      .from('Post-Files')
      .upload(filePath, file, {
        cacheControl: '31536000',
        upsert: false,
      })

    if (uploadError) {
      console.error('Upload error:', uploadError)
      return NextResponse.json(
        { error: 'File upload failed: ' + (uploadError.message || 'Unknown error') },
        { status: 500 }
      )
    }

    // Get public URL
    const { data: urlData } = supabase.storage
      .from('Post-Files')
      .getPublicUrl(filePath)

    // Determine media type from MIME
    let mediaType: 'image' | 'audio' | 'video' | 'file' = 'file'
    if (file.type.startsWith('image/')) {
      mediaType = 'image'
    } else if (file.type.startsWith('audio/')) {
      mediaType = 'audio'
    } else if (file.type.startsWith('video/')) {
      mediaType = 'video'
    }

    return NextResponse.json({
      filename: file.name,
      url: urlData.publicUrl,
      mediaType,
      size: file.size,
    })
  } catch (error) {
    console.error('Upload error:', error)
    return NextResponse.json({ error: 'File upload failed' }, { status: 500 })
  }
}
