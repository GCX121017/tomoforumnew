import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/supabase'

const MAX_AVATAR_SIZE = 2 * 1024 * 1024 // 2MB
const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml']

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get('avatar') as File | null
    const userId = formData.get('userId') as string | null

    if (!file) {
      return NextResponse.json({ error: 'No avatar file selected' }, { status: 400 })
    }

    if (!ALLOWED_TYPES.includes(file.type)) {
      return NextResponse.json({ error: 'Only JPG, PNG, GIF, WebP, SVG formats are supported' }, { status: 400 })
    }

    if (file.size > MAX_AVATAR_SIZE) {
      return NextResponse.json({ error: 'Avatar size cannot exceed 2MB' }, { status: 400 })
    }

    // Generate unique path: userId/timestamp_random.ext
    const timestamp = Date.now()
    const randomStr = Math.random().toString(36).substring(2, 8)
    const ext = file.name.split('.').pop() || 'jpg'
    const prefix = userId ? `${userId}/` : ''
    const filePath = `${prefix}${timestamp}_${randomStr}.${ext}`

    // Upload to Supabase Storage Avatars bucket
    const { error: uploadError } = await supabase.storage
      .from('Avatars')
      .upload(filePath, file, {
        cacheControl: '31536000',
        upsert: false,
      })

    if (uploadError) {
      console.error('Avatar upload error:', uploadError)
      return NextResponse.json(
        { error: 'Avatar upload failed: ' + (uploadError.message || 'Unknown error') },
        { status: 500 }
      )
    }

    // Get public URL
    const { data: urlData } = supabase.storage
      .from('Avatars')
      .getPublicUrl(filePath)

    return NextResponse.json({
      url: urlData.publicUrl,
      filename: file.name,
    })
  } catch (error) {
    console.error('Avatar upload error:', error)
    return NextResponse.json({ error: 'Avatar upload failed' }, { status: 500 })
  }
}
