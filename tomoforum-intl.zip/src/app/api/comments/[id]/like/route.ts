import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: commentId } = await params
    const body = await request.json()
    const { userId } = body

    if (!userId) {
      return NextResponse.json(
        { error: 'userId is required' },
        { status: 400 }
      )
    }

    // Verify comment exists
    const { data: comment } = await supabase
      .from('Comment')
      .select('id')
      .eq('id', commentId)
      .single()
    if (!comment) {
      return NextResponse.json(
        { error: 'Comment not found' },
        { status: 404 }
      )
    }

    // Check if like already exists
    const { data: existingLike } = await supabase
      .from('CommentLike')
      .select('id')
      .eq('commentId', commentId)
      .eq('userId', userId)
      .maybeSingle()

    if (existingLike) {
      // Unlike: remove
      await supabase.from('CommentLike').delete().eq('id', existingLike.id)

      const { count: likeCount } = await supabase
        .from('CommentLike')
        .select('*', { count: 'exact', head: true })
        .eq('commentId', commentId)

      return NextResponse.json({ liked: false, likeCount })
    } else {
      // Like: create
      await supabase.from('CommentLike').insert({ commentId, userId })

      const { count: likeCount } = await supabase
        .from('CommentLike')
        .select('*', { count: 'exact', head: true })
        .eq('commentId', commentId)

      return NextResponse.json({ liked: true, likeCount })
    }
  } catch (error) {
    console.error('Error toggling comment like:', error)
    return NextResponse.json(
      { error: 'Failed to toggle comment like' },
      { status: 500 }
    )
  }
}
