import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    const { data: comment } = await supabase
      .from('Comment')
      .select('*')
      .eq('id', id)
      .single()

    if (!comment) {
      return NextResponse.json(
        { error: 'Comment not found' },
        { status: 404 }
      )
    }

    // Count replies
    const { count: replyCount } = await supabase
      .from('Comment')
      .select('*', { count: 'exact', head: true })
      .eq('parentId', id)

    const deleteCount = 1 + (replyCount || 0)

    // Delete the comment (replies should cascade)
    await supabase.from('Comment').delete().eq('id', id)

    // Also delete replies explicitly (in case cascade isn't set up)
    if (replyCount && replyCount > 0) {
      await supabase.from('Comment').delete().eq('parentId', id)
    }

    // Decrement post commentCount
    const { data: post } = await supabase
      .from('Post')
      .select('commentCount')
      .eq('id', comment.postId)
      .single()
    if (post) {
      await supabase
        .from('Post')
        .update({ commentCount: Math.max(0, (post.commentCount || 0) - deleteCount) })
        .eq('id', comment.postId)
    }

    return NextResponse.json({ success: true, deletedCount: deleteCount })
  } catch (error) {
    console.error('Error deleting comment:', error)
    return NextResponse.json(
      { error: 'Failed to delete comment' },
      { status: 500 }
    )
  }
}
