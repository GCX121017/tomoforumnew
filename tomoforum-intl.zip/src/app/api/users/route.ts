import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'
import { calculatePoints, getLevelFromPoints, generateAvatarUrl, generateRandomColor } from '@/lib/levels'
import { normalizeUser, normalizeUsers, encodeUsername, generateVirtualEmail, hasNonASCII } from '@/lib/normalizeUser'
import { recalculateUserPoints } from '@/lib/recalcPoints'
import { randomUUID } from 'crypto'

// Helper to get user counts
async function getUserCounts(userId: string) {
  const [postsRes, commentsRes, followersRes, followingRes] = await Promise.all([
    supabase.from('Post').select('id', { count: 'exact', head: true }).eq('authorId', userId),
    supabase.from('Comment').select('id', { count: 'exact', head: true }).eq('authorId', userId),
    supabase.from('Follow').select('id', { count: 'exact', head: true }).eq('followingId', userId),
    supabase.from('Follow').select('id', { count: 'exact', head: true }).eq('followerId', userId),
  ])
  return {
    postCount: postsRes.count || 0,
    commentCount: commentsRes.count || 0,
    followersCount: followersRes.count || 0,
    followingCount: followingRes.count || 0,
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const username = searchParams.get('username')
    const search = searchParams.get('search')?.trim()

    // User search (for user filter in post list)
    if (search) {
      // Encode search term for DB lookup
      const dbSearch = encodeUsername(search)
      let query = supabase
        .from('User')
        .select('*')
        .eq('role', 'user')
        .ilike('username', `%${dbSearch}%`)
        .order('points', { ascending: false })
        .limit(10)

      const { data: rawUsers } = await query
      const users = normalizeUsers(rawUsers || [])

      // Attach counts
      const usersWithCounts = await Promise.all(
        users.map(async (u) => {
          const counts = await getUserCounts(u.id)
          return {
            id: u.id,
            username: u.username,
            displayName: u.displayName,
            avatar: u.avatar,
            bio: u.bio,
            level: u.level,
            points: u.points,
            role: u.role,
            _count: {
              posts: counts.postCount,
              followers: counts.followersCount,
              following: counts.followingCount,
            },
          }
        })
      )

      return NextResponse.json(usersWithCounts)
    }

    if (!username) {
      return NextResponse.json(
        { error: 'username is required' },
        { status: 400 }
      )
    }

    // Encode username for DB lookup
    const dbUsername = encodeUsername(username)

    const { data: rawUser } = await supabase
      .from('User')
      .select('*')
      .eq('username', dbUsername)
      .single()

    if (!rawUser) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    const user = normalizeUser(rawUser)

    // Recalculate points in real-time for this user
    if (user.role !== 'official') {
      const { points: newPoints, level: newLevel } = await recalculateUserPoints(user.id)
      if (user.points !== newPoints || user.level !== newLevel) {
        user.points = newPoints
        user.level = newLevel
      }
    }

    const counts = await getUserCounts(user.id)

    return NextResponse.json({
      ...user,
      _count: {
        posts: counts.postCount,
        comments: counts.commentCount,
        followers: counts.followersCount,
        following: counts.followingCount,
      },
    })
  } catch (error) {
    console.error('Error fetching user:', error)
    return NextResponse.json(
      { error: 'Failed to fetch user' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { username, avatar, avatarColor, avatarType, bio } = body

    if (!username || !username.trim()) {
      return NextResponse.json(
        { error: 'Username is required' },
        { status: 400 }
      )
    }

    if (username.trim().length < 2) {
      return NextResponse.json(
        { error: 'Username must be at least 2 characters' },
        { status: 400 }
      )
    }

    if (username.trim().length > 20) {
      return NextResponse.json(
        { error: 'Username cannot exceed 20 characters' },
        { status: 400 }
      )
    }

    const displayName = username.trim()
    // Encode username for DB storage
    const dbUsername = encodeUsername(displayName)
    // Generate unique virtual email
    const virtualEmail = generateVirtualEmail(dbUsername)

    // Check if username already exists
    const { data: existingUser } = await supabase
      .from('User')
      .select('id')
      .eq('username', dbUsername)
      .single()

    if (existingUser) {
      return NextResponse.json(
        { error: 'Username already exists', exists: true },
        { status: 409 }
      )
    }

    // Determine avatar
    let finalAvatar = avatar || ''
    let finalColor = avatarColor || ''
    let finalType = avatarType || 'preset'

    if (!finalAvatar) {
      const color = finalColor || generateRandomColor()
      finalAvatar = generateAvatarUrl(displayName, color)
      finalColor = color
      finalType = 'generated'
    }

    const { data: user } = await supabase
      .from('User')
      .insert({
        id: randomUUID(),
        username: dbUsername,
        displayName: displayName,
        email: virtualEmail,
        avatar: finalAvatar,
        avatarColor: finalColor,
        avatarType: finalType,
        bio: bio || '',
        role: 'user',
        level: 0,
        points: 0,
      })
      .select()
      .single()

    if (!user) {
      return NextResponse.json({ error: 'Failed to create user' }, { status: 500 })
    }

    return NextResponse.json(normalizeUser(user), { status: 201 })
  } catch (error) {
    console.error('Error creating user:', error)
    return NextResponse.json(
      { error: 'Failed to create user' },
      { status: 500 }
    )
  }
}
