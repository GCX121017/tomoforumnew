import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'
import { normalizeUser } from '@/lib/normalizeUser'
import { recalculateUserPoints } from '@/lib/recalcPoints'

// Helper to get user counts
async function getUserCounts(userId: string) {
  const [postsRes, commentsRes, bookmarksRes, followersRes, followingRes] = await Promise.all([
    supabase.from('Post').select('id', { count: 'exact', head: true }).eq('authorId', userId),
    supabase.from('Comment').select('id', { count: 'exact', head: true }).eq('authorId', userId),
    supabase.from('PostBookmark').select('id', { count: 'exact', head: true }).eq('userId', userId),
    supabase.from('Follow').select('id', { count: 'exact', head: true }).eq('followingId', userId),
    supabase.from('Follow').select('id', { count: 'exact', head: true }).eq('followerId', userId),
  ])
  return {
    postCount: postsRes.count || 0,
    commentCount: commentsRes.count || 0,
    bookmarkCount: bookmarksRes.count || 0,
    followersCount: followersRes.count || 0,
    followingCount: followingRes.count || 0,
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { bio, avatar, avatarColor, avatarType } = body

    const updateData: Record<string, any> = {}
    if (bio !== undefined) updateData.bio = bio
    if (avatar !== undefined) updateData.avatar = avatar
    if (avatarColor !== undefined) updateData.avatarColor = avatarColor
    if (avatarType !== undefined) updateData.avatarType = avatarType

    const { data: user } = await supabase
      .from('User')
      .update(updateData)
      .eq('id', id)
      .select()
      .single()

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    return NextResponse.json(normalizeUser(user))
  } catch (error) {
    console.error('Error updating user:', error)
    return NextResponse.json({ error: 'Failed to update user' }, { status: 500 })
  }
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    const { data: rawUser } = await supabase
      .from('User')
      .select('*')
      .eq('id', id)
      .single()

    if (!rawUser) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    const user = normalizeUser(rawUser)

    // Recalculate points in real-time
    let points = user.points
    let level = user.level
    if (user.role !== 'official') {
      const result = await recalculateUserPoints(user.id)
      points = result.points
      level = result.level
    }

    const counts = await getUserCounts(user.id)

    // Fetch bookmarks for this user (with post + author + category)
    const { data: bookmarkEntries } = await supabase
      .from('PostBookmark')
      .select('id, postId, createdAt')
      .eq('userId', id)
      .order('createdAt', { ascending: false })
      .limit(20)

    let bookmarks: any[] = []
    if (bookmarkEntries && bookmarkEntries.length > 0) {
      const postIds = bookmarkEntries.map((b: any) => b.postId)

      // Batch fetch posts
      const { data: rawPosts } = await supabase
        .from('Post')
        .select('*')
        .in('id', postIds)

      if (rawPosts && rawPosts.length > 0) {
        // Collect author IDs and category IDs
        const authorIds = [...new Set(rawPosts.map((p: any) => p.authorId))]
        const categoryIds = [...new Set(rawPosts.map((p: any) => p.categoryId))]

        // Batch fetch authors and categories
        const [authorsRes, categoriesRes] = await Promise.all([
          supabase.from('User').select('id, username, avatar, level, role, displayName').in('id', authorIds),
          supabase.from('Category').select('id, name, icon').in('id', categoryIds),
        ])

        const authorMap = new Map((authorsRes.data || []).map((a: any) => [a.id, a]))
        const categoryMap = new Map((categoriesRes.data || []).map((c: any) => [c.id, c]))

        // Map bookmark order
        const postOrderMap = new Map(bookmarkEntries.map((b: any, i: number) => [b.postId, i]))

        const postsWithDetails = rawPosts
          .map((p: any) => ({
            ...p,
            author: authorMap.get(p.authorId) ? normalizeUser(authorMap.get(p.authorId)) : null,
            category: categoryMap.get(p.categoryId) || null,
          }))
          .sort((a: any, b: any) => (postOrderMap.get(a.id) ?? 0) - (postOrderMap.get(b.id) ?? 0))

        bookmarks = postsWithDetails
      }
    }

    return NextResponse.json({
      id: user.id,
      username: user.username,
      displayName: user.displayName,
      email: user.email,
      avatar: user.avatar,
      avatarColor: user.avatarColor,
      avatarType: user.avatarType,
      bio: user.bio,
      role: user.role,
      level,
      points,
      createdAt: user.createdAt,
      updatedAt: user.updatedAt,
      _count: counts,
      bookmarks,
    })
  } catch (error) {
    console.error('Error fetching user:', error)
    return NextResponse.json(
      { error: 'Failed to fetch user' },
      { status: 500 }
    )
  }
}
