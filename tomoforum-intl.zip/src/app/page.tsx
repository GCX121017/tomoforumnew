'use client'

import { useEffect } from 'react'
import { useForumStore } from '@/store/forum'
import ForumHeader from '@/components/forum/ForumHeader'
import ForumSidebar from '@/components/forum/ForumSidebar'
import ForumFooter from '@/components/forum/ForumFooter'
import MobileBottomNav from '@/components/forum/MobileBottomNav'
import RegionDetector from '@/components/forum/RegionDetector'
import BackToTop from '@/components/forum/BackToTop'
import PostList from '@/components/forum/PostList'
import PostDetail from '@/components/forum/PostDetail'
import CreatePost from '@/components/forum/CreatePost'
import UserProfile from '@/components/forum/UserProfile'
import SearchResults from '@/components/forum/SearchResults'
import AdminPanel from '@/components/forum/AdminPanel'
import LegalPages from '@/components/forum/LegalPages'
import FriendPanel from '@/components/forum/FriendPanel'
import MessagesPage from '@/components/forum/MessagesPage'
import { AnimatePresence, motion } from 'framer-motion'

export default function ForumPage() {
  const { currentPage, navigate } = useForumStore()

  // NOTE: Seed is no longer auto-called on page load.
  // Supabase data persists in the cloud — do NOT call /api/seed automatically.
  // If you need to re-seed, manually visit /api/seed in the browser.

  const renderPage = () => {
    switch (currentPage.name) {
      case 'home':
        return <PostList />
      case 'post':
        return <PostDetail />
      case 'create':
      case 'edit':
        return <CreatePost />
      case 'user':
        return <UserProfile />
      case 'search':
        return <SearchResults />
      case 'admin':
        return <AdminPanel />
      case 'legal':
        return <LegalPages />
      case 'messages':
        return <MessagesPage />
      default:
        return <PostList />
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-gray-50/50 to-gray-100/80 dark:from-gray-950 dark:to-gray-900 pb-16 md:pb-0 custom-scrollbar">
      {/* Region Detection Banner */}
      <RegionDetector />

      {/* Header */}
      <ForumHeader />

      {/* Main Content */}
      <div className="flex-1 pt-14">
        <main className="max-w-7xl mx-auto flex gap-6">
          {/* Sidebar - Desktop */}
          <ForumSidebar />

          {/* Content Area */}
          <AnimatePresence mode="wait">
            <motion.div
              key={currentPage.name === 'home' 
                ? `home-${currentPage.categoryId || 'all'}-${currentPage.tag || ''}` 
                : currentPage.name === 'post' 
                ? `post-${(currentPage as { postId: string }).postId}`
                : currentPage.name === 'user'
                ? `user-${(currentPage as { userId: string }).userId}`
                : currentPage.name === 'search'
                ? `search-${(currentPage as { query: string }).query}`
                : currentPage.name === 'legal'
                ? `legal-${(currentPage as { section: string }).section}`
                : currentPage.name === 'messages'
                ? `messages-${(currentPage as { partnerId?: string }).partnerId || 'list'}`
                : currentPage.name
              }
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="flex-1 min-w-0 py-4"
            >
              {renderPage()}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* Mobile Bottom Navigation */}
      <MobileBottomNav />

      {/* Footer */}
      <ForumFooter />

      {/* Back to Top */}
      <BackToTop />

      {/* Friends Panel */}
      <FriendPanel />
    </div>
  )
}
