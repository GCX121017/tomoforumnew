'use client'

import { useReducer, useEffect, useRef, useState } from 'react'
import { useForumStore, type Comment } from '@/store/forum'
import { cn, formatTimeAgo, getLevelInfo } from '@/components/forum/helpers'
import LevelBadge from './LevelBadge'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Skeleton } from '@/components/ui/skeleton'
import { MessageSquare, Reply, Send, Trash2, CornerDownRight, Heart } from 'lucide-react'
import { EmojiPickerInline } from './EmojiPicker'
import MentionSelector, { useMention } from './MentionSelector'
import MentionHighlight from './MentionHighlight'
import { motion, AnimatePresence } from 'framer-motion'
import { toast } from 'sonner'

interface CommentSectionProps {
  postId: string
  isLocked?: boolean
}

interface CSState {
  comments: Comment[]
  loading: boolean
  newComment: string
  submitting: boolean
  replyingTo: string | null
  replyContent: string
  replySubmitting: boolean
}

type CSAction =
  | { type: 'SET_LOADING' }
  | { type: 'SET_COMMENTS'; comments: Comment[] }
  | { type: 'SET_NEW_COMMENT'; value: string }
  | { type: 'SET_SUBMITTING'; value: boolean }
  | { type: 'SET_REPLYING_TO'; id: string | null }
  | { type: 'SET_REPLY_CONTENT'; value: string }
  | { type: 'SET_REPLY_SUBMITTING'; value: boolean }

function csReducer(state: CSState, action: CSAction): CSState {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, loading: true }
    case 'SET_COMMENTS':
      return { ...state, comments: action.comments, loading: false }
    case 'SET_NEW_COMMENT':
      return { ...state, newComment: action.value }
    case 'SET_SUBMITTING':
      return { ...state, submitting: action.value }
    case 'SET_REPLYING_TO':
      return { ...state, replyingTo: action.id, replyContent: action.id === state.replyingTo ? state.replyContent : '' }
    case 'SET_REPLY_CONTENT':
      return { ...state, replyContent: action.value }
    case 'SET_REPLY_SUBMITTING':
      return { ...state, replySubmitting: action.value }
    default:
      return state
  }
}

export default function CommentSection({ postId, isLocked = false }: CommentSectionProps) {
  const { currentUser, navigate, setShowLoginDialog } = useForumStore()
  const [newCommentJustAdded, setNewCommentJustAdded] = useState<string | null>(null)
  const mainTextareaRef = useRef<HTMLTextAreaElement>(null)
  const replyTextareaRef = useRef<HTMLTextAreaElement>(null)

  const [state, dispatch] = useReducer(csReducer, {
    comments: [],
    loading: true,
    newComment: '',
    submitting: false,
    replyingTo: null,
    replyContent: '',
    replySubmitting: false,
  })

  // Main comment @mention
  const mainMention = useMention(mainTextareaRef, (friend) => {
    const textarea = mainTextareaRef.current
    if (!textarea) return
    // Read from DOM to avoid stale closure
    const value = textarea.value
    const cursorPos = textarea.selectionStart
    let searchStart = cursorPos - 1
    while (searchStart >= 0 && value[searchStart] !== ' ' && value[searchStart] !== '\n') searchStart--
    const before = value.substring(0, searchStart + 1)
    const after = value.substring(cursorPos)
    dispatch({ type: 'SET_NEW_COMMENT', value: `${before}@${friend.username} ${after}` })
  })

  // Reply @mention
  const replyMention = useMention(replyTextareaRef, (friend) => {
    const textarea = replyTextareaRef.current
    if (!textarea) return
    const value = textarea.value
    const cursorPos = textarea.selectionStart
    let searchStart = cursorPos - 1
    while (searchStart >= 0 && value[searchStart] !== ' ' && value[searchStart] !== '\n') searchStart--
    const before = value.substring(0, searchStart + 1)
    const after = value.substring(cursorPos)
    dispatch({ type: 'SET_REPLY_CONTENT', value: `${before}@${friend.username} ${after}` })
  })

  useEffect(() => {
    let cancelled = false
    dispatch({ type: 'SET_LOADING' })
    ;(async () => {
      try {
        const userIdParam = currentUser ? `&userId=${currentUser.id}` : ''
        const res = await fetch(`/api/comments?postId=${postId}${userIdParam}`)
        if (!cancelled && res.ok) {
          const data = await res.json()
          dispatch({ type: 'SET_COMMENTS', comments: data || [] })
        }
      } catch { /* ignore */ }
      if (cancelled) dispatch({ type: 'SET_COMMENTS', comments: [] })
    })()
    return () => { cancelled = true }
  }, [postId, currentUser])

  const fetchComments = async () => {
    try {
      const userIdParam = currentUser ? `&userId=${currentUser.id}` : ''
      const res = await fetch(`/api/comments?postId=${postId}${userIdParam}`)
      if (res.ok) {
        const data = await res.json()
        dispatch({ type: 'SET_COMMENTS', comments: data || [] })
      }
    } catch { /* ignore */ }
  }

  const handleSubmitComment = async () => {
    if (!currentUser || !state.newComment.trim()) return
    dispatch({ type: 'SET_SUBMITTING', value: true })
    try {
      const res = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: state.newComment.trim(),
          postId,
          authorId: currentUser.id,
        }),
      })
      if (res.ok) {
        dispatch({ type: 'SET_NEW_COMMENT', value: '' })
        const newId = (await res.json()).id
        setNewCommentJustAdded(newId)
        setTimeout(() => setNewCommentJustAdded(null), 1000)
        await fetchComments()
        toast.success('Comment posted')
      }
    } catch { /* ignore */ }
    dispatch({ type: 'SET_SUBMITTING', value: false })
  }

  const handleSubmitReply = async (parentId: string) => {
    if (!currentUser || !state.replyContent.trim()) return
    dispatch({ type: 'SET_REPLY_SUBMITTING', value: true })
    try {
      const res = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: state.replyContent.trim(),
          postId,
          authorId: currentUser.id,
          parentId,
        }),
      })
      if (res.ok) {
        dispatch({ type: 'SET_REPLYING_TO', id: null })
        const newId = (await res.json()).id
        setNewCommentJustAdded(newId)
        setTimeout(() => setNewCommentJustAdded(null), 1000)
        await fetchComments()
        toast.success('Reply posted')
      }
    } catch { /* ignore */ }
    dispatch({ type: 'SET_REPLY_SUBMITTING', value: false })
  }

  const handleDeleteComment = async (commentId: string) => {
    if (!currentUser) return
    try {
      const res = await fetch(`/api/comments/${commentId}`, {
        method: 'DELETE',
      })
      if (res.ok) {
        await fetchComments()
        toast.success('Comment deleted')
      }
    } catch { /* ignore */ }
  }

  const totalCommentCount = state.comments.reduce(
    (sum, c) => sum + 1 + (c.replies?.length || 0),
    0
  )

  return (
    <div className="border-t border-gray-100 dark:border-gray-800 px-4 pt-6 pb-8">
      {/* Header */}
      <div className="flex items-center gap-2 mb-5">
        <MessageSquare className="size-5 text-gray-400" />
        <h2 className="text-base font-semibold text-gray-900 dark:text-gray-100">
          Comments ({totalCommentCount})
        </h2>
      </div>

      {/* Main comment input */}
      {!isLocked && (
        <div className="mb-6">
          {!currentUser ? (
            <div
              onClick={() => {
                setShowLoginDialog(true)
              }}
              className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 text-center text-sm text-gray-400 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors border border-gray-100 dark:border-gray-700"
            >
              Login to post a comment
            </div>
          ) : (
            <div className="space-y-2">
              <div className="relative">
                <Textarea
                  ref={mainTextareaRef}
                  placeholder="Write your comment... (type @ to mention friends)"
                  value={state.newComment}
                  onChange={(e) => {
                    dispatch({ type: 'SET_NEW_COMMENT', value: e.target.value })
                    mainMention.handleChange(e)
                  }}
                  className="min-h-24 resize-none bg-gray-50 border-gray-200 focus-visible:bg-white dark:bg-gray-800 dark:border-gray-700 dark:text-gray-100 dark:placeholder-gray-500 dark:focus-visible:bg-gray-800"
                />
                {mainMention.selectorProps && (
                  <MentionSelector {...mainMention.selectorProps} />
                )}
              </div>
              <div className="flex items-center justify-end gap-1">
                <EmojiPickerInline
                  onSelect={(emoji) => dispatch({ type: 'SET_NEW_COMMENT', value: state.newComment + emoji })}
                />
                <Button
                  size="sm"
                  onClick={handleSubmitComment}
                  disabled={!state.newComment.trim() || state.submitting}
                  className="bg-gray-900 hover:bg-gray-800 text-white"
                >
                  {state.submitting ? (
                    <span className="flex items-center gap-1">
                      <span className="size-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Sending
                    </span>
                  ) : (
                    <span className="flex items-center gap-1">
                      <Send className="size-3" />
                      Post Comment
                    </span>
                  )}
                </Button>
              </div>
            </div>
          )}
        </div>
      )}

      {isLocked && (
        <div className="mb-6 bg-gray-50 dark:bg-gray-800 rounded-lg p-3 text-center text-sm text-gray-400 border border-gray-100 dark:border-gray-700">
          This post is locked, comments are disabled
        </div>
      )}

      {/* Comments list */}
      {state.loading ? (
        <div className="space-y-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="flex gap-3">
              <Skeleton className="size-8 rounded-full shrink-0" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-3 w-24" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-3 w-16" />
              </div>
            </div>
          ))}
        </div>
      ) : state.comments.length === 0 ? (
        <div className="text-center py-8 text-gray-400 text-sm">
          No comments yet, be the first to share your thoughts
        </div>
      ) : (
        <div className="space-y-1">
          {state.comments.map((comment, index) => (
            <motion.div
              key={comment.id}
              initial={comment.id === newCommentJustAdded ? { opacity: 0, y: 10 } : { opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: comment.id === newCommentJustAdded ? 0.4 : 0.2, delay: comment.id === newCommentJustAdded ? 0 : index * 0.05 }}
              className="group"
            >
              <CommentItem
                comment={comment}
                currentUser={currentUser}
                replyingTo={state.replyingTo}
                onReplyClick={(id) => dispatch({ type: 'SET_REPLYING_TO', id: state.replyingTo === id ? null : id })}
                replySubmitting={state.replySubmitting}
                onDelete={() => handleDeleteComment(comment.id)}
                onUserClick={(userId) => navigate({ name: 'user', userId })}
              />

              {/* Nested replies */}
              {comment.replies && comment.replies.length > 0 && (
                <div className="ml-10 sm:ml-12 border-l-2 border-gray-100 dark:border-l-gray-700 pl-4 mt-1 space-y-1">
                  {comment.replies.map((reply) => (
                    <motion.div
                      key={reply.id}
                      initial={reply.id === newCommentJustAdded ? { opacity: 0, y: 10 } : { opacity: 0 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: reply.id === newCommentJustAdded ? 0.4 : 0.2 }}
                    >
                      <CommentItem
                        comment={reply}
                        currentUser={currentUser}
                        isReply
                        onDelete={() => handleDeleteComment(reply.id)}
                        onUserClick={(userId) => navigate({ name: 'user', userId })}
                      />
                    </motion.div>
                  ))}
                </div>
              )}

              {/* Reply input */}
              <AnimatePresence>
                {state.replyingTo === comment.id && !isLocked && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="ml-10 sm:ml-12 mt-2 overflow-hidden"
                  >
                    <div className="flex items-start gap-2">
                      <CornerDownRight className="size-4 text-gray-300 dark:text-gray-600 mt-2.5 shrink-0" />
                      <div className="flex-1">
                        <div className="relative">
                          <Textarea
                            ref={replyTextareaRef}
                            placeholder={`Reply to ${comment.author?.username}... (type @ to mention friends)`}
                            value={state.replyContent}
                            onChange={(e) => {
                              dispatch({ type: 'SET_REPLY_CONTENT', value: e.target.value })
                              replyMention.handleChange(e)
                            }}
                            className="min-h-20 resize-none bg-gray-50 border-gray-200 text-sm dark:bg-gray-800 dark:border-gray-700 dark:text-gray-100 dark:placeholder-gray-500"
                            autoFocus
                          />
                          {replyMention.selectorProps && (
                            <MentionSelector {...replyMention.selectorProps} />
                          )}
                        </div>
                        <div className="flex items-center justify-end gap-1 mt-2">
                          <EmojiPickerInline
                            onSelect={(emoji) => dispatch({ type: 'SET_REPLY_CONTENT', value: state.replyContent + emoji })}
                          />
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              dispatch({ type: 'SET_REPLYING_TO', id: null })
                              dispatch({ type: 'SET_REPLY_CONTENT', value: '' })
                            }}
                            className="text-xs h-7"
                          >
                            Cancel
                          </Button>
                          <Button
                            size="sm"
                            onClick={() => handleSubmitReply(comment.id)}
                            disabled={!state.replyContent.trim() || state.replySubmitting}
                            className="bg-gray-900 hover:bg-gray-800 text-white text-xs h-7"
                          >
                            Reply
                          </Button>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  )
}

interface CommentItemProps {
  comment: Comment
  currentUser: { id: string } | null
  isReply?: boolean
  replyingTo?: string | null
  onReplyClick?: (id: string) => void
  replySubmitting?: boolean
  onDelete?: () => void
  onUserClick: (userId: string) => void
}

function CommentItem({
  comment,
  currentUser,
  isReply = false,
  replyingTo,
  onReplyClick,
  replySubmitting,
  onDelete,
  onUserClick,
}: CommentItemProps) {
  const isAuthor = currentUser && currentUser.id === comment.authorId
  const [liked, setLiked] = useState(!!(comment as any).commentLiked)
  const [likeCount, setLikeCount] = useState((comment as any).likeCount || 0)
  const [likeAnimating, setLikeAnimating] = useState(false)

  const handleLike = async () => {
    if (!currentUser) return
    try {
      const res = await fetch(`/api/comments/${comment.id}/like`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id }),
      })
      if (res.ok) {
        const data = await res.json()
        setLiked(data.liked)
        setLikeCount(data.likeCount)
      }
    } catch { /* ignore */ }
    setLikeAnimating(true)
    setTimeout(() => setLikeAnimating(false), 300)
  }

  return (
    <div className={cn(
      'flex gap-2.5 py-3',
      !isReply && 'border-b border-gray-50 dark:border-gray-800'
    )}>
      <button onClick={() => onUserClick(comment.authorId)} className="shrink-0">
        <div className="relative">
          <Avatar className={cn(isReply ? 'size-6' : 'size-8')}>
            <AvatarImage src={comment.author?.avatar} alt={comment.author?.username} />
            <AvatarFallback className={cn('bg-gray-100 dark:bg-gray-800', isReply ? 'text-[10px]' : 'text-xs')}>
              {comment.author?.username?.charAt(0) || '?'}
            </AvatarFallback>
          </Avatar>
          {!isReply && (() => {
            const level = getLevelInfo(comment.author?.points ?? 0)
            return (
              <span className="absolute -bottom-0.5 -right-0.5 size-4 rounded-full bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-[10px] flex items-center justify-center shadow-sm leading-none">
                {level.icon}
              </span>
            )
          })()}
        </div>
      </button>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <button
            onClick={() => onUserClick(comment.authorId)}
            className="text-sm font-medium text-gray-800 dark:text-gray-200 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
          >
            {comment.author?.username}
          </button>
          <LevelBadge
            level={comment.author?.level ?? 0}
            points={comment.author?.points ?? 0}
            role={comment.author?.role}
            size="sm"
          />
          <span className="text-xs text-gray-400">
            {formatTimeAgo(comment.createdAt)}
          </span>
        </div>

        <MentionHighlight
          text={comment.content}
          className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed break-words"
        />

        <div className="flex items-center gap-3 mt-1.5">
          {/* Like button */}
          <motion.button
            onClick={handleLike}
            animate={likeAnimating ? { scale: [1, 1.25, 1] } : {}}
            transition={{ duration: 0.25 }}
            className={cn(
              'text-xs flex items-center gap-1 transition-colors',
              liked
                ? 'text-gray-900 dark:text-gray-100'
                : 'text-gray-400 hover:text-gray-600 dark:hover:text-gray-300',
              !currentUser && 'opacity-50 cursor-not-allowed'
            )}
          >
            <Heart className={cn('size-3', liked && 'fill-current')} />
            {likeCount > 0 ? likeCount : 'Like'}
          </motion.button>

          {!isReply && onReplyClick && (
            <button
              onClick={() => onReplyClick(comment.id)}
              className="text-xs text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors flex items-center gap-1"
            >
              <Reply className="size-3" />
              Reply
            </button>
          )}
          {isAuthor && onDelete && (
            <button
              onClick={onDelete}
              className="text-xs text-gray-300 dark:text-gray-600 hover:text-red-500 transition-colors flex items-center gap-1"
            >
              <Trash2 className="size-3" />
              Delete
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
