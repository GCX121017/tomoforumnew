'use client'

import { useState, useEffect, useRef } from 'react'
import { useForumStore } from '@/store/forum'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Separator } from '@/components/ui/separator'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog'
import { toast } from 'sonner'
import { Loader2, Camera, Check, Sparkles, Shuffle, Palette, Upload } from 'lucide-react'
import { PRESET_AVATARS, generateAvatarUrl, generateRandomColor } from '@/lib/levels'
import { cn } from '@/components/forum/helpers'
import { motion } from 'framer-motion'

// Preset color options for custom avatar generation
const PRESET_COLORS = [
  { name: 'Gray', value: '#6b7280' },
  { name: 'Blue', value: '#3b82f6' },
  { name: 'Green', value: '#22c55e' },
  { name: 'Orange', value: '#f97316' },
  { name: 'Red', value: '#ef4444' },
  { name: 'Purple', value: '#a855f7' },
  { name: 'Teal', value: '#14b8a6' },
  { name: 'Pink', value: '#ec4899' },
]

interface EditProfileProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export default function EditProfile({ open, onOpenChange }: EditProfileProps) {
  const { currentUser, setCurrentUser } = useForumStore()
  const [bio, setBio] = useState('')
  const [avatarUrl, setAvatarUrl] = useState('')
  const [saving, setSaving] = useState(false)

  // Avatar picker state
  const [avatarPickerOpen, setAvatarPickerOpen] = useState(false)
  const [avatarType, setAvatarType] = useState<'preset' | 'generated' | 'uploaded'>('preset')
  const [selectedAvatarId, setSelectedAvatarId] = useState(PRESET_AVATARS[0].id)
  const [selectedAvatarUrl, setSelectedAvatarUrl] = useState(PRESET_AVATARS[0].url)
  const [selectedColor, setSelectedColor] = useState('#6b7280')
  const customColorInputRef = useRef<HTMLInputElement>(null)
  const avatarFileInputRef = useRef<HTMLInputElement>(null)
  const [uploadingAvatar, setUploadingAvatar] = useState(false)

  useEffect(() => {
    if (open && currentUser) {
      setBio(currentUser.bio || '')
      setAvatarUrl(currentUser.avatar || '')
      // Try to detect current avatar type
      const isPreset = PRESET_AVATARS.some(p => p.url === currentUser.avatar)
      const isUploaded = currentUser.avatar && !PRESET_AVATARS.some(p => p.url === currentUser.avatar) && !currentUser.avatar.includes('ui-avatars.com') && !currentUser.avatar.includes('dicebear.com')
      if (isPreset) {
        setAvatarType('preset')
        const match = PRESET_AVATARS.find(p => p.url === currentUser.avatar)
        if (match) {
          setSelectedAvatarId(match.id)
          setSelectedAvatarUrl(match.url)
        }
      } else if (isUploaded) {
        setAvatarType('uploaded')
        setSelectedAvatarUrl(currentUser.avatar || '')
      } else {
        setAvatarType('generated')
        setSelectedAvatarUrl(currentUser.avatar || '')
      }
    }
  }, [open, currentUser])

  const openAvatarPicker = () => {
    setAvatarPickerOpen(true)
  }

  const handleAvatarConfirm = () => {
    if (avatarType === 'preset' || avatarType === 'uploaded') {
      setAvatarUrl(selectedAvatarUrl)
    } else {
      const url = generateAvatarUrl(currentUser?.username || '', selectedColor)
      setAvatarUrl(url)
      setSelectedAvatarUrl(url)
    }
    setAvatarPickerOpen(false)
  }

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file || !currentUser) return
    if (file.size > 2 * 1024 * 1024) {
      toast.error('Avatar size cannot exceed 2MB')
      return
    }
    setUploadingAvatar(true)
    try {
      const formData = new FormData()
      formData.append('avatar', file)
      formData.append('userId', currentUser.id)
      const res = await fetch('/api/upload/avatar', {
        method: 'POST',
        body: formData,
      })
      if (res.ok) {
        const data = await res.json()
        setSelectedAvatarUrl(data.url)
        setAvatarType('uploaded')
        toast.success('Avatar uploaded')
      } else {
        const err = await res.json()
        toast.error(err.error || 'Avatar upload failed')
      }
    } catch {
      toast.error('Avatar upload failed')
    } finally {
      setUploadingAvatar(false)
      if (avatarFileInputRef.current) avatarFileInputRef.current.value = ''
    }
  }

  const handleSave = async () => {
    if (!currentUser) return
    setSaving(true)
    try {
      const res = await fetch(`/api/users/${currentUser.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bio,
          avatar: avatarUrl,
          avatarType: avatarType,
          avatarColor: avatarType === 'generated' ? selectedColor : '',
        }),
      })

      if (res.ok) {
        const updatedUser = {
          ...currentUser,
          bio,
          avatar: avatarUrl,
          avatarType,
          avatarColor: avatarType === 'generated' ? selectedColor : '',
        }
        setCurrentUser(updatedUser)
        localStorage.setItem('forum_user', JSON.stringify(updatedUser))
        toast.success('Profile updated')
        onOpenChange(false)
      } else {
        toast.error('Update failed, please try again')
      }
    } catch {
      toast.error('Network error, please try again')
    } finally {
      setSaving(false)
    }
  }

  if (!currentUser) return null

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center text-lg">Edit Profile</DialogTitle>
            <DialogDescription className="text-center text-gray-500 dark:text-gray-400">
              Update your personal information
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-5 pt-2">
            {/* Avatar - clickable to open picker */}
            <div className="flex flex-col items-center gap-3">
              <button
                type="button"
                onClick={openAvatarPicker}
                className="relative group cursor-pointer"
              >
                <Avatar className="size-20 ring-2 ring-transparent group-hover:ring-gray-300 dark:group-hover:ring-gray-600 transition-all duration-200">
                  <AvatarImage src={avatarUrl} alt="Current avatar" />
                  <AvatarFallback className="text-2xl bg-gray-100 dark:bg-gray-800">
                    {currentUser.username.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                  <div className="size-20 rounded-full bg-black/30 flex items-center justify-center">
                    <Camera className="size-5 text-white" />
                  </div>
                </div>
              </button>
              <button
                type="button"
                onClick={openAvatarPicker}
                className="text-xs text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300 transition-colors flex items-center gap-1"
              >
                <Camera className="size-3" />
                Click to change avatar
              </button>
            </div>

            {/* Username (read-only) */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-gray-500 dark:text-gray-400">Username</label>
              <Input
                value={currentUser.username}
                disabled
                className="text-sm bg-gray-50 text-gray-500 dark:bg-gray-800 dark:text-gray-400"
              />
              <p className="text-[11px] text-gray-400 dark:text-gray-500">Username cannot be changed</p>
            </div>

            {/* Bio */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-gray-500 dark:text-gray-400">Bio</label>
              <Textarea
                placeholder="Tell us about yourself..."
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="text-sm resize-none"
                rows={3}
                maxLength={200}
              />
              <p className="text-[11px] text-gray-400 dark:text-gray-500 text-right">{bio.length}/200</p>
            </div>

            {/* Actions */}
            <div className="flex gap-3 pt-2">
              <Button
                variant="outline"
                onClick={() => onOpenChange(false)}
                className="flex-1 text-sm"
                disabled={saving}
              >
                Cancel
              </Button>
              <Button
                onClick={handleSave}
                className="flex-1 bg-gray-900 hover:bg-gray-800 text-sm"
                disabled={saving}
              >
                {saving && <Loader2 className="size-3.5 animate-spin mr-1.5" />}
                Save
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Avatar Picker Dialog */}
      <Dialog open={avatarPickerOpen} onOpenChange={setAvatarPickerOpen}>
        <DialogContent className="sm:max-w-md overflow-hidden p-0">
          <div className="px-6 pt-6 pb-0 shrink-0">
            <DialogHeader>
              <DialogTitle className="text-center text-lg">Choose Your Avatar</DialogTitle>
              <DialogDescription className="text-center text-gray-500 dark:text-gray-400">
                Pick an avatar you like, or upload your own photo
              </DialogDescription>
            </DialogHeader>
          </div>

          <div className="px-6 pb-6 pt-4 space-y-5 max-h-[70vh] overflow-y-auto scrollbar-thin">
            {/* Upload Avatar Section */}
            <div>
              <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3 flex items-center gap-1.5">
                <Upload className="size-3.5" />
                Upload Avatar
              </p>
              <input
                ref={avatarFileInputRef}
                type="file"
                accept="image/jpeg,image/png,image/gif,image/webp,image/svg+xml"
                onChange={handleAvatarUpload}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => avatarFileInputRef.current?.click()}
                disabled={uploadingAvatar}
                className={cn(
                  'w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl border-2 border-dashed transition-colors',
                  avatarType === 'uploaded'
                    ? 'border-gray-900 dark:border-gray-100 bg-gray-50 dark:bg-gray-800'
                    : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-800/50',
                  uploadingAvatar && 'opacity-50 cursor-not-allowed'
                )}
              >
                {uploadingAvatar ? (
                  <Loader2 className="size-4 animate-spin text-gray-400" />
                ) : avatarType === 'uploaded' ? (
                  <Check className="size-4 text-gray-900 dark:text-gray-100" />
                ) : (
                  <Upload className="size-4 text-gray-400" />
                )}
                <span className="text-sm text-gray-600 dark:text-gray-300">
                  {uploadingAvatar ? 'Uploading...' : avatarType === 'uploaded' ? 'Custom avatar selected' : 'Click to upload your own photo'}
                </span>
              </button>
              {avatarType === 'uploaded' && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-3 flex items-center gap-3 p-3 rounded-lg bg-gray-50 dark:bg-gray-800/50 border border-gray-100 dark:border-gray-800"
                >
                  <img src={selectedAvatarUrl} alt="Custom avatar preview" className="size-12 rounded-lg" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-gray-700 dark:text-gray-300">Custom Avatar</p>
                    <p className="text-[11px] text-gray-400 dark:text-gray-500 mt-0.5">Your uploaded photo will be used as your avatar</p>
                  </div>
                </motion.div>
              )}
            </div>

            <Separator />

            {/* Current avatar preview */}
            <div className="flex items-center justify-center">
              <motion.div
                key={avatarType === 'generated' ? selectedColor : selectedAvatarUrl}
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.2 }}
                className="size-16 rounded-full overflow-hidden ring-2 ring-gray-200 dark:ring-gray-700"
              >
                <img
                  src={avatarType === 'preset' || avatarType === 'uploaded' ? selectedAvatarUrl : generateAvatarUrl(currentUser.username, selectedColor)}
                  alt="Avatar preview"
                  className="w-full h-full object-cover"
                />
              </motion.div>
            </div>

            {/* Preset Avatars Grid */}
            <div>
              <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3 flex items-center gap-1.5">
                <Sparkles className="size-3.5" />
                Preset Avatars
              </p>
              <div className="grid grid-cols-4 gap-2.5">
                {PRESET_AVATARS.map((preset) => (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => {
                      setSelectedAvatarId(preset.id)
                      setSelectedAvatarUrl(preset.url)
                      setAvatarType('preset')
                    }}
                    className={cn(
                      'relative group rounded-xl p-1.5 transition-all duration-200',
                      'border-2',
                      selectedAvatarId === preset.id && avatarType === 'preset'
                        ? 'border-gray-900 dark:border-gray-100 bg-gray-50 dark:bg-gray-800 shadow-sm'
                        : 'border-transparent hover:border-gray-200 dark:hover:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800/50'
                    )}
                  >
                    <div className="relative aspect-square">
                      <img
                        src={preset.url}
                        alt={preset.name}
                        className="w-full h-full rounded-lg object-cover"
                        loading="lazy"
                      />
                      {selectedAvatarId === preset.id && avatarType === 'preset' && (
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="absolute inset-0 flex items-center justify-center bg-black/20 rounded-lg"
                        >
                          <div className="size-6 rounded-full bg-gray-900 dark:bg-gray-100 flex items-center justify-center">
                            <Check className="size-3.5 text-white dark:text-gray-900" strokeWidth={3} />
                          </div>
                        </motion.div>
                      )}
                    </div>
                    <p className="text-[10px] text-gray-400 dark:text-gray-500 text-center mt-1 truncate">
                      {preset.name}
                    </p>
                  </button>
                ))}
              </div>
            </div>

            <Separator />

            {/* Custom Avatar Section */}
            <div>
              <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3 flex items-center gap-1.5">
                <Sparkles className="size-3.5" />
                Custom Avatar
              </p>

              {/* Color picker */}
              <div className="flex items-center gap-2 flex-wrap">
                {PRESET_COLORS.map((color) => (
                  <button
                    key={color.value}
                    type="button"
                    title={color.name}
                    onClick={() => {
                      setSelectedColor(color.value)
                      setAvatarType('generated')
                    }}
                    className={cn(
                      'size-8 rounded-full transition-all duration-200',
                      'hover:scale-110 focus:outline-none',
                      avatarType === 'generated' && selectedColor === color.value
                        ? 'ring-2 ring-offset-2 ring-gray-900 dark:ring-gray-100 ring-offset-white dark:ring-offset-gray-950 scale-110'
                        : 'ring-1 ring-black/10 dark:ring-white/10'
                    )}
                    style={{ backgroundColor: color.value }}
                  />
                ))}
                {/* Custom color picker */}
                <button
                  type="button"
                  onClick={() => customColorInputRef.current?.click()}
                  className={cn(
                    'size-8 rounded-full transition-all duration-200',
                    'hover:scale-110 focus:outline-none',
                    'bg-gradient-to-br from-red-400 via-green-400 to-blue-400',
                    'flex items-center justify-center',
                    'ring-1 ring-black/10 dark:ring-white/10'
                  )}
                  title="Custom color"
                >
                  <Palette className="size-3.5 text-white drop-shadow-sm" />
                </button>
                <input
                  ref={customColorInputRef}
                  type="color"
                  value={selectedColor}
                  onChange={(e) => {
                    setSelectedColor(e.target.value)
                    setAvatarType('generated')
                  }}
                  className="sr-only"
                  aria-label="Select custom color"
                />
                <button
                  type="button"
                  onClick={() => {
                    const newColor = generateRandomColor()
                    setSelectedColor(newColor)
                    setAvatarType('generated')
                  }}
                  className="size-8 rounded-full bg-gray-100 dark:bg-gray-800 border border-dashed border-gray-300 dark:border-gray-600 flex items-center justify-center hover:bg-gray-200 dark:hover:bg-gray-700 hover:scale-110 transition-all duration-200"
                  title="Random color"
                >
                  <Shuffle className="size-3.5 text-gray-500 dark:text-gray-400" />
                </button>
              </div>

              {/* Live preview for generated avatar */}
              {avatarType === 'generated' && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-3 flex items-center gap-3 p-3 rounded-lg bg-gray-50 dark:bg-gray-800/50 border border-gray-100 dark:border-gray-800"
                >
                  <img
                    src={generateAvatarUrl(currentUser.username, selectedColor)}
                    alt="Custom avatar preview"
                    className="size-12 rounded-lg"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-gray-700 dark:text-gray-300">Preview</p>
                    <p className="text-[11px] text-gray-400 dark:text-gray-500 mt-0.5 flex items-center gap-1">
                      <span
                        className="inline-block size-3 rounded-sm"
                        style={{ backgroundColor: selectedColor }}
                      />
                      {selectedColor}
                    </p>
                  </div>
                </motion.div>
              )}
            </div>

            {/* Confirm / Cancel buttons */}
            <div className="flex gap-3 pt-2">
              <Button
                variant="outline"
                onClick={() => setAvatarPickerOpen(false)}
                className="flex-1 h-10 text-sm"
              >
                Cancel
              </Button>
              <Button
                onClick={handleAvatarConfirm}
                className="flex-1 bg-gray-900 hover:bg-gray-800 text-sm h-10"
              >
                <Check className="size-3.5 mr-1.5" />
                Confirm
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
