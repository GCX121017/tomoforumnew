'use client'

import { useState, useCallback, useRef, useEffect } from 'react'
import { Smile, Clock, Search } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { cn } from '@/lib/utils'

// Comprehensive emoji data with keyword search support
interface EmojiData {
  emoji: string
  keywords: string[]
}

const EMOJI_CATEGORIES: { name: string; icon: string; emojis: EmojiData[] }[] = [
  {
    name: 'Common',
    icon: '⭐',
    emojis: [
      { emoji: '👍', keywords: ['like', 'good', 'great', 'good', 'like', 'thumb'] },
      { emoji: '👎', keywords: ['dislike', 'bad', 'bad', 'dislike'] },
      { emoji: '❤️', keywords: ['love', 'heart', 'love', 'heart'] },
      { emoji: '😂', keywords: ['laugh', 'cry', 'happy', 'laugh', 'joy'] },
      { emoji: '😮', keywords: ['surprise', 'wow', 'oh', 'surprise'] },
      { emoji: '😢', keywords: ['cry', 'sad', 'sad', 'cry'] },
      { emoji: '🔥', keywords: ['fire', 'hot', 'hot', 'fire'] },
      { emoji: '⭐', keywords: ['star', 'star'] },
      { emoji: '🎉', keywords: ['celebrate', 'party', 'tada'] },
      { emoji: '💯', keywords: ['perfect', '100', 'perfect', 'hundred'] },
      { emoji: '✅', keywords: ['yes', 'done', 'yes', 'check'] },
      { emoji: '❌', keywords: ['wrong', 'no', 'wrong', 'x'] },
      { emoji: '🙏', keywords: ['thanks', 'pray', 'thanks', 'pray'] },
      { emoji: '💪', keywords: ['cheer', 'strength', 'strong'] },
      { emoji: '👀', keywords: ['look', 'eye', 'eye', 'look'] },
      { emoji: '🤔', keywords: ['think', 'hmm', 'think', 'hmm'] },
      { emoji: '😅', keywords: ['awkward', 'sweat', 'awkward', 'sweat'] },
      { emoji: '🥰', keywords: ['like', 'love', 'cute'] },
      { emoji: '😭', keywords: ['sob', 'cry', 'tears'] },
      { emoji: '🤝', keywords: ['cooperate', 'handshake', 'handshake'] },
      { emoji: '👏', keywords: ['clap', 'clap'] },
      { emoji: '🫡', keywords: ['salute', 'salute'] },
      { emoji: '💎', keywords: ['diamond', 'diamond'] },
      { emoji: '🚀', keywords: ['rocket', 'rocket', 'launch'] },
      { emoji: '😊', keywords: ['smile', 'smile'] },
      { emoji: '🤣', keywords: ['rofl', 'rofl', 'laughing'] },
      { emoji: '😘', keywords: ['kiss', 'kiss'] },
      { emoji: '🥺', keywords: ['pity', 'please', 'please', 'puppy'] },
      { emoji: '😎', keywords: ['cool', 'cool', 'sunglasses'] },
      { emoji: '🤩', keywords: ['amazing', 'amazing', 'star'] },
    ],
  },
  {
    name: 'Smileys',
    icon: '😀',
    emojis: [
      { emoji: '😀', keywords: ['laugh', 'happy', 'grin'] },
      { emoji: '😃', keywords: ['happy', 'smile'] },
      { emoji: '😄', keywords: ['laugh', 'happy'] },
      { emoji: '😁', keywords: ['laugh', 'beaming'] },
      { emoji: '😆', keywords: ['laughing', 'laughing'] },
      { emoji: '😅', keywords: ['awkward', 'sweat'] },
      { emoji: '🤣', keywords: ['rofl', 'rofl'] },
      { emoji: '😂', keywords: ['rofl', 'joy'] },
      { emoji: '🙂', keywords: ['smile', 'slight'] },
      { emoji: '🙃', keywords: ['upside down', 'upside'] },
      { emoji: '😉', keywords: ['wink', 'wink'] },
      { emoji: '😊', keywords: ['smile', 'blush'] },
      { emoji: '😇', keywords: ['angel', 'halo', 'innocent'] },
      { emoji: '🥰', keywords: ['love', 'hearts', 'adoration'] },
      { emoji: '😍', keywords: ['love struck', 'love', 'eyes'] },
      { emoji: '🤩', keywords: ['star eyes', 'star'] },
      { emoji: '😘', keywords: ['blow kiss', 'kiss'] },
      { emoji: '😋', keywords: ['yummy', 'yummy', 'delicious'] },
      { emoji: '😛', keywords: ['tongue out', 'tongue'] },
      { emoji: '😜', keywords: ['playful', 'wink', 'tongue'] },
      { emoji: '🤪', keywords: ['crazy', 'zany', 'crazy'] },
      { emoji: '😝', keywords: ['closed eyes', 'squint'] },
      { emoji: '🤑', keywords: ['money', 'money', 'rich'] },
      { emoji: '🤗', keywords: ['hug', 'hug'] },
      { emoji: '🤭', keywords: ['cover mouth', 'hand', 'mouth'] },
      { emoji: '🤫', keywords: ['shh', 'quiet', 'shh'] },
      { emoji: '🤔', keywords: ['think', 'think'] },
      { emoji: '🤐', keywords: ['zip it', 'zipper', 'mouth'] },
      { emoji: '🤨', keywords: ['doubt', 'raised', 'brow'] },
      { emoji: '😐', keywords: ['speechless', 'neutral'] },
      { emoji: '😑', keywords: ['expressionless', 'expressionless'] },
      { emoji: '😶', keywords: ['silent', 'silent', 'mute'] },
      { emoji: '😏', keywords: ['smug', 'smirk'] },
      { emoji: '😒', keywords: ['unhappy', 'unamused'] },
      { emoji: '🙄', keywords: ['eye roll', 'eye', 'roll'] },
      { emoji: '😬', keywords: ['awkward', 'grimace'] },
      { emoji: '😮‍💨', keywords: ['sigh', 'exhale', 'sigh'] },
      { emoji: '🤥', keywords: ['lying', 'liar', 'pinocchio'] },
      { emoji: '🫠', keywords: ['melting', 'melting'] },
      { emoji: '😌', keywords: ['relieved', 'relieved'] },
      { emoji: '😔', keywords: ['depressed', 'sad', 'pensive'] },
      { emoji: '😪', keywords: ['sleepy', 'sleepy'] },
      { emoji: '🤤', keywords: ['drooling', 'drool'] },
      { emoji: '😴', keywords: ['sleep', 'sleep', 'zzz'] },
      { emoji: '😷', keywords: ['mask', 'mask', 'sick'] },
      { emoji: '🤒', keywords: ['fever', 'thermometer', 'sick'] },
      { emoji: '🤕', keywords: ['injured', 'bandage', 'hurt'] },
      { emoji: '🤢', keywords: ['nausea', 'nausea', 'sick'] },
      { emoji: '🤮', keywords: ['vomit', 'vomit'] },
      { emoji: '🥵', keywords: ['hot', 'hot'] },
      { emoji: '🥶', keywords: ['cold', 'cold', 'freezing'] },
      { emoji: '🥴', keywords: ['drunk', 'drunk', 'woozy'] },
      { emoji: '😵', keywords: ['dizzy', 'dizzy'] },
      { emoji: '🤯', keywords: ['explosion', 'mind', 'blown'] },
      { emoji: '🤠', keywords: ['cowboy', 'cowboy'] },
      { emoji: '🥳', keywords: ['party', 'party', 'celebrate'] },
      { emoji: '🥸', keywords: ['disguise', 'disguise'] },
      { emoji: '😎', keywords: ['cool', 'cool', 'sunglasses'] },
      { emoji: '🤓', keywords: ['nerd', 'nerd', 'glasses'] },
      { emoji: '🧐', keywords: ['inspect', 'monocle', 'inspect'] },
      { emoji: '😕', keywords: ['confused', 'confused'] },
      { emoji: '🫤', keywords: ['dissatisfied', 'diagonal', 'mouth'] },
      { emoji: '😟', keywords: ['worried', 'worried'] },
      { emoji: '🙁', keywords: ['unhappy', 'frown'] },
      { emoji: '😮', keywords: ['surprise', 'surprised', 'oh'] },
      { emoji: '😯', keywords: ['startled', 'hushed'] },
      { emoji: '😲', keywords: ['shocked', 'astonished'] },
      { emoji: '😳', keywords: ['blushing', 'flushed', 'embarrassed'] },
      { emoji: '🥺', keywords: ['pity', ' pleading', 'eyes'] },
      { emoji: '🥹', keywords: ['touched', 'tears', 'holding'] },
      { emoji: '😢', keywords: ['cry', 'cry', 'sad'] },
      { emoji: '😭', keywords: ['sob', 'sob', 'bawl'] },
      { emoji: '😱', keywords: ['fear', 'scream', 'fear'] },
      { emoji: '😖', keywords: ['troubled', 'confounded'] },
      { emoji: '😣', keywords: ['persevere', 'persevere'] },
      { emoji: '😞', keywords: ['disappointed', 'disappointed'] },
      { emoji: '😓', keywords: ['sweat', 'cold', 'sweat'] },
      { emoji: '😩', keywords: ['exhausted', 'weary', 'tired'] },
      { emoji: '😫', keywords: ['tired', 'tired', 'dizzy'] },
      { emoji: '🥱', keywords: ['yawning', 'yawn'] },
      { emoji: '😤', keywords: ['angry', 'huff', 'angry', 'steam'] },
      { emoji: '😡', keywords: ['rage', 'rage', 'angry'] },
      { emoji: '😠', keywords: ['angry', 'angry'] },
      { emoji: '🤬', keywords: ['swear', 'swear', 'curse'] },
      { emoji: '😈', keywords: ['devil', 'devil', 'evil'] },
      { emoji: '👿', keywords: ['devil', 'imp'] },
      { emoji: '💀', keywords: ['skull', 'skull', 'dead'] },
      { emoji: '☠️', keywords: ['skull', 'skull'] },
      { emoji: '💩', keywords: ['poop', 'poop'] },
      { emoji: '🤡', keywords: ['clown', 'clown'] },
      { emoji: '👹', keywords: ['ogre', 'ogre'] },
      { emoji: '👻', keywords: ['ghost', 'ghost'] },
      { emoji: '👽', keywords: ['alien', 'alien'] },
      { emoji: '🤖', keywords: ['robot', 'robot'] },
      { emoji: '😺', keywords: ['cat smile', 'cat', 'smile'] },
      { emoji: '😸', keywords: ['cat smile', 'cat', 'grin'] },
      { emoji: '😹', keywords: ['cat', 'joy', 'laughing'] },
      { emoji: '😻', keywords: ['cat love', 'cat', 'heart'] },
      { emoji: '🙀', keywords: ['cat surprise', 'cat', 'weary'] },
      { emoji: '😿', keywords: ['cat cry', 'cat', 'cry'] },
      { emoji: '😾', keywords: ['cat angry', 'cat', 'angry'] },
    ],
  },
  {
    name: 'Gestures',
    icon: '👋',
    emojis: [
      { emoji: '👋', keywords: ['wave', 'wave', 'bye'] },
      { emoji: '🤚', keywords: ['hand', 'hand', 'back'] },
      { emoji: '✋', keywords: ['raise hand', 'hand', 'raise'] },
      { emoji: '🖖', keywords: ['vulcan', 'spock', 'vulcan'] },
      { emoji: '👌', keywords: ['OK', 'good', 'perfect'] },
      { emoji: '🤌', keywords: ['pinch', 'pinch', 'italian'] },
      { emoji: '🤏', keywords: ['a little', 'pinching'] },
      { emoji: '✌️', keywords: ['peace', 'peace', 'victory'] },
      { emoji: '🤞', keywords: ['crossed', 'crossed', 'luck'] },
      { emoji: '🫰', keywords: ['finger heart', 'hand', 'heart'] },
      { emoji: '🤟', keywords: ['love you', 'love', 'you'] },
      { emoji: '🤘', keywords: ['rock', 'rock'] },
      { emoji: '🤙', keywords: ['call', 'call', 'shaka'] },
      { emoji: '👈', keywords: ['left', 'left', 'point'] },
      { emoji: '👉', keywords: ['right', 'right', 'point'] },
      { emoji: '👆', keywords: ['up', 'up', 'point'] },
      { emoji: '🖕', keywords: ['middle finger', 'middle', 'finger'] },
      { emoji: '👇', keywords: ['down', 'down', 'point'] },
      { emoji: '☝️', keywords: ['point at', 'index', 'up'] },
      { emoji: '🫵', keywords: ['point at you', 'point', 'you'] },
      { emoji: '👍', keywords: ['like', 'thumbs', 'up'] },
      { emoji: '👎', keywords: ['dislike', 'thumbs', 'down'] },
      { emoji: '✊', keywords: ['fist', 'fist', 'punch'] },
      { emoji: '👊', keywords: ['punch', 'fist', 'bump'] },
      { emoji: '🤛', keywords: ['left fist', 'fist', 'left'] },
      { emoji: '🤜', keywords: ['right fist', 'fist', 'right'] },
      { emoji: '👏', keywords: ['clap', 'clap'] },
      { emoji: '🙌', keywords: ['cheer', 'raise', 'hands'] },
      { emoji: '🫶', keywords: ['finger heart', 'heart', 'hands'] },
      { emoji: '👐', keywords: ['open', 'open', 'hands'] },
      { emoji: '🤲', keywords: ['palms together', 'palms', 'up'] },
      { emoji: '🤝', keywords: ['handshake', 'handshake'] },
      { emoji: '🙏', keywords: ['pray', 'pray', 'thanks'] },
      { emoji: '✍️', keywords: ['write', 'write'] },
      { emoji: '💅', keywords: ['nail polish', 'nail', 'polish'] },
      { emoji: '🤳', keywords: ['selfie', 'selfie'] },
      { emoji: '💪', keywords: ['cheer', 'muscle', 'strong'] },
      { emoji: '🦾', keywords: ['mechanical arm', 'arm'] },
      { emoji: '🦿', keywords: ['mechanical leg', 'leg'] },
      { emoji: '🦵', keywords: ['leg', 'leg'] },
      { emoji: '🦶', keywords: ['foot', 'foot'] },
      { emoji: '👂', keywords: ['ear', 'ear'] },
      { emoji: '🦻', keywords: ['hearing aid', 'ear'] },
      { emoji: '👃', keywords: ['nose', 'nose'] },
      { emoji: '🧠', keywords: ['brain', 'brain'] },
      { emoji: '🫀', keywords: ['heart organ', 'heart'] },
      { emoji: '🫁', keywords: ['lungs', 'lungs'] },
      { emoji: '🦷', keywords: ['tooth', 'tooth'] },
      { emoji: '🦴', keywords: ['bone', 'bone'] },
      { emoji: '👀', keywords: ['eyes', 'eyes', 'look'] },
      { emoji: '👁️', keywords: ['eye', 'eye'] },
      { emoji: '👅', keywords: ['tongue', 'tongue'] },
      { emoji: '👄', keywords: ['lips', 'lips', 'mouth'] },
      { emoji: '🫦', keywords: ['biting lip', 'biting', 'lip'] },
    ],
  },
  {
    name: 'Hearts',
    icon: '❤️',
    emojis: [
      { emoji: '❤️', keywords: ['red heart', 'love', 'red'] },
      { emoji: '🧡', keywords: ['orange heart', 'orange'] },
      { emoji: '💛', keywords: ['yellow heart', 'yellow'] },
      { emoji: '💚', keywords: ['green heart', 'green'] },
      { emoji: '💙', keywords: ['blue heart', 'blue'] },
      { emoji: '💜', keywords: ['purple heart', 'purple'] },
      { emoji: '🖤', keywords: ['black heart', 'black'] },
      { emoji: '🤍', keywords: ['white heart', 'white'] },
      { emoji: '🤎', keywords: ['brown heart', 'brown'] },
      { emoji: '💔', keywords: ['broken heart', 'broken', 'heart'] },
      { emoji: '❣️', keywords: ['heart exclamation', 'heart', 'exclamation'] },
      { emoji: '💕', keywords: ['two hearts', 'hearts'] },
      { emoji: '💞', keywords: ['revolving hearts', 'revolving', 'hearts'] },
      { emoji: '💓', keywords: ['beating heart', 'heartbeat', 'growing'] },
      { emoji: '💗', keywords: ['growing heart', 'growing', 'heart'] },
      { emoji: '💖', keywords: ['sparkling heart', 'sparkling', 'heart'] },
      { emoji: '💘', keywords: ['cupid arrow', 'cupid', 'arrow'] },
      { emoji: '💝', keywords: ['gift heart', 'gift', 'heart'] },
      { emoji: '💟', keywords: ['decoration heart', 'heart', 'decoration'] },
      { emoji: '♥️', keywords: ['heart', 'suit', 'heart'] },
      { emoji: '🫶', keywords: ['finger heart', 'heart', 'hands'] },
      { emoji: '💌', keywords: ['love letter', 'love', 'letter'] },
      { emoji: '💋', keywords: ['lipstick mark', 'kiss', 'mark'] },
      { emoji: '💯', keywords: ['perfect', '100', 'perfect'] },
      { emoji: '💢', keywords: ['rage', 'anger'] },
      { emoji: '💥', keywords: ['explosion', 'boom', 'collision'] },
      { emoji: '💫', keywords: ['dizzy star', 'dizzy', 'star'] },
      { emoji: '💦', keywords: ['droplet', 'sweat', 'drops'] },
      { emoji: '💨', keywords: ['dash', 'dash', 'wind'] },
      { emoji: '🕳️', keywords: ['hole', 'hole'] },
      { emoji: '💤', keywords: ['sleep', 'sleep', 'zzz'] },
      { emoji: '💬', keywords: ['speech', 'speech', 'bubble'] },
      { emoji: '🗨️', keywords: ['thought bubble', 'thought', 'bubble'] },
      { emoji: '🗯️', keywords: ['anger bubble', 'anger', 'bubble'] },
      { emoji: '💭', keywords: ['thought', 'thought', 'cloud'] },
    ],
  },
  {
    name: 'Animals',
    icon: '🐱',
    emojis: [
      { emoji: '🐱', keywords: ['cat', 'cat'] },
      { emoji: '🐶', keywords: ['dog', 'dog'] },
      { emoji: '🐭', keywords: ['mouse', 'mouse'] },
      { emoji: '🐹', keywords: ['hamster', 'hamster'] },
      { emoji: '🐰', keywords: ['rabbit', 'rabbit', 'bunny'] },
      { emoji: '🦊', keywords: ['fox', 'fox'] },
      { emoji: '🐻', keywords: ['bear', 'bear'] },
      { emoji: '🐼', keywords: ['panda', 'panda'] },
      { emoji: '🐨', keywords: ['koala', 'koala'] },
      { emoji: '🐯', keywords: ['tiger', 'tiger'] },
      { emoji: '🦁', keywords: ['lion', 'lion'] },
      { emoji: '🐮', keywords: ['cow', 'cow'] },
      { emoji: '🐷', keywords: ['pig', 'pig'] },
      { emoji: '🐸', keywords: ['frog', 'frog'] },
      { emoji: '🐵', keywords: ['monkey', 'monkey'] },
      { emoji: '🐔', keywords: ['chicken', 'chicken'] },
      { emoji: '🐧', keywords: ['penguin', 'penguin'] },
      { emoji: '🐦', keywords: ['bird', 'bird'] },
      { emoji: '🦅', keywords: ['eagle', 'eagle'] },
      { emoji: '🦆', keywords: ['duck', 'duck'] },
      { emoji: '🦉', keywords: ['owl', 'owl'] },
      { emoji: '🦇', keywords: ['bat', 'bat'] },
      { emoji: '🐺', keywords: ['wolf', 'wolf'] },
      { emoji: '🐗', keywords: ['boar', 'boar'] },
      { emoji: '🐴', keywords: ['horse', 'horse'] },
      { emoji: '🦄', keywords: ['unicorn', 'unicorn'] },
      { emoji: '🐝', keywords: ['bee', 'bee'] },
      { emoji: '🪱', keywords: ['bug', 'worm'] },
      { emoji: '🐛', keywords: ['caterpillar', 'bug', 'caterpillar'] },
      { emoji: '🦋', keywords: ['butterfly', 'butterfly'] },
      { emoji: '🐌', keywords: ['snail', 'snail'] },
      { emoji: '🐞', keywords: ['ladybug', 'ladybug'] },
      { emoji: '🐜', keywords: ['ant', 'ant'] },
      { emoji: '🪰', keywords: ['fly', 'fly'] },
      { emoji: '🪲', keywords: ['beetle', 'beetle'] },
      { emoji: '🪳', keywords: ['cockroach', 'cockroach'] },
      { emoji: '🦟', keywords: ['mosquito', 'mosquito'] },
      { emoji: '🦗', keywords: ['cricket', 'cricket'] },
      { emoji: '🕷️', keywords: ['spider', 'spider'] },
      { emoji: '🦂', keywords: ['scorpion', 'scorpion'] },
      { emoji: '🐢', keywords: ['turtle', 'turtle'] },
      { emoji: '🐍', keywords: ['snake', 'snake'] },
      { emoji: '🦎', keywords: ['lizard', 'lizard'] },
      { emoji: '🦖', keywords: ['dinosaur', 'dinosaur'] },
      { emoji: '🦕', keywords: ['sauropod', 'sauropod'] },
      { emoji: '🐙', keywords: ['octopus', 'octopus'] },
      { emoji: '🦑', keywords: ['squid', 'squid'] },
      { emoji: '🦐', keywords: ['shrimp', 'shrimp'] },
      { emoji: '🦞', keywords: ['lobster', 'lobster'] },
      { emoji: '🦀', keywords: ['crab', 'crab'] },
      { emoji: '🐡', keywords: ['blowfish', 'blowfish'] },
      { emoji: '🐠', keywords: ['fish', 'fish'] },
      { emoji: '🐟', keywords: ['fish', 'fish'] },
      { emoji: '🐬', keywords: ['dolphin', 'dolphin'] },
      { emoji: '🐳', keywords: ['whale', 'whale'] },
      { emoji: '🐋', keywords: ['whale', 'whale'] },
      { emoji: '🦈', keywords: ['shark', 'shark'] },
      { emoji: '🐊', keywords: ['crocodile', 'crocodile'] },
      { emoji: '🐅', keywords: ['tiger', 'tiger'] },
      { emoji: '🐆', keywords: ['leopard', 'leopard'] },
      { emoji: '🦓', keywords: ['zebra', 'zebra'] },
      { emoji: '🦍', keywords: ['gorilla', 'gorilla'] },
      { emoji: '🦧', keywords: ['orangutan', 'orangutan'] },
      { emoji: '🐘', keywords: ['elephant', 'elephant'] },
      { emoji: '🦛', keywords: ['hippo', 'hippo'] },
      { emoji: '🦏', keywords: ['rhino', 'rhino'] },
      { emoji: '🐪', keywords: ['camel', 'camel'] },
      { emoji: '🐫', keywords: ['bactrian camel', 'camel'] },
      { emoji: '🦒', keywords: ['giraffe', 'giraffe'] },
      { emoji: '🦘', keywords: ['kangaroo', 'kangaroo'] },
      { emoji: '🐃', keywords: ['water buffalo', 'buffalo'] },
      { emoji: '🐂', keywords: ['ox', 'ox'] },
      { emoji: '🐄', keywords: ['dairy cow', 'cow'] },
      { emoji: '🐎', keywords: ['racehorse', 'horse', 'racing'] },
      { emoji: '🐖', keywords: ['pig', 'pig'] },
      { emoji: '🐏', keywords: ['ram', 'ram'] },
      { emoji: '🐑', keywords: ['sheep', 'sheep'] },
      { emoji: '🦙', keywords: ['llama', 'llama'] },
      { emoji: '🐐', keywords: ['goat', 'goat'] },
      { emoji: '🦌', keywords: ['deer', 'deer'] },
      { emoji: '🐕', keywords: ['dog', 'dog'] },
      { emoji: '🐩', keywords: ['poodle', 'poodle'] },
      { emoji: '🦮', keywords: ['guide dog', 'guide', 'dog'] },
      { emoji: '🐕‍🦺', keywords: ['service dog', 'service', 'dog'] },
      { emoji: '🐈', keywords: ['cat', 'cat'] },
      { emoji: '🐈‍⬛', keywords: ['black cat', 'black', 'cat'] },
      { emoji: '🪶', keywords: ['feather', 'feather'] },
      { emoji: '🐓', keywords: ['rooster', 'rooster'] },
      { emoji: '🦃', keywords: ['turkey', 'turkey'] },
      { emoji: '🦚', keywords: ['peacock', 'peacock'] },
      { emoji: '🦜', keywords: ['parrot', 'parrot'] },
      { emoji: '🦢', keywords: ['swan', 'swan'] },
      { emoji: '🦩', keywords: ['flamingo', 'flamingo'] },
      { emoji: '🕊️', keywords: ['dove', 'peace', 'dove'] },
      { emoji: '🐇', keywords: ['rabbit', 'rabbit'] },
      { emoji: '🦝', keywords: ['raccoon', 'raccoon'] },
      { emoji: '🦨', keywords: ['skunk', 'skunk'] },
      { emoji: '🦡', keywords: ['badger', 'badger'] },
      { emoji: '🦫', keywords: ['beaver', 'beaver'] },
      { emoji: '🦦', keywords: ['otter', 'otter'] },
      { emoji: '🦥', keywords: ['sloth', 'sloth'] },
      { emoji: '🐭', keywords: ['mouse', 'mouse', 'face'] },
      { emoji: '🐿️', keywords: ['squirrel', 'squirrel'] },
      { emoji: '🦔', keywords: ['hedgehog', 'hedgehog'] },
    ],
  },
  {
    name: 'Food',
    icon: '🍔',
    emojis: [
      { emoji: '🍎', keywords: ['apple', 'apple'] },
      { emoji: '🍐', keywords: ['pear', 'pear'] },
      { emoji: '🍊', keywords: ['tangerine', 'orange'] },
      { emoji: '🍋', keywords: ['lemon', 'lemon'] },
      { emoji: '🍌', keywords: ['banana', 'banana'] },
      { emoji: '🍉', keywords: ['watermelon', 'watermelon'] },
      { emoji: '🍇', keywords: ['grape', 'grape'] },
      { emoji: '🍓', keywords: ['strawberry', 'strawberry'] },
      { emoji: '🫐', keywords: ['blueberry', 'blueberry'] },
      { emoji: '🍈', keywords: ['melon', 'melon'] },
      { emoji: '🍒', keywords: ['cherry', 'cherry'] },
      { emoji: '🍑', keywords: ['peach', 'peach'] },
      { emoji: '🥭', keywords: ['mango', 'mango'] },
      { emoji: '🍍', keywords: ['pineapple', 'pineapple'] },
      { emoji: '🥥', keywords: ['coconut', 'coconut'] },
      { emoji: '🥝', keywords: ['kiwi', 'kiwi'] },
      { emoji: '🍅', keywords: ['tomato', 'tomato'] },
      { emoji: '🍆', keywords: ['eggplant', 'eggplant'] },
      { emoji: '🥑', keywords: ['avocado', 'avocado'] },
      { emoji: '🫛', keywords: ['pea', 'pea', 'pod'] },
      { emoji: '🥦', keywords: ['broccoli', 'broccoli'] },
      { emoji: '🥬', keywords: ['vegetable', 'leafy', 'green'] },
      { emoji: '🥒', keywords: ['cucumber', 'cucumber'] },
      { emoji: '🌶️', keywords: ['pepper', 'pepper', 'hot'] },
      { emoji: '🫑', keywords: ['bell pepper', 'bell', 'pepper'] },
      { emoji: '🌽', keywords: ['corn', 'corn'] },
      { emoji: '🥕', keywords: ['carrot', 'carrot'] },
      { emoji: '🫒', keywords: ['olive', 'olive'] },
      { emoji: '🧄', keywords: ['garlic', 'garlic'] },
      { emoji: '🧅', keywords: ['onion', 'onion'] },
      { emoji: '🥔', keywords: ['potato', 'potato'] },
      { emoji: '🍠', keywords: ['sweet potato', 'sweet', 'potato'] },
      { emoji: '🫘', keywords: ['beans', 'beans'] },
      { emoji: '🥐', keywords: ['croissant', 'croissant'] },
      { emoji: '🥖', keywords: ['baguette', 'baguette', 'bread'] },
      { emoji: '🍞', keywords: ['bread', 'bread'] },
      { emoji: '🥨', keywords: ['pretzel', 'pretzel'] },
      { emoji: '🥯', keywords: ['bagel', 'bagel'] },
      { emoji: '🥞', keywords: ['pancake', 'pancake'] },
      { emoji: '🧇', keywords: ['waffle', 'waffle'] },
      { emoji: '🧀', keywords: ['cheese', 'cheese'] },
      { emoji: '🍖', keywords: ['meat', 'meat', 'bone'] },
      { emoji: '🍗', keywords: ['drumstick', 'poultry', 'leg'] },
      { emoji: '🥩', keywords: ['steak', 'steak'] },
      { emoji: '🥓', keywords: ['bacon', 'bacon'] },
      { emoji: '🍔', keywords: ['burger', 'burger'] },
      { emoji: '🍟', keywords: ['fries', 'fries'] },
      { emoji: '🍕', keywords: ['pizza', 'pizza'] },
      { emoji: '🌭', keywords: ['hotdog', 'hotdog'] },
      { emoji: '🥪', keywords: ['sandwich', 'sandwich'] },
      { emoji: '🌮', keywords: ['taco', 'taco'] },
      { emoji: '🌯', keywords: ['burrito', 'burrito'] },
      { emoji: '🫔', keywords: ['tamale', 'tamale'] },
      { emoji: '🥙', keywords: ['pita', 'pita'] },
      { emoji: '🧆', keywords: ['falafel', 'falafel'] },
      { emoji: '🥚', keywords: ['egg', 'egg'] },
      { emoji: '🍳', keywords: ['fried egg', 'fried', 'egg', 'cooking'] },
      { emoji: '🥘', keywords: ['stew', 'stew'] },
      { emoji: '🍲', keywords: ['hotpot', 'soup', 'pot'] },
      { emoji: '🫕', keywords: ['fondue', 'fondue'] },
      { emoji: '🥣', keywords: ['bowl', 'bowl', 'cereal'] },
      { emoji: '🥗', keywords: ['salad', 'salad'] },
      { emoji: '🍿', keywords: ['popcorn', 'popcorn'] },
      { emoji: '🧈', keywords: ['butter', 'butter'] },
      { emoji: '🧂', keywords: ['salt', 'salt'] },
      { emoji: '🥫', keywords: ['canned', 'can'] },
      { emoji: '🍱', keywords: ['bento', 'bento'] },
      { emoji: '🍘', keywords: ['rice cracker', 'cracker'] },
      { emoji: '🍙', keywords: ['rice ball', 'rice', 'ball'] },
      { emoji: '🍚', keywords: ['rice', 'rice'] },
      { emoji: '🍛', keywords: ['curry', 'curry'] },
      { emoji: '🍜', keywords: ['noodles', 'noodle', 'ramen'] },
      { emoji: '🍝', keywords: ['pasta', 'spaghetti', 'pasta'] },
      { emoji: '🍠', keywords: ['roasted sweet potato', 'roasted'] },
      { emoji: '🍢', keywords: ['oden', 'oden'] },
      { emoji: '🍣', keywords: ['sushi', 'sushi'] },
      { emoji: '🍤', keywords: ['fried shrimp', 'fried', 'shrimp'] },
      { emoji: '🍥', keywords: ['fish cake', 'fish', 'cake'] },
      { emoji: '🥮', keywords: ['moon cake', 'moon', 'cake'] },
      { emoji: '🍡', keywords: ['dango', 'dango'] },
      { emoji: '🥟', keywords: ['dumpling', 'dumpling'] },
      { emoji: '🥠', keywords: ['fortune cookie', 'fortune', 'cookie'] },
      { emoji: '🥡', keywords: ['takeout', 'takeout', 'box'] },
      { emoji: '🦀', keywords: ['crab', 'crab'] },
      { emoji: '🦞', keywords: ['lobster', 'lobster'] },
      { emoji: '🦐', keywords: ['shrimp', 'shrimp'] },
      { emoji: '🦑', keywords: ['squid', 'squid'] },
      { emoji: '🦪', keywords: ['oyster', 'oyster'] },
      { emoji: '🍦', keywords: ['ice cream', 'ice', 'cream'] },
      { emoji: '🍧', keywords: ['shaved ice', 'shaved', 'ice'] },
      { emoji: '🍨', keywords: ['ice cream', 'ice', 'cream'] },
      { emoji: '🍩', keywords: ['donut', 'donut'] },
      { emoji: '🍪', keywords: ['cookie', 'cookie'] },
      { emoji: '🎂', keywords: ['cake', 'birthday', 'cake'] },
      { emoji: '🍰', keywords: ['cake', 'cake', 'shortcake'] },
      { emoji: '🧁', keywords: ['cupcake', 'cupcake'] },
      { emoji: '🥧', keywords: ['pie', 'pie'] },
      { emoji: '🍫', keywords: ['chocolate', 'chocolate'] },
      { emoji: '🍬', keywords: ['candy', 'candy'] },
      { emoji: '🍭', keywords: ['lollipop', 'lollipop'] },
      { emoji: '🍮', keywords: ['pudding', 'pudding'] },
      { emoji: '🍯', keywords: ['honey', 'honey'] },
      { emoji: '🍼', keywords: ['baby bottle', 'baby', 'bottle'] },
      { emoji: '🥛', keywords: ['milk', 'milk'] },
      { emoji: '☕', keywords: ['coffee', 'coffee', 'hot'] },
      { emoji: '🫖', keywords: ['teapot', 'teapot'] },
      { emoji: '🍵', keywords: ['tea', 'tea'] },
      { emoji: '🧃', keywords: ['juice', 'juice', 'box'] },
      { emoji: '🥤', keywords: ['drink', 'cup', 'straw', 'drink'] },
      { emoji: '🧋', keywords: ['bubble tea', 'bubble', 'tea', 'boba'] },
      { emoji: '🍶', keywords: ['sake', 'sake'] },
      { emoji: '🍺', keywords: ['beer', 'beer'] },
      { emoji: '🍻', keywords: ['cheers', 'beer', 'cheers'] },
      { emoji: '🥂', keywords: ['champagne', 'champagne', 'cheers'] },
      { emoji: '🍷', keywords: ['red wine', 'wine'] },
      { emoji: '🥃', keywords: ['whiskey', 'whiskey'] },
      { emoji: '🍸', keywords: ['cocktail', 'cocktail'] },
      { emoji: '🍹', keywords: ['tropical drink', 'tropical', 'drink'] },
      { emoji: '🧉', keywords: ['mate', 'mate'] },
      { emoji: '🍾', keywords: ['champagne', 'champagne', 'bottle'] },
      { emoji: '🫗', keywords: ['pour', 'pour', 'liquid'] },
    ],
  },
  {
    name: 'Nature',
    icon: '🌸',
    emojis: [
      { emoji: '🌸', keywords: ['cherry blossom', 'cherry', 'blossom'] },
      { emoji: '🌺', keywords: ['hibiscus', 'hibiscus'] },
      { emoji: '🌻', keywords: ['sunflower', 'sunflower'] },
      { emoji: '🌹', keywords: ['rose', 'rose'] },
      { emoji: '🌷', keywords: ['tulip', 'tulip'] },
      { emoji: '🌼', keywords: ['flower', 'blossom'] },
      { emoji: '🌻', keywords: ['flower', 'flower'] },
      { emoji: '💐', keywords: ['bouquet', 'bouquet'] },
      { emoji: '🪷', keywords: ['lotus', 'lotus'] },
      { emoji: '🪻', keywords: ['lavender', 'hyacinth'] },
      { emoji: '💮', keywords: ['white flower', 'white', 'flower'] },
      { emoji: '🏵️', keywords: ['rosette', 'rosette'] },
      { emoji: '🪹', keywords: ['empty nest', 'nest'] },
      { emoji: '🪺', keywords: ['egg nest', 'egg', 'nest'] },
      { emoji: '🍀', keywords: ['four leaf clover', 'clover', 'lucky'] },
      { emoji: '🌿', keywords: ['grass', 'herb'] },
      { emoji: '☘️', keywords: ['shamrock', 'shamrock'] },
      { emoji: '🍃', keywords: ['leaf', 'leaf'] },
      { emoji: '🍁', keywords: ['maple leaf', 'maple'] },
      { emoji: '🍂', keywords: ['fallen leaf', 'fallen', 'leaf'] },
      { emoji: '🌍', keywords: ['earth', 'earth', 'world'] },
      { emoji: '🌎', keywords: ['earth', 'earth', 'americas'] },
      { emoji: '🌏', keywords: ['earth', 'earth', 'asia'] },
      { emoji: '🌙', keywords: ['moon', 'moon', 'crescent'] },
      { emoji: '🌝', keywords: ['full moon face', 'moon', 'face'] },
      { emoji: '🌞', keywords: ['sun face', 'sun', 'face'] },
      { emoji: '⭐', keywords: ['star', 'star'] },
      { emoji: '🌟', keywords: ['glowing star', 'glowing', 'star'] },
      { emoji: '✨', keywords: ['sparkle', 'sparkles', 'shine'] },
      { emoji: '⚡', keywords: ['lightning', 'lightning', 'zap'] },
      { emoji: '🔥', keywords: ['fire', 'fire'] },
      { emoji: '💧', keywords: ['droplet', 'droplet', 'water'] },
      { emoji: '🌊', keywords: ['wave', 'wave', 'ocean'] },
      { emoji: '🌈', keywords: ['rainbow', 'rainbow'] },
      { emoji: '☀️', keywords: ['sun', 'sun'] },
      { emoji: '🌤️', keywords: ['sunny', 'sun', 'cloud'] },
      { emoji: '⛅', keywords: ['cloudy', 'partly', 'cloudy'] },
      { emoji: '🌥️', keywords: ['cloudy', 'cloud'] },
      { emoji: '☁️', keywords: ['cloud', 'cloud'] },
      { emoji: '🌦️', keywords: ['shower', 'rain', 'sun'] },
      { emoji: '🌧️', keywords: ['rain', 'rain'] },
      { emoji: '⛈️', keywords: ['thunderstorm', 'thunderstorm'] },
      { emoji: '🌩️', keywords: ['lightning', 'lightning'] },
      { emoji: '🌨️', keywords: ['snow', 'snow'] },
      { emoji: '❄️', keywords: ['snowflake', 'snowflake'] },
      { emoji: '☃️', keywords: ['snowman', 'snowman'] },
      { emoji: '⛄', keywords: ['snowman', 'snowman'] },
      { emoji: '🌬️', keywords: ['wind', 'wind', 'face'] },
      { emoji: '💨', keywords: ['wind', 'dash', 'wind'] },
      { emoji: '🌪️', keywords: ['tornado', 'tornado'] },
      { emoji: '🌫️', keywords: ['fog', 'fog'] },
      { emoji: '🌊', keywords: ['wave', 'wave'] },
      { emoji: '💧', keywords: ['droplet', 'water'] },
      { emoji: '💦', keywords: ['water', 'sweat', 'drops'] },
      { emoji: '🫧', keywords: ['bubbles', 'bubbles'] },
      { emoji: '🪨', keywords: ['rock', 'rock'] },
      { emoji: '🏔️', keywords: ['mountain', 'mountain', 'snow'] },
      { emoji: '⛰️', keywords: ['mountain', 'mountain'] },
      { emoji: '🌋', keywords: ['volcano', 'volcano'] },
      { emoji: '🏜️', keywords: ['desert', 'desert'] },
      { emoji: '🏖️', keywords: ['beach', 'beach'] },
      { emoji: '🏝️', keywords: ['island', 'island'] },
      { emoji: '🏞️', keywords: ['park', 'park'] },
      { emoji: '🌍', keywords: ['earth', 'earth'] },
    ],
  },
  {
    name: 'Objects',
    icon: '💡',
    emojis: [
      { emoji: '💻', keywords: ['computer', 'laptop', 'computer'] },
      { emoji: '🖥️', keywords: ['desktop', 'desktop'] },
      { emoji: '📱', keywords: ['phone', 'phone', 'mobile'] },
      { emoji: '☎️', keywords: ['telephone', 'phone'] },
      { emoji: '📞', keywords: ['telephone', 'phone', 'receiver'] },
      { emoji: '📟', keywords: ['pager', 'pager'] },
      { emoji: '📠', keywords: ['fax', 'fax'] },
      { emoji: '🔋', keywords: ['battery', 'battery'] },
      { emoji: '🪫', keywords: ['low battery', 'battery'] },
      { emoji: '🔌', keywords: ['plug', 'plug'] },
      { emoji: '💡', keywords: ['light bulb', 'bulb', 'idea'] },
      { emoji: '🔦', keywords: ['flashlight', 'flashlight'] },
      { emoji: '🕯️', keywords: ['candle', 'candle'] },
      { emoji: '📷', keywords: ['camera', 'camera'] },
      { emoji: '📸', keywords: ['flash camera', 'camera', 'flash'] },
      { emoji: '📹', keywords: ['video camera', 'video', 'camera'] },
      { emoji: '🎥', keywords: ['movie', 'movie', 'camera'] },
      { emoji: '📽️', keywords: ['projector', 'projector'] },
      { emoji: '📺', keywords: ['TV', 'television', 'TV'] },
      { emoji: '📻', keywords: ['radio', 'radio'] },
      { emoji: '🎙️', keywords: ['microphone', 'studio', 'mic'] },
      { emoji: '📻', keywords: ['radio', 'radio'] },
      { emoji: '📺', keywords: ['TV', 'TV'] },
      { emoji: '🎮', keywords: ['game controller', 'game', 'controller'] },
      { emoji: '🕹️', keywords: ['joystick', 'joystick', 'game'] },
      { emoji: '🎰', keywords: ['slot machine', 'slot', 'machine'] },
      { emoji: '🎲', keywords: ['dice', 'dice', 'die'] },
      { emoji: '🧩', keywords: ['puzzle', 'puzzle', 'piece'] },
      { emoji: '🪀', keywords: ['yo-yo', 'yo-yo'] },
      { emoji: '🪁', keywords: ['kite', 'kite'] },
      { emoji: '🎮', keywords: ['game', 'game'] },
      { emoji: '🎵', keywords: ['music', 'music', 'note'] },
      { emoji: '🎶', keywords: ['music', 'notes', 'music'] },
      { emoji: '🎤', keywords: ['microphone', 'microphone', 'karaoke'] },
      { emoji: '🎧', keywords: ['headphones', 'headphone'] },
      { emoji: '🎸', keywords: ['guitar', 'guitar'] },
      { emoji: '🎹', keywords: ['piano', 'piano'] },
      { emoji: '🥁', keywords: ['drum', 'drum'] },
      { emoji: '🎺', keywords: ['trumpet', 'trumpet'] },
      { emoji: '🪗', keywords: ['accordion', 'accordion'] },
      { emoji: '📖', keywords: ['book', 'book', 'open'] },
      { emoji: '📕', keywords: ['book', 'book'] },
      { emoji: '📗', keywords: ['book', 'book', 'green'] },
      { emoji: '📘', keywords: ['book', 'book', 'blue'] },
      { emoji: '📙', keywords: ['book', 'book', 'orange'] },
      { emoji: '📚', keywords: ['bookshelf', 'books'] },
      { emoji: '✏️', keywords: ['pencil', 'pencil'] },
      { emoji: '✒️', keywords: ['fountain pen', 'pen'] },
      { emoji: '🖊️', keywords: ['pen', 'pen', 'ballpoint'] },
      { emoji: '📝', keywords: ['memo', 'memo', 'note'] },
      { emoji: '📎', keywords: ['paperclip', 'paperclip'] },
      { emoji: '📎', keywords: ['clip', 'clip'] },
      { emoji: '📏', keywords: ['ruler', 'ruler'] },
      { emoji: '✂️', keywords: ['scissors', 'scissors'] },
      { emoji: '📁', keywords: ['folder', 'folder'] },
      { emoji: '📂', keywords: ['folder', 'folder', 'open'] },
      { emoji: '📅', keywords: ['calendar', 'calendar'] },
      { emoji: '📆', keywords: ['calendar', 'tear-off', 'calendar'] },
      { emoji: '📌', keywords: ['pushpin', 'pushpin'] },
      { emoji: '📍', keywords: ['location', 'pin', 'location'] },
      { emoji: '🔒', keywords: ['lock', 'lock'] },
      { emoji: '🔓', keywords: ['unlock', 'unlock'] },
      { emoji: '🔑', keywords: ['key', 'key'] },
      { emoji: '🗝️', keywords: ['key', 'old', 'key'] },
      { emoji: '🔨', keywords: ['hammer', 'hammer'] },
      { emoji: '🪓', keywords: ['axe', 'axe'] },
      { emoji: '⛏️', keywords: ['pickaxe', 'pick'] },
      { emoji: '🔧', keywords: ['wrench', 'wrench'] },
      { emoji: '🔩', keywords: ['screw', 'bolt', 'nut'] },
      { emoji: '⚙️', keywords: ['gear', 'gear', 'settings'] },
      { emoji: '✅', keywords: ['done', 'check', 'mark'] },
      { emoji: '❌', keywords: ['error', 'cross', 'mark'] },
      { emoji: '⭕', keywords: ['circle', 'circle'] },
      { emoji: '❗', keywords: ['exclamation', 'exclamation'] },
      { emoji: '❓', keywords: ['question', 'question'] },
      { emoji: '❕', keywords: ['exclaim', 'white', 'exclamation'] },
      { emoji: '❔', keywords: ['ask', 'white', 'question'] },
      { emoji: '🏆', keywords: ['trophy', 'trophy'] },
      { emoji: '🥇', keywords: ['gold medal', 'gold', 'medal'] },
      { emoji: '🥈', keywords: ['silver medal', 'silver', 'medal'] },
      { emoji: '🥉', keywords: ['bronze medal', 'bronze', 'medal'] },
      { emoji: '🏅', keywords: ['medal', 'sports', 'medal'] },
      { emoji: '🎖️', keywords: ['military medal', 'military', 'medal'] },
      { emoji: '🎗️', keywords: ['ribbon', 'reminder', 'ribbon'] },
      { emoji: '🎫', keywords: ['ticket', 'ticket'] },
      { emoji: '🎟️', keywords: ['admission ticket', 'admission', 'ticket'] },
      { emoji: '🎭', keywords: ['performance', 'performing', 'arts'] },
      { emoji: '🎨', keywords: ['art', 'art', 'palette'] },
      { emoji: '🖼️', keywords: ['picture frame', 'framed', 'picture'] },
      { emoji: '🎨', keywords: ['palette', 'palette', 'art'] },
      { emoji: '🧵', keywords: ['thread', 'thread', 'yarn'] },
      { emoji: '🪡', keywords: ['needle', 'needle'] },
      { emoji: '🧶', keywords: ['yarn', 'yarn', 'ball'] },
      { emoji: '🪢', keywords: ['knot', 'knot'] },
      { emoji: '🛍️', keywords: ['shopping bag', 'shopping', 'bag'] },
      { emoji: '💰', keywords: ['money', 'money', 'bag'] },
      { emoji: '🪙', keywords: ['coin', 'coin'] },
      { emoji: '💴', keywords: ['yen', 'yen', 'money'] },
      { emoji: '💵', keywords: ['dollar', 'dollar', 'money'] },
      { emoji: '💶', keywords: ['euro', 'euro', 'money'] },
      { emoji: '💷', keywords: ['pound', 'pound', 'money'] },
      { emoji: '💸', keywords: ['flying money', 'money', 'wing'] },
      { emoji: '💳', keywords: ['credit card', 'credit', 'card'] },
      { emoji: '💎', keywords: ['diamond', 'diamond', 'gem'] },
      { emoji: '🌈', keywords: ['rainbow', 'rainbow'] },
      { emoji: '🛒', keywords: ['shopping cart', 'cart', 'shopping'] },
    ],
  },
  {
    name: 'Travel',
    icon: '✈️',
    emojis: [
      { emoji: '🚗', keywords: ['car', 'car'] },
      { emoji: '🚕', keywords: ['taxi', 'taxi'] },
      { emoji: '🚙', keywords: ['SUV', 'SUV', 'jeep'] },
      { emoji: '🚌', keywords: ['bus', 'bus'] },
      { emoji: '🚎', keywords: ['trolleybus', 'trolleybus'] },
      { emoji: '🏎️', keywords: ['race car', 'race', 'car'] },
      { emoji: '🚓', keywords: ['police car', 'police', 'car'] },
      { emoji: '🚑', keywords: ['ambulance', 'ambulance'] },
      { emoji: '🚒', keywords: ['fire engine', 'fire', 'engine'] },
      { emoji: '🚐', keywords: ['van', 'minibus'] },
      { emoji: '🛻', keywords: ['pickup', 'pickup', 'truck'] },
      { emoji: '🚚', keywords: ['truck', 'truck'] },
      { emoji: '🚛', keywords: ['cargo truck', 'truck'] },
      { emoji: '🚜', keywords: ['tractor', 'tractor'] },
      { emoji: '🛵', keywords: ['motorcycle', 'scooter'] },
      { emoji: '🏍️', keywords: ['motorcycle', 'motorcycle'] },
      { emoji: '🚲', keywords: ['bicycle', 'bicycle', 'bike'] },
      { emoji: '🛴', keywords: ['scooter', 'kick', 'scooter'] },
      { emoji: '🛹', keywords: ['skateboard', 'skateboard'] },
      { emoji: '🛼', keywords: ['roller skates', 'roller', 'skate'] },
      { emoji: '✈️', keywords: ['airplane', 'airplane', 'plane'] },
      { emoji: '🛩️', keywords: ['small plane', 'small', 'airplane'] },
      { emoji: '🚀', keywords: ['rocket', 'rocket'] },
      { emoji: '🛸', keywords: ['UFO', 'UFO'] },
      { emoji: '🚁', keywords: ['helicopter', 'helicopter'] },
      { emoji: '🛶', keywords: ['canoe', 'canoe'] },
      { emoji: '⛵', keywords: ['sailboat', 'sailboat'] },
      { emoji: '🚤', keywords: ['speedboat', 'speedboat'] },
      { emoji: '🛳️', keywords: ['passenger ship', 'ship'] },
      { emoji: '⛴️', keywords: ['ferry', 'ferry'] },
      { emoji: '🚢', keywords: ['ship', 'ship'] },
      { emoji: '🏠', keywords: ['house', 'house'] },
      { emoji: '🏡', keywords: ['garden house', 'house', 'garden'] },
      { emoji: '🏢', keywords: ['office building', 'office', 'building'] },
      { emoji: '🏣', keywords: ['post office', 'post', 'office'] },
      { emoji: '🏥', keywords: ['hospital', 'hospital'] },
      { emoji: '🏦', keywords: ['bank', 'bank'] },
      { emoji: '🏨', keywords: ['hotel', 'hotel'] },
      { emoji: '🏩', keywords: ['love hotel', 'love', 'hotel'] },
      { emoji: '🏪', keywords: ['convenience store', 'store'] },
      { emoji: '🏫', keywords: ['school', 'school'] },
      { emoji: '🏬', keywords: ['mall', 'department', 'store'] },
      { emoji: '🏭', keywords: ['factory', 'factory'] },
      { emoji: '🏯', keywords: ['castle', 'castle', 'japan'] },
      { emoji: '🏰', keywords: ['castle', 'castle', 'european'] },
      { emoji: '⛪', keywords: ['church', 'church'] },
      { emoji: '🕌', keywords: ['mosque', 'mosque'] },
      { emoji: '🛕', keywords: ['hindu temple', 'hindu', 'temple'] },
      { emoji: '🕍', keywords: ['synagogue', 'synagogue'] },
      { emoji: '⛩️', keywords: ['shrine', 'shrine'] },
      { emoji: '🕋', keywords: ['kaaba', 'kaaba'] },
      { emoji: '⛲', keywords: ['fountain', 'fountain'] },
      { emoji: '⛺', keywords: ['tent', 'tent'] },
      { emoji: '🌁', keywords: ['fog', 'fog'] },
      { emoji: '🌃', keywords: ['night view', 'night', 'city'] },
      { emoji: '🏙️', keywords: ['city', 'city'] },
      { emoji: '🌄', keywords: ['mountain sunrise', 'sunrise', 'mountain'] },
      { emoji: '🌅', keywords: ['sunset', 'sunset'] },
      { emoji: '🌆', keywords: ['dusk', 'cityscape', 'dusk'] },
      { emoji: '🌇', keywords: ['sunset', 'sunset'] },
      { emoji: '🌉', keywords: ['bridge', 'bridge', 'night'] },
      { emoji: '🎢', keywords: ['rollercoaster', 'rollercoaster'] },
      { emoji: '🎡', keywords: ['ferris wheel', 'ferris', 'wheel'] },
      { emoji: '🎠', keywords: ['carousel', 'carousel'] },
    ],
  },
  {
    name: 'Symbols',
    icon: '💡',
    emojis: [
      { emoji: '©️', keywords: ['copyright', 'copyright'] },
      { emoji: '®️', keywords: ['registered', 'registered'] },
      { emoji: '™️', keywords: ['trademark', 'trademark'] },
      { emoji: '❗', keywords: ['exclamation', 'exclamation'] },
      { emoji: '❕', keywords: ['exclamation', 'white', 'exclamation'] },
      { emoji: '❓', keywords: ['question', 'question'] },
      { emoji: '❔', keywords: ['question', 'white', 'question'] },
      { emoji: '‼️', keywords: ['double exclamation', 'double', 'exclamation'] },
      { emoji: '⁉️', keywords: ['exclamation question', 'exclamation', 'question'] },
      { emoji: '💯', keywords: ['perfect', '100', 'hundred'] },
      { emoji: '0️⃣', keywords: ['zero', 'zero'] },
      { emoji: '➕', keywords: ['plus', 'plus'] },
      { emoji: '➖', keywords: ['minus', 'minus'] },
      { emoji: '➗', keywords: ['divide', 'divide'] },
      { emoji: '✖️', keywords: ['multiply', 'multiply'] },
      { emoji: '♾️', keywords: ['infinity', 'infinity'] },
      { emoji: '💲', keywords: ['dollar', 'dollar'] },
      { emoji: '💱', keywords: ['exchange rate', 'exchange'] },
      { emoji: '™️', keywords: ['trademark', 'trademark'] },
      { emoji: '🔴', keywords: ['red', 'red', 'circle'] },
      { emoji: '🟠', keywords: ['orange', 'orange', 'circle'] },
      { emoji: '🟡', keywords: ['yellow', 'yellow', 'circle'] },
      { emoji: '🟢', keywords: ['green', 'green', 'circle'] },
      { emoji: '🔵', keywords: ['blue', 'blue', 'circle'] },
      { emoji: '🟣', keywords: ['purple', 'purple', 'circle'] },
      { emoji: '⚫', keywords: ['black', 'black', 'circle'] },
      { emoji: '⚪', keywords: ['white', 'white', 'circle'] },
      { emoji: '🟤', keywords: ['brown', 'brown', 'circle'] },
      { emoji: '🔺', keywords: ['red triangle', 'red', 'triangle'] },
      { emoji: '🔻', keywords: ['red down triangle', 'red', 'triangle'] },
      { emoji: '🔸', keywords: ['orange', 'diamond', 'up triangle'] },
      { emoji: '🔹', keywords: ['blue diamond', 'blue', 'diamond'] },
      { emoji: '▶️', keywords: ['play', 'play'] },
      { emoji: '⏸️', keywords: ['pause', 'pause'] },
      { emoji: '⏹️', keywords: ['stop', 'stop'] },
      { emoji: '⏺️', keywords: ['record', 'record'] },
      { emoji: '⏭️', keywords: ['next track', 'next', 'track'] },
      { emoji: '⏮️', keywords: ['previous track', 'previous', 'track'] },
      { emoji: '⏩', keywords: ['fast forward', 'fast', 'forward'] },
      { emoji: '⏪', keywords: ['rewind', 'rewind'] },
      { emoji: '🔀', keywords: ['shuffle', 'shuffle'] },
      { emoji: '🔁', keywords: ['repeat', 'repeat'] },
      { emoji: '🔂', keywords: ['repeat one', 'repeat', 'one'] },
      { emoji: '➡️', keywords: ['right arrow', 'right', 'arrow'] },
      { emoji: '⬅️', keywords: ['left arrow', 'left', 'arrow'] },
      { emoji: '⬆️', keywords: ['up arrow', 'up', 'arrow'] },
      { emoji: '⬇️', keywords: ['down arrow', 'down', 'arrow'] },
      { emoji: '↗️', keywords: ['upper right', 'arrow'] },
      { emoji: '↘️', keywords: ['lower right', 'arrow'] },
      { emoji: '↙️', keywords: ['lower left', 'arrow'] },
      { emoji: '↖️', keywords: ['upper left', 'arrow'] },
      { emoji: '↕️', keywords: ['up down', 'arrow'] },
      { emoji: '↔️', keywords: ['left right', 'arrow'] },
      { emoji: '↪️', keywords: ['left arrow curve', 'arrow'] },
      { emoji: '↩️', keywords: ['right arrow curve', 'arrow'] },
      { emoji: '⤴️', keywords: ['upper right', 'arrow'] },
      { emoji: '⤵️', keywords: ['lower right', 'arrow'] },
      { emoji: '🔃', keywords: ['rotate', 'arrows'] },
      { emoji: '🔄', keywords: ['rotate', 'arrows'] },
      { emoji: '🔙', keywords: ['back', 'back'] },
      { emoji: '🔚', keywords: ['end', 'end'] },
      { emoji: '🔛', keywords: ['on', 'on'] },
      { emoji: '🔜', keywords: ['soon', 'soon'] },
      { emoji: '🔝', keywords: ['top', 'top'] },
      { emoji: '🛜', keywords: ['WiFi', 'wireless'] },
      { emoji: '📲', keywords: ['incoming call', 'call'] },
      { emoji: '📶', keywords: ['signal', 'signal'] },
      { emoji: '🔋', keywords: ['battery', 'battery'] },
      { emoji: '🪫', keywords: ['low battery', 'battery', 'low'] },
      { emoji: '⚡', keywords: ['lightning', 'zap', 'lightning'] },
      { emoji: '♻️', keywords: ['recycle', 'recycle'] },
      { emoji: '✅', keywords: ['done', 'check'] },
      { emoji: '❌', keywords: ['cancel', 'cross', 'mark'] },
      { emoji: '⭕', keywords: ['circle', 'hollow', 'circle'] },
      { emoji: '❎', keywords: ['cross mark', 'cross', 'mark'] },
      { emoji: '️', keywords: ['ballot', 'ballot'] },
      { emoji: '☑️', keywords: ['check box', 'check', 'box'] },
      { emoji: '✔️', keywords: ['check mark', 'check', 'mark'] },
      { emoji: '✅', keywords: ['check mark', 'green', 'check'] },
      { emoji: '❗', keywords: ['exclamation mark', 'exclamation'] },
      { emoji: '❓', keywords: ['question', 'question'] },
      { emoji: '➰', keywords: ['curly loop', 'curly', 'loop'] },
      { emoji: '➿', keywords: ['double loop', 'double', 'loop'] },
      { emoji: '〽️', keywords: ['mark', 'part', 'alternation'] },
      { emoji: '✳️', keywords: ['eight spoked', 'eight', 'spoked'] },
      { emoji: '✴️', keywords: ['eight pointed', 'eight', 'pointed'] },
      { emoji: '❇️', keywords: ['sparkle', 'sparkle'] },
      { emoji: '©️', keywords: ['copyright', 'copyright'] },
      { emoji: '®️', keywords: ['registered', 'registered'] },
      { emoji: '™️', keywords: ['trademark', 'trademark'] },
      { emoji: '#️⃣', keywords: ['hash', 'hash'] },
      { emoji: '*️⃣', keywords: ['asterisk', 'asterisk'] },
      { emoji: '0️⃣', keywords: ['zero', 'zero'] },
      { emoji: '1️⃣', keywords: ['one', 'one'] },
      { emoji: '2️⃣', keywords: ['two', 'two'] },
      { emoji: '3️⃣', keywords: ['three', 'three'] },
      { emoji: '4️⃣', keywords: ['four', 'four'] },
      { emoji: '5️⃣', keywords: ['five', 'five'] },
      { emoji: '6️⃣', keywords: ['six', 'six'] },
      { emoji: '7️⃣', keywords: ['seven', 'seven'] },
      { emoji: '8️⃣', keywords: ['eight', 'eight'] },
      { emoji: '9️⃣', keywords: ['nine', 'nine'] },
      { emoji: '🔟', keywords: ['ten', 'ten'] },
      { emoji: '💯', keywords: ['perfect', 'hundred'] },
      { emoji: '🔠', keywords: ['capital letters', 'capital', 'letters'] },
      { emoji: '🔡', keywords: ['lowercase letters', 'input', 'latin'] },
      { emoji: '🔢', keywords: ['numbers', 'input', 'numbers'] },
      { emoji: '🔣', keywords: ['symbols', 'symbols'] },
      { emoji: '🔤', keywords: ['letters', 'letters'] },
      { emoji: '🅰️', keywords: ['blood type A', 'blood', 'type', 'A'] },
      { emoji: '🆎', keywords: ['blood type AB', 'blood', 'type', 'AB'] },
      { emoji: '🅱️', keywords: ['blood type B', 'blood', 'type', 'B'] },
      { emoji: '🆑', keywords: ['CL', 'clear'] },
      { emoji: '🆒', keywords: ['COOL', 'cool'] },
      { emoji: '🆓', keywords: ['FREE', 'free'] },
      { emoji: 'ℹ️', keywords: ['information', 'information'] },
      { emoji: '🆔', keywords: ['ID', 'identification'] },
      { emoji: 'Ⓜ️', keywords: ['M', 'circled', 'M'] },
      { emoji: '🆕', keywords: ['NEW', 'new'] },
      { emoji: '🆖', keywords: ['NG', 'no', 'good'] },
      { emoji: '🅾️', keywords: ['O', 'blood', 'type', 'O'] },
      { emoji: '🆗', keywords: ['OK', 'ok'] },
      { emoji: '🅿️', keywords: ['P', 'parking'] },
      { emoji: '🆘', keywords: ['SOS', 'help', 'sos'] },
      { emoji: '🆙', keywords: ['UP', 'up'] },
      { emoji: '🆚', keywords: ['VS', 'versus'] },
      { emoji: '🈁', keywords: ['Koko', 'here'] },
      { emoji: '🈂️', keywords: ['Sa', 'service', 'charge'] },
      { emoji: '🈷️', keywords: ['month', 'moon'] },
      { emoji: '🈶', keywords: ['have', 'have'] },
      { emoji: '🈯', keywords: ['point at', 'point'] },
      { emoji: '🉐', keywords: ['get', 'negotiation'] },
      { emoji: '🈹', keywords: ['discount', 'discount'] },
      { emoji: '🈚', keywords: ['nothing', 'nothing', 'empty'] },
      { emoji: '🈲', keywords: ['prohibited', 'prohibited'] },
      { emoji: '🉑', keywords: ['acceptable', 'acceptable'] },
      { emoji: '🈸', keywords: ['apply', 'application'] },
      { emoji: '🈴', keywords: ['pass', 'passing'] },
      { emoji: '🈳', keywords: ['vacancy', 'vacancy'] },
      { emoji: '㊗️', keywords: ['congratulations', 'congratulations'] },
      { emoji: '㊙️', keywords: ['secret', 'secret'] },
      { emoji: '🈺', keywords: ['open for business', 'open', 'business'] },
      { emoji: '🈵', keywords: ['full', 'full'] },
      { emoji: '🔴', keywords: ['red', 'red', 'circle'] },
      { emoji: '🟠', keywords: ['orange', 'orange', 'circle'] },
      { emoji: '🟡', keywords: ['yellow', 'yellow', 'circle'] },
      { emoji: '🟢', keywords: ['green', 'green', 'circle'] },
      { emoji: '🔵', keywords: ['blue', 'blue', 'circle'] },
      { emoji: '🟣', keywords: ['purple', 'purple', 'circle'] },
      { emoji: '⚫', keywords: ['black', 'black', 'circle'] },
      { emoji: '⚪', keywords: ['white', 'white', 'circle'] },
      { emoji: '🟤', keywords: ['brown', 'brown', 'circle'] },
      { emoji: '🔺', keywords: ['red triangle', 'up', 'triangle'] },
      { emoji: '🔻', keywords: ['red down triangle', 'down', 'triangle'] },
      { emoji: '🔸', keywords: ['orange', 'diamond'] },
      { emoji: '🔹', keywords: ['blue', 'diamond'] },
      { emoji: '🔶', keywords: ['orange', 'diamond', 'large'] },
      { emoji: '🔷', keywords: ['blue', 'diamond', 'large'] },
    ],
  },
  {
    name: 'Flags',
    icon: '🏁',
    emojis: [
      { emoji: '🏁', keywords: ['checkered flag', 'checkered', 'flag'] },
      { emoji: '🚩', keywords: ['red flag', 'red', 'flag'] },
      { emoji: '🎌', keywords: ['crossed flags', 'crossed', 'flags'] },
      { emoji: '🏴', keywords: ['black flag', 'black', 'flag'] },
      { emoji: '🏳️', keywords: ['white flag', 'white', 'flag'] },
      { emoji: '🏳️‍🌈', keywords: ['rainbow flag', 'rainbow', 'flag', 'pride'] },
      { emoji: '🏳️‍⚧️', keywords: ['transgender flag', 'transgender', 'flag'] },
      { emoji: '🏴‍☠️', keywords: ['pirate flag', 'pirate', 'flag'] },
      { emoji: '🇨🇳', keywords: ['China', 'china', 'CN'] },
      { emoji: '🇺🇸', keywords: ['USA', 'usa', 'US', 'america'] },
      { emoji: '🇬🇧', keywords: ['UK', 'uk', 'britain'] },
      { emoji: '🇯🇵', keywords: ['Japan', 'japan', 'JP'] },
      { emoji: '🇰🇷', keywords: ['Korea', 'korea', 'KR'] },
      { emoji: '🇫🇷', keywords: ['France', 'france', 'FR'] },
      { emoji: '🇩🇪', keywords: ['Germany', 'germany', 'DE'] },
      { emoji: '🇮🇹', keywords: ['Italy', 'italy', 'IT'] },
      { emoji: '🇪🇸', keywords: ['Spain', 'spain', 'ES'] },
      { emoji: '🇷🇺', keywords: ['Russia', 'russia', 'RU'] },
      { emoji: '🇧🇷', keywords: ['Brazil', 'brazil', 'BR'] },
      { emoji: '🇮🇳', keywords: ['India', 'india', 'IN'] },
      { emoji: '🇦🇺', keywords: ['Australia', 'australia', 'AU'] },
      { emoji: '🇨🇦', keywords: ['Canada', 'canada', 'CA'] },
      { emoji: '🇲🇽', keywords: ['Mexico', 'mexico', 'MX'] },
      { emoji: '🇸🇬', keywords: ['Singapore', 'singapore', 'SG'] },
      { emoji: '🇲🇾', keywords: ['Malaysia', 'malaysia', 'MY'] },
      { emoji: '🇹🇭', keywords: ['Thailand', 'thailand', 'TH'] },
      { emoji: '🇻🇳', keywords: ['Vietnam', 'vietnam', 'VN'] },
      { emoji: '🇮🇩', keywords: ['Indonesia', 'indonesia', 'ID'] },
      { emoji: '🇵🇭', keywords: ['Philippines', 'philippines', 'PH'] },
      { emoji: '🇳🇿', keywords: ['New Zealand', 'new', 'zealand'] },
      { emoji: '🇸🇦', keywords: ['Saudi Arabia', 'saudi', 'arabia'] },
      { emoji: '🇦🇪', keywords: ['UAE', 'UAE'] },
      { emoji: '🇹🇷', keywords: ['Turkey', 'turkey', 'TR'] },
      { emoji: '🇪🇬', keywords: ['Egypt', 'egypt', 'EG'] },
      { emoji: '🇿🇦', keywords: ['South Africa', 'south', 'africa'] },
      { emoji: '🇳🇱', keywords: ['Netherlands', 'netherlands', 'NL'] },
      { emoji: '🇧🇪', keywords: ['Belgium', 'belgium'] },
      { emoji: '🇨🇭', keywords: ['Switzerland', 'switzerland', 'CH'] },
      { emoji: '🇦🇹', keywords: ['Austria', 'austria'] },
      { emoji: '🇸🇪', keywords: ['Sweden', 'sweden', 'SE'] },
      { emoji: '🇳🇴', keywords: ['Norway', 'norway', 'NO'] },
      { emoji: '🇩🇰', keywords: ['Denmark', 'denmark', 'DK'] },
      { emoji: '🇫🇮', keywords: ['Finland', 'finland', 'FI'] },
      { emoji: '🇵🇱', keywords: ['Poland', 'poland', 'PL'] },
      { emoji: '🇵🇹', keywords: ['Portugal', 'portugal', 'PT'] },
      { emoji: '🇬🇷', keywords: ['Greece', 'greece', 'GR'] },
      { emoji: '🇭🇺', keywords: ['Hungary', 'hungary'] },
      { emoji: '🇨🇿', keywords: ['Czech', 'czech'] },
      { emoji: '🇮🇱', keywords: ['Israel', 'israel', 'IL'] },
      { emoji: '🇦🇷', keywords: ['Argentina', 'argentina', 'AR'] },
      { emoji: '🇨🇱', keywords: ['Chile', 'chile', 'CL'] },
      { emoji: '🇨🇴', keywords: ['Colombia', 'colombia'] },
      { emoji: '🇵🇪', keywords: ['Peru', 'peru'] },
      { emoji: '🇭🇰', keywords: ['Hong Kong', 'hong', 'kong'] },
      { emoji: '🇹🇼', keywords: ['Taiwan', 'taiwan', 'TW'] },
      { emoji: '🇲🇴', keywords: ['Macau', 'macau', 'MO'] },
    ],
  },
]

// Recently used emojis (persisted in localStorage)
const RECENT_EMOJIS_KEY = 'forum_recent_emojis'
const MAX_RECENT = 16

function getRecentEmojis(): string[] {
  if (typeof window === 'undefined') return []
  try {
    const saved = localStorage.getItem(RECENT_EMOJIS_KEY)
    return saved ? JSON.parse(saved) : []
  } catch {
    return []
  }
}

function addRecentEmoji(emoji: string) {
  if (typeof window === 'undefined') return
  try {
    const recent = getRecentEmojis().filter(e => e !== emoji)
    recent.unshift(emoji)
    localStorage.setItem(RECENT_EMOJIS_KEY, JSON.stringify(recent.slice(0, MAX_RECENT)))
  } catch { /* ignore */ }
}

// Search emojis by keyword
function searchEmojis(query: string): EmojiData[] {
  if (!query.trim()) return []
  const q = query.toLowerCase().trim()
  const results: EmojiData[] = []
  const seen = new Set<string>()
  for (const cat of EMOJI_CATEGORIES) {
    for (const e of cat.emojis) {
      if (!seen.has(e.emoji) && (
        e.emoji.includes(q) ||
        e.keywords.some(k => k.includes(q))
      )) {
        results.push(e)
        seen.add(e.emoji)
      }
      if (results.length >= 40) return results
    }
  }
  return results
}

interface EmojiPickerProps {
  onSelect: (emoji: string) => void
  children?: React.ReactNode
}

export function EmojiPicker({ onSelect }: EmojiPickerProps) {
  const [open, setOpen] = useState(false)
  const [search, setSearch] = useState('')
  const inputRef = useRef<HTMLInputElement>(null)
  const [activeCategory, setActiveCategory] = useState(0)
  const [recentEmojis] = useState<string[]>(() => getRecentEmojis())

  const filteredEmojis = search ? searchEmojis(search) : []

  useEffect(() => {
    if (open && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 100)
    }
  }, [open])

  const handleSelect = useCallback((emoji: string) => {
    onSelect(emoji)
    addRecentEmoji(emoji)
    setOpen(false)
    setSearch('')
  }, [onSelect])

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        {<Button variant="ghost" size="icon" className="size-8 text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300" title="Emoji">
          <Smile className="size-4" />
        </Button>}
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="start">
        <div className="border-b border-gray-100 dark:border-gray-800 p-2">
          <div className="relative">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 size-3.5 text-gray-400" />
            <input
              ref={inputRef}
              type="text"
              placeholder="Search emoji..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full text-sm bg-gray-50 dark:bg-gray-900 pl-7 pr-2 py-1.5 rounded-md border-0 outline-none placeholder-gray-400 dark:placeholder-gray-500 text-gray-900 dark:text-gray-100"
            />
          </div>
        </div>

        {/* Category tabs */}
        {!search && (
          <div className="flex gap-0.5 px-2 pt-2 pb-1.5 border-b border-gray-50 dark:border-gray-800/50 overflow-x-auto no-scrollbar">
            {recentEmojis.length > 0 && (
              <button
                onClick={() => setActiveCategory(-1)}
                className={cn('text-xs px-2 py-1 rounded-full transition-colors whitespace-nowrap flex items-center gap-1',
                  activeCategory === -1
                    ? 'bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900'
                    : 'text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-800')}
              >
                <Clock className="size-3" />
                Recent
              </button>
            )}
            {EMOJI_CATEGORIES.map((cat, i) => (
              <button
                key={cat.name}
                onClick={() => setActiveCategory(i)}
                className={cn('text-xs px-2 py-1 rounded-full transition-colors whitespace-nowrap',
                  activeCategory === i
                    ? 'bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900'
                    : 'text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-800')}
              >
                {cat.icon} {cat.name}
              </button>
            ))}
          </div>
        )}

        {/* Emoji grid */}
        <div className="max-h-56 overflow-y-auto p-2">
          {search ? (
            <div className="grid grid-cols-8 gap-0.5">
              {filteredEmojis.map((item, i) => (
                <button
                  key={`${item.emoji}-${i}`}
                  onClick={() => handleSelect(item.emoji)}
                  className="size-8 flex items-center justify-center rounded hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors text-lg"
                  title={item.keywords[0]}
                >
                  {item.emoji}
                </button>
              ))}
              {filteredEmojis.length === 0 && (
                <div className="col-span-8 text-center text-xs text-gray-400 dark:text-gray-500 py-4">
                  No matching emoji found
                </div>
              )}
            </div>
          ) : activeCategory === -1 ? (
            <div className="grid grid-cols-8 gap-0.5">
              {recentEmojis.map((emoji, i) => (
                <button
                  key={`recent-${emoji}-${i}`}
                  onClick={() => handleSelect(emoji)}
                  className="size-8 flex items-center justify-center rounded hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors text-lg"
                >
                  {emoji}
                </button>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-8 gap-0.5">
              {EMOJI_CATEGORIES[activeCategory].emojis.map((item, i) => (
                <button
                  key={`${item.emoji}-${i}`}
                  onClick={() => handleSelect(item.emoji)}
                  className="size-8 flex items-center justify-center rounded hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors text-lg"
                  title={item.keywords[0]}
                >
                  {item.emoji}
                </button>
              ))}
            </div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  )
}

// Compact inline emoji picker button for comment/chat input
interface EmojiPickerInlineProps {
  onSelect: (emoji: string) => void
}

export function EmojiPickerInline({ onSelect }: EmojiPickerInlineProps) {
  const [open, setOpen] = useState(false)
  const [search, setSearch] = useState('')
  const [activeCategory, setActiveCategory] = useState(0)
  const [recentEmojis] = useState<string[]>(() => getRecentEmojis())

  const filteredEmojis = search ? searchEmojis(search) : []

  const handleSelect = useCallback((emoji: string) => {
    onSelect(emoji)
    addRecentEmoji(emoji)
    setOpen(false)
    setSearch('')
  }, [onSelect])

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          type="button"
          className="flex items-center justify-center size-7 rounded-full text-gray-400 hover:text-gray-600 hover:bg-gray-100 dark:text-gray-500 dark:hover:text-gray-300 dark:hover:bg-gray-800 transition-colors"
          title="Emoji"
        >
          <Smile className="size-4" />
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-72 p-0" align="start" side="top">
        <div className="border-b border-gray-100 dark:border-gray-800 p-2">
          <div className="relative">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 size-3 text-gray-400" />
            <input
              type="text"
              placeholder="Search emoji..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full text-sm bg-gray-50 dark:bg-gray-900 pl-7 pr-2 py-1.5 rounded-md border-0 outline-none placeholder-gray-400 dark:placeholder-gray-500 text-gray-900 dark:text-gray-100"
            />
          </div>
        </div>
        {!search && (
          <div className="flex gap-0.5 px-2 pt-1.5 pb-1 overflow-x-auto no-scrollbar">
            {recentEmojis.length > 0 && (
              <button
                onClick={() => setActiveCategory(-1)}
                className={cn('text-[10px] px-1.5 py-0.5 rounded-full transition-colors whitespace-nowrap',
                  activeCategory === -1
                    ? 'bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900'
                    : 'text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-800')}
              >
                <Clock className="size-2.5 inline -mt-px mr-0.5" />
                Recent
              </button>
            )}
            {EMOJI_CATEGORIES.map((cat, i) => (
              <button
                key={cat.name}
                onClick={() => setActiveCategory(i)}
                className={cn('text-[10px] px-1.5 py-0.5 rounded-full transition-colors whitespace-nowrap',
                  activeCategory === i
                    ? 'bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900'
                    : 'text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-800'
                )}
              >
                {cat.icon} {cat.name}
              </button>
            ))}
          </div>
        )}
        <div className="max-h-48 overflow-y-auto p-1.5">
          {search ? (
            <div className="grid grid-cols-8 gap-0.5">
              {filteredEmojis.map((item, i) => (
                <button
                  key={`${item.emoji}-${i}`}
                  onClick={() => handleSelect(item.emoji)}
                  className="size-7 flex items-center justify-center rounded hover:bg-gray-100 dark:hover:bg-gray-800 text-base transition-colors"
                  title={item.keywords[0]}
                >
                  {item.emoji}
                </button>
              ))}
            </div>
          ) : activeCategory === -1 ? (
            <div className="grid grid-cols-8 gap-0.5">
              {recentEmojis.map((emoji, i) => (
                <button
                  key={`recent-${emoji}-${i}`}
                  onClick={() => handleSelect(emoji)}
                  className="size-7 flex items-center justify-center rounded hover:bg-gray-100 dark:hover:bg-gray-800 text-base transition-colors"
                >
                  {emoji}
                </button>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-8 gap-0.5">
              {EMOJI_CATEGORIES[activeCategory].emojis.map((item, i) => (
                <button
                  key={`${item.emoji}-${i}`}
                  onClick={() => handleSelect(item.emoji)}
                  className="size-7 flex items-center justify-center rounded hover:bg-gray-100 dark:hover:bg-gray-800 text-base transition-colors"
                  title={item.keywords[0]}
                >
                  {item.emoji}
                </button>
              ))}
            </div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  )
}
