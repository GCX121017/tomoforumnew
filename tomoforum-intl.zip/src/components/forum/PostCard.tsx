'use client'

import { useForumStore, type Post } from '@/store/forum'
import { cn, formatTimeAgo, formatFullDate, truncateText, getLevelInfo, getReadingTime } from '@/components/forum/helpers'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Eye, MessageSquare, Heart, Pin, Clock, Share2, ImageIcon, Shield, UserPlus, UserCheck } from 'lucide-react'
import LevelBadge from './LevelBadge'
import { toast } from 'sonner'
import { motion } from 'framer-motion'

interface PostCardProps {
  post: Post
  index?: number
  followedAuthors?: Record<string, boolean>
  onFollowAuthor?: (authorId: string) => void
}

export default function PostCard({ post, index = 0, followedAuthors, onFollowAuthor }: PostCardProps) {
  const { navigate, currentUser, setShowLoginDialog } = useForumStore()
  const authorLevel = post.author ? getLevelInfo(post.author.points ?? 0) : null

  // Extract image URLs from markdown content
  const postImages = (() => {
    const regex = /!\[[^\]]*\]\(([^)]+)\)/g
    const images: string[] = []
    let match
    while ((match = regex.exec(post.content)) !== null) {
      images.push(match[1])
    }
    return images
  })()

  // Extract file attachments from markdown content
  const postFiles = (() => {
    const regex = /\[([🎵🎬📎][^\]]+)\]\([^)]+\)/g
    const files: string[] = []
    let match
    while ((match = regex.exec(post.content)) !== null) {
      files.push(match[1])
    }
    return files
  })()

  // Clean content for preview: strip markdown URLs
  const cleanPreview = (() => {
    let cleaned = post.content
      // Remove image markdown: ![alt](url) → [Image]
      .replace(/!\[[^\]]*\]\([^)]+\)/g, '[Image]')
      // Remove file link markdown: [📎 filename](url) → filename
      .replace(/\[[🎵🎬📎]\s*([^\]]+)\]\([^)]+\)/g, '$1')
      // Remove regular link markdown: [text](url) → text
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    return cleaned
  })()

  const isFollowed = followedAuthors?.[post.authorId] ?? false
  const isOwnPost = currentUser?.id === post.authorId

  const handleFollowClick = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (!currentUser) {
      setShowLoginDialog(true)
      return
    }
    onFollowAuthor?.(post.authorId)
  }

  return (
    <motion.article
      whileHover={{ y: -1 }}
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, delay: index * 0.03 }}
      className={cn(
        'border-b border-gray-100 dark:border-gray-800 last:border-b-0',
        'hover:shadow-sm transition-shadow',
        'post-card-gradient-border',
        post.isPinned && 'bg-gray-50/70 dark:bg-gray-800/70'
      )}
    >
    <div
      role="button"
      tabIndex={0}
      className={cn(
        'group w-full text-left cursor-pointer',
        'px-5 py-5',
        'border-l-2 border-l-transparent',
        'hover:border-l-gray-900 dark:hover:border-l-gray-100',
        'hover:bg-gray-50/80 dark:hover:bg-gray-800/80 transition-all'
      )}
      onClick={() => navigate({ name: 'post', postId: post.id })}
      onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); navigate({ name: 'post', postId: post.id }) } }}
    >
      <div className="flex gap-3">
        {/* Avatar with level badge */}
        <div className="relative shrink-0 mt-0.5">
          <Avatar className="size-10 transition-transform duration-200 group-hover:scale-110">
            <AvatarImage src={post.author?.avatar} alt={post.author?.username} />
            <AvatarFallback className="text-sm bg-gray-100 dark:bg-gray-800">
              {post.author?.username?.charAt(0) || '?'}
            </AvatarFallback>
          </Avatar>
          {authorLevel && (
            <span className="absolute -bottom-0.5 -right-0.5 size-4 rounded-full bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-[10px] flex items-center justify-center shadow-sm leading-none">
              {authorLevel.icon}
            </span>
          )}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          {/* Top row: Category + Pinned */}
          <div className="flex items-center gap-2 mb-1">
            {post.isPinned && (
              <span className="flex items-center gap-0.5 text-xs text-gray-400 dark:text-gray-500">
                <Pin className="size-3" />
                Pinned
              </span>
            )}
            {post.category && (
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  navigate({ name: 'home', categoryId: post.categoryId })
                }}
                className="inline-flex items-center gap-1 text-xs text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-400 transition-colors"
              >
                <span>{post.category.icon}</span>
                <span>{post.category.name}</span>
              </button>
            )}
          </div>

          {/* Title */}
          <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100 leading-snug mb-1 line-clamp-2 group-hover:text-gray-700 dark:group-hover:text-gray-300 transition-colors">
            {post.title}
          </h3>

          {/* Content preview */}
          <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed line-clamp-2 mb-2">
            {truncateText(cleanPreview, 120)}
          </p>

          {/* Tags */}
          {post.tags && post.tags.length > 0 && (
            <div className="flex flex-wrap gap-1 mb-2">
              {post.tags.slice(0, 3).map((tag) => (
                <Badge
                  key={tag.id}
                  variant="secondary"
                  className="text-[10px] font-normal px-1.5 py-0 bg-gray-100 text-gray-500 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700 border-0"
                  onClick={(e) => {
                    e.stopPropagation()
                    navigate({ name: 'home', tag: tag.name })
                  }}
                >
                  {tag.name}
                </Badge>
              ))}
              {post.tags.length > 3 && (
                <span className="text-[10px] text-gray-400 dark:text-gray-500 self-center">
                  +{post.tags.length - 3}
                </span>
              )}
            </div>
          )}

          {/* Image thumbnail grid */}
          {postImages.length > 0 && (
            <div className="flex gap-1.5 mb-2">
              {postImages.slice(0, 3).map((src, i) => (
                <div
                  key={i}
                  className={cn(
                    'relative overflow-hidden rounded-md border border-gray-100 dark:border-gray-800 bg-gray-50 dark:bg-gray-800',
                    postImages.length === 1 && 'w-32 h-20',
                    postImages.length === 2 && 'w-24 h-20',
                    postImages.length >= 3 && 'w-20 h-16',
                    'flex-shrink-0'
                  )}
                >
                  <img
                    src={src}
                    alt=""
                    className="w-full h-full object-cover"
                  />
                  {i === 2 && postImages.length > 3 && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center text-white text-xs font-medium">
                      +{postImages.length - 3}
                    </div>
                  )}
                </div>
              ))}
              <div className="flex items-center self-center">
                <ImageIcon className="size-3 text-gray-400 dark:text-gray-500" />
                <span className="text-[10px] text-gray-400 dark:text-gray-500 ml-0.5">{postImages.length}</span>
              </div>
            </div>
          )}

          {/* File attachment indicator */}
          {postFiles.length > 0 && (
            <div className="flex items-center gap-1.5 mb-2 text-[11px] text-gray-400 dark:text-gray-500">
              📎
              <span>{postFiles.length} attachment{postFiles.length > 1 ? 's' : ''}</span>
              <span className="truncate">
                {postFiles.slice(0, 2).map(f => f.replace(/^[🎵🎬📎]\s*/, '')).join(', ')}
                {postFiles.length > 2 && ' etc.'}
              </span>
            </div>
          )}

          {/* Bottom: Author + Stats */}
          <div className="flex items-center justify-between text-xs text-gray-400 dark:text-gray-500">
            <div className="flex items-center gap-1.5">
              <span
                className="hover:text-gray-600 dark:hover:text-gray-400 transition-colors cursor-pointer"
                onClick={(e) => {
                  e.stopPropagation()
                  navigate({ name: 'user', userId: post.authorId })
                }}
              >
                {post.author?.username}
              </span>
              {post.author?.role === 'official' && (
                <Shield className="size-3 text-rose-500 dark:text-rose-400" />
              )}
              <LevelBadge
                level={post.author?.level ?? 0}
                points={post.author?.points ?? 0}
                role={post.author?.role}
                size="sm"
              />
              {/* Follow button - visible on hover */}
              {!isOwnPost && (
                <button
                  onClick={handleFollowClick}
                  className={cn(
                    'inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] font-medium transition-all opacity-0 group-hover:opacity-100',
                    isFollowed
                      ? 'text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300'
                      : 'text-gray-400 hover:text-gray-900 dark:text-gray-500 dark:hover:text-gray-100'
                  )}
                  title={isFollowed ? 'Unfollow' : 'Follow'}
                >
                  {isFollowed ? (
                    <><UserCheck className="size-3" />Following</>
                  ) : (
                    <><UserPlus className="size-3" />Follow</>
                  )}
                </button>
              )}
              <span>·</span>
              <span className="hidden group-hover:inline" title={formatFullDate(post.createdAt)}>
                {formatFullDate(post.createdAt)}
              </span>
              <span className="group-hover:hidden">
                {formatTimeAgo(post.createdAt)}
              </span>
            </div>
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1 text-gray-500 dark:text-gray-400" title="Reading time">
                <Clock className="size-3.5" />
                {getReadingTime(post.content)} min read
              </span>
              <span className="flex items-center gap-1" title="Views">
                <Eye className="size-3" />
                {post.viewCount}
              </span>
              <span className="flex items-center gap-1" title="Comments">
                <MessageSquare className="size-3" />
                {post.commentCount}
              </span>
              <span className={cn(
                'flex items-center gap-1',
                post.liked && 'text-gray-900 dark:text-white'
              )} title="Like">
                <Heart className={cn('size-3', post.liked && 'fill-current')} />
                {post.likeCount}
              </span>
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  navigator.clipboard.writeText(window.location.origin + '/post/' + post.id)
                  toast.success('Link copied')
                }}
                className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity hover:text-gray-600 dark:hover:text-gray-300"
                title="Share"
              >
                <Share2 className="size-3" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
    </motion.article>
  )
}
