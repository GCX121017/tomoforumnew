import { cn } from '@/lib/utils'
import { formatDistanceToNow, format } from 'date-fns'
import { enUS } from 'date-fns/locale'
import { LEVELS, getLevelFromPoints, type LevelInfo } from '@/lib/levels'

export { cn }

// Re-export level functions from the canonical source (src/lib/levels.ts)
export { type LevelInfo, getLevelFromPoints as getLevelInfo, LEVELS, getLevelProgress } from '@/lib/levels'

// getNextLevelInfo: get the next level above the current one
export function getNextLevelInfo(points: number): LevelInfo | null {
  const current = getLevelFromPoints(points)
  const idx = LEVELS.findIndex((l) => l.level === current.level)
  return idx < LEVELS.length - 1 ? LEVELS[idx + 1] : null
}

export function formatTimeAgo(dateStr: string): string {
  try {
    const date = new Date(dateStr)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffSeconds = Math.floor(diffMs / 1000)

    if (diffSeconds < 60) return 'just now'
    if (diffSeconds < 3600) return `${Math.floor(diffSeconds / 60)} min ago`
    if (diffSeconds < 86400) return `${Math.floor(diffSeconds / 3600)} hr ago`
    if (diffSeconds < 2592000) return `${Math.floor(diffSeconds / 86400)} day${Math.floor(diffSeconds / 86400) !== 1 ? 's' : ''} ago`
    if (diffSeconds < 31536000) return `${Math.floor(diffSeconds / 2592000)} month${Math.floor(diffSeconds / 2592000) !== 1 ? 's' : ''} ago`

    return formatDistanceToNow(date, { addSuffix: true, locale: enUS })
  } catch {
    return ''
  }
}

export function formatDate(dateStr: string): string {
  try {
    const date = new Date(dateStr)
    return format(date, 'yyyy-MM-dd')
  } catch {
    return ''
  }
}

export function formatFullDate(dateStr: string): string {
  try {
    const date = new Date(dateStr)
    return format(date, 'yyyy-MM-dd HH:mm')
  } catch {
    return ''
  }
}

export function truncateText(text: string, maxLen: number): string {
  if (!text || text.length <= maxLen) return text
  return text.slice(0, maxLen) + '...'
}

export function getLevelBadgeText(level: number, role?: string): string {
  if (role === 'official') return '🏛️ Official'
  const levels = ['🫧 Newbie', '🌱 Starter', '🤝 Old Friend', '⭐ Expert', '💎 VIP', '👑 SVIP']
  return levels[Math.min(level, levels.length - 1)] || '🫧 Newbie'
}

export function getReadingTime(text: string): number {
  if (!text) return 1
  // Chinese characters count as 1, English words count as 1
  const chineseChars = (text.match(/[\u4e00-\u9fff]/g) || []).length
  const englishWords = (text.match(/[a-zA-Z]+/g) || []).length
  return Math.max(1, Math.ceil((chineseChars + englishWords * 5) / 500))
}
