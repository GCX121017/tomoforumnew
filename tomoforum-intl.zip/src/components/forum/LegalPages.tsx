'use client'

import { useForumStore } from '@/store/forum'
import { motion } from 'framer-motion'
import {
  ArrowLeft,
  Heart,
  Users,
  Shield,
  Mail,
  MessageCircle,
  Clock,
  Globe,
  Sparkles,
  BookOpen,
  AlertTriangle,
  Scale,
  FileText,
  ChevronRight,
  Github,
} from 'lucide-react'
import ForumLogo from './ForumLogo'

export default function LegalPages() {
  const { currentPage, navigate } = useForumStore()
  const section = currentPage.name === 'legal' ? currentPage.section : 'about'

  return (
    <motion.div
      initial={{ opacity: 0, x: 10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.3 }}
      className="flex-1 max-w-3xl mx-auto w-full"
    >
      {/* Back button */}
      <div className="px-4 py-3">
        <button
          onClick={() => navigate({ name: 'home' })}
          className="flex items-center gap-1.5 text-sm text-gray-400 hover:text-gray-700 dark:text-gray-500 dark:hover:text-gray-300 transition-colors"
        >
          <ArrowLeft className="size-4" />
          Back
        </button>
      </div>

      {/* Tab navigation */}
      <div className="px-4 border-b border-gray-100 dark:border-gray-800 mb-6">
        <div className="flex gap-1">
          {([
            { key: 'about', label: 'About Us', icon: Heart },
            { key: 'terms', label: 'Terms', icon: BookOpen },
            { key: 'contact', label: 'Contact', icon: Mail },
          ] as const).map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => navigate({ name: 'legal', section: key })}
              className={`flex items-center gap-1.5 px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                section === key
                  ? 'border-gray-900 text-gray-900 dark:border-gray-100 dark:text-gray-100'
                  : 'border-transparent text-gray-400 hover:text-gray-600 dark:hover:text-gray-300'
              }`}
            >
              <Icon className="size-4" />
              {label}
            </button>
          ))}
        </div>
      </div>

      <div className="px-4 pb-8">
        {section === 'about' && <AboutSection />}
        {section === 'terms' && <TermsSection />}
        {section === 'contact' && <ContactSection />}
      </div>
    </motion.div>
  )
}

/* ========== About Us ========== */
function AboutSection() {
  return (
    <div className="space-y-8">
      {/* Hero */}
      <div className="text-center py-8">
        <ForumLogo size={80} className="rounded-2xl" />
        <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-2">TomoForum</h1>
        <p className="text-gray-500 dark:text-gray-400 text-sm">In black and white, we write tomorrow</p>
      </div>

      {/* Introduction */}
      <SectionBlock title="Our Story">
        <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed">
          TomoForum was born from a simple idea — in this noisy internet world, we need a quiet, pure corner to share thoughts, exchange knowledge, and make friends.
        </p>
        <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed mt-3">
          We chose black and white as the community's base color, not because we lack color, but because we believe: truly valuable content doesn't need fancy packaging. In simple black and white, every word can be taken seriously, and every voice deserves to be heard.
        </p>
        <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed mt-3">
          The name "TomoForum" (明天后, meaning "After Tomorrow") represents our reflection on the future — not dwelling on the past, not anxious about the present, but with a graceful attitude, exploring the world after tomorrow.
        </p>
      </SectionBlock>

      {/* Mission */}
      <SectionBlock title="Our Mission">
        <div className="grid sm:grid-cols-3 gap-4 mt-2">
          <MissionCard
            icon={<MessageCircle className="size-5" />}
            title="Authentic Expression"
            desc="Encourage users to share their views and experiences genuinely and openly, creating a safe and inclusive environment for communication."
          />
          <MissionCard
            icon={<Users className="size-5" />}
            title="Community Building"
            desc="The community is built together by every member. We respect every user's contribution, making everyone feel a sense of belonging."
          />
          <MissionCard
            icon={<Globe className="size-5" />}
            title="Open Sharing"
            desc="Promote the spread of knowledge and sharing of experiences, so that valuable information can benefit more people who need help."
          />
        </div>
      </SectionBlock>

      {/* Values */}
      <SectionBlock title="Community Values">
        <ul className="space-y-3 mt-2">
          <ValueItem title="Respect" desc="Respect every community member, regardless of their identity, background, or views." />
          <ValueItem title="Friendliness" desc="Communicate with a friendly attitude, avoid aggressive language and personal attacks." />
          <ValueItem title="Authenticity" desc="Share genuine content and views, do not spread false information or mislead others." />
          <ValueItem title="Quality" desc="Focus on content quality, encourage deep thinking and valuable discussions." />
          <ValueItem title="Collaboration" desc="Community members help each other and work together to create a positive atmosphere." />
        </ul>
      </SectionBlock>

      {/* Tech */}
      <SectionBlock title="Tech Stack">
        <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed mt-1">
          TomoForum is built with the following modern web technologies:
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
          {['Next.js 16', 'TypeScript', 'Tailwind CSS', 'Prisma ORM'].map((tech) => (
            <div
              key={tech}
              className="px-3 py-2 rounded-lg bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700 text-center"
            >
              <span className="text-xs font-medium text-gray-700 dark:text-gray-300">{tech}</span>
            </div>
          ))}
        </div>
      </SectionBlock>

      {/* Open Source */}
      <SectionBlock title="Open Source">
        <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed mt-1">
          TomoForum is an open source project under the MIT license. We believe in the power of open source and welcome every developer to contribute and help build a better community platform together.
        </p>
        <a
          href="https://github.com/GCX121017/tomoforumnew"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 mt-4 px-5 py-2.5 bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900 rounded-full text-sm font-medium hover:bg-gray-800 dark:hover:bg-gray-200 transition-colors"
        >
          <Github className="size-4" />
          View Source Code
        </a>
      </SectionBlock>

      {/* Thanks */}
      <div className="text-center py-6">
        <p className="text-sm text-gray-400 dark:text-gray-500">
          Thank you to every TomoForum community member 💫
        </p>
        <p className="text-xs text-gray-300 dark:text-gray-600 mt-1">
          It's because of you that this community keeps getting better
        </p>
      </div>
    </div>
  )
}

/* ========== Terms ========== */
function TermsSection() {
  return (
    <div className="space-y-6">
      <div className="text-center py-6">
        <div className="inline-flex items-center justify-center size-16 rounded-2xl bg-gray-100 dark:bg-gray-800 mb-4">
          <Scale className="size-8 text-gray-600 dark:text-gray-400" />
        </div>
        <h1 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-1">Terms of Service</h1>
        <p className="text-xs text-gray-400 dark:text-gray-500">Last updated: January 2025</p>
      </div>

      {/* Section 1 */}
      <TermsBlock
        number="1"
        title="Acceptance of Terms"
        content={
          <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed">
            By registering and using the TomoForum community, you agree to comply with these Terms of Service. If you do not agree with any part of these terms, please stop using the service. We reserve the right to modify these terms at any time, and the modified terms will take effect after being announced within the community. Continued use of the service constitutes acceptance of the modified terms.
          </p>
        }
      />

      {/* Section 2 */}
      <TermsBlock
        number="2"
        title="User Accounts"
        content={
          <ul className="space-y-2">
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              Users must register with a legitimate username that does not contain illegal, obscene, or discriminatory content.
            </li>
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              Each user may only register one account. Registering multiple accounts or impersonating others is prohibited.
            </li>
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              Users are responsible for keeping their account information secure and are accountable for all activities under their account.
            </li>
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              If you discover your account has been compromised or has security issues, please contact the administrator immediately.
            </li>
          </ul>
        }
      />

      {/* Section 3 */}
      <TermsBlock
        number="3"
        title="Content Guidelines"
        content={
          <div className="space-y-3">
            <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed">
              Content published by users in the community (including but not limited to posts, comments, and images) must comply with the following guidelines:
            </p>
            <div className="grid sm:grid-cols-2 gap-3">
              <RuleCard type="prohibit" items={[
                'Publishing illegal, pornographic, or violent content',
                'Personal attacks or harassment',
                'Spreading false information or rumors',
                'Posting advertisements or spam',
                'Leaking others\' private information',
                'Infringing on others\' intellectual property',
              ]} />
              <RuleCard type="encourage" items={[
                'Sharing valuable knowledge and experiences',
                'Engaging in friendly discussions',
                'Respecting different views and opinions',
                'Helping and answering other users\' questions',
                'Actively maintaining community atmosphere',
                'Providing genuine original content',
              ]} />
            </div>
          </div>
        }
      />

      {/* Section 4 */}
      <TermsBlock
        number="4"
        title="Points & Level System"
        content={
          <ul className="space-y-2">
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              The community implements a points system where users earn points through posting, receiving likes, receiving comments, and receiving bookmarks.
            </li>
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              Points are used to increase user levels. Higher levels represent greater contributions to the community.
            </li>
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              Obtaining points through fraudulent means such as point farming or mutual liking is prohibited. Violators will have their points deducted or accounts banned.
            </li>
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              Official accounts do not participate in point rankings and are used solely for community management and publishing official announcements.
            </li>
          </ul>
        }
      />

      {/* Section 5 */}
      <TermsBlock
        number="5"
        title="Intellectual Property"
        content={
          <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed">
            The intellectual property of original content published by users in the community belongs to the original author. Users authorize TomoForum to use, display, and distribute such content within a reasonable scope. When reproducing others' content, please indicate the source and respect the original author's rights. The community does not bear responsibility for copyright infringement of content published by users. In case of copyright disputes, please contact the administrator.
          </p>
        }
      />

      {/* Section 6 */}
      <TermsBlock
        number="6"
        title="Community Management"
        content={
          <ul className="space-y-2">
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              The management team has the right to edit, delete, or hide content that violates community rules.
            </li>
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              For users who seriously violate the rules, the management team may issue warnings, mute, or ban accounts.
            </li>
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              The management team will enforce community rules fairly and transparently. Users may appeal management decisions through the contact channels.
            </li>
          </ul>
        }
      />

      {/* Section 7 */}
      <TermsBlock
        number="7"
        title="Disclaimer"
        content={
          <ul className="space-y-2">
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              Content published by users in the community only represents the author's personal views and does not represent the platform's position.
            </li>
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              TomoForum does not bear legal responsibility for any losses suffered by users as a result of using the service.
            </li>
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              TomoForum does not bear compensation responsibility for service interruptions or data loss caused by force majeure.
            </li>
          </ul>
        }
      />

      {/* Section 8 */}
      <TermsBlock
        number="8"
        title="Privacy Protection"
        content={
          <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed">
            TomoForum values user privacy protection. We only collect the minimum information necessary to provide services and will not sell or share users' personal information with third parties. Public information such as avatars and usernames will be displayed within the community. For more details, please contact our management team.
          </p>
        }
      />

      <div className="text-center py-4">
        <p className="text-xs text-gray-400 dark:text-gray-500">
          If you have any questions about these Terms of Service, please contact us at <a href="mailto:zl199518@outlook.com" className="text-gray-500 dark:text-gray-400 underline underline-offset-2">zl199518@outlook.com</a>
        </p>
      </div>
    </div>
  )
}

/* ========== Contact ========== */
function ContactSection() {
  return (
    <div className="space-y-6">
      <div className="text-center py-6">
        <div className="inline-flex items-center justify-center size-16 rounded-2xl bg-gray-100 dark:bg-gray-800 mb-4">
          <Mail className="size-8 text-gray-600 dark:text-gray-400" />
        </div>
        <h1 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-1">Contact Us</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400">We welcome your feedback and suggestions at any time</p>
      </div>

      {/* Contact Cards */}
      <div className="grid sm:grid-cols-2 gap-4">
        <ContactCard
          icon={<Mail className="size-5" />}
          title="Email (Recommended)"
          value="zl199518@outlook.com"
          link="mailto:zl199518@outlook.com"
          desc="Preferred contact method, usually responds within 24 hours"
        />
        <ContactCard
          icon={<Mail className="size-5" />}
          title="Backup Email"
          value="guanqpcx@outlook.com"
          link="mailto:guanqpcx@outlook.com"
          desc="Alternative contact method, response may be slower"
        />
        <ContactCard
          icon={<MessageCircle className="size-5" />}
          title="Community Feedback"
          value="Mention @TomoForum in a post"
          desc="Post in the community and @ the official account, we'll follow up promptly"
        />
        <ContactCard
          icon={<Clock className="size-5" />}
          title="Response Time"
          value="1-2 business days"
          desc="Business days prioritized, urgent issues will be addressed ASAP"
        />
        <ContactCard
          icon={<Shield className="size-5" />}
          title="Reports & Complaints"
          value="Via email or community"
          desc="For policy violations, please contact us immediately"
        />
      </div>

      {/* FAQ */}
      <SectionBlock title="FAQ">
        <div className="space-y-4 mt-2">
          <FaqItem
            question="How do I report a violation?"
            answer="You can report to us via email at zl199518@outlook.com, or @ the official account directly in the community. Please provide the relevant post link and specific violation details when reporting, and we will verify and handle it as soon as possible."
          />
          <FaqItem
            question="How do I apply to become an administrator?"
            answer="The community has not yet opened an administrator application channel. We will periodically invite outstanding users to participate in community management based on their activity, contributions, and influence. Continuously contributing to the community is the most important prerequisite."
          />
          <FaqItem
            question="What if I forget how to log in?"
            answer="TomoForum uses a lightweight login method with username + avatar, without passwords. Simply enter your previously registered username to log in automatically. If you encounter issues, please contact the administrator for assistance."
          />
          <FaqItem
            question="Can I migrate or export my data?"
            answer="Self-service data export is not currently supported. If you have personal data migration needs, please contact us via email, and we will assist you within a reasonable scope."
          />
          <FaqItem
            question="How do I delete my account?"
            answer="If you wish to delete your account, please submit a request to us via email at zl199518@outlook.com (recommended) or guanqpcx@outlook.com, and include your username in the email. We will process the account deletion after verifying your identity."
          />
        </div>
      </SectionBlock>

      {/* Message hint */}
      <div className="rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700 p-5 text-center">
        <p className="text-sm text-gray-600 dark:text-gray-300 font-medium mb-1">Still haven't found your answer?</p>
        <p className="text-xs text-gray-400 dark:text-gray-500 mb-4">
          Feel free to contact us via email, we're happy to help
        </p>
        <a
          href="mailto:zl199518@outlook.com"
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900 rounded-full text-sm font-medium hover:bg-gray-800 dark:hover:bg-gray-200 transition-colors"
        >
          <Mail className="size-4" />
          Send Email
        </a>
      </div>
    </div>
  )
}

/* ========== Shared Components ========== */

function SectionBlock({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h2 className="text-base font-semibold text-gray-900 dark:text-gray-100 mb-3 flex items-center gap-2">
        <span className="size-1 rounded-full bg-gray-900 dark:bg-gray-100" />
        {title}
      </h2>
      {children}
    </div>
  )
}

function MissionCard({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className="p-4 rounded-xl bg-gray-50 dark:bg-gray-800/80 border border-gray-100 dark:border-gray-700 text-center">
      <div className="inline-flex items-center justify-center size-10 rounded-xl bg-white dark:bg-gray-700 border border-gray-100 dark:border-gray-600 mb-3 text-gray-600 dark:text-gray-300">
        {icon}
      </div>
      <h3 className="text-sm font-semibold text-gray-800 dark:text-gray-200 mb-1">{title}</h3>
      <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">{desc}</p>
    </div>
  )
}

function ValueItem({ title, desc }: { title: string; desc: string }) {
  return (
    <li className="flex items-start gap-2.5">
      <span className="mt-1 size-1.5 rounded-full bg-gray-900 dark:bg-gray-100 shrink-0" />
      <div>
        <span className="text-sm font-medium text-gray-800 dark:text-gray-200">{title} — </span>
        <span className="text-sm text-gray-500 dark:text-gray-400">{desc}</span>
      </div>
    </li>
  )
}

function TermsBlock({ number, title, content }: { number: string; title: string; content: React.ReactNode }) {
  return (
    <div className="rounded-xl bg-white dark:bg-gray-800/50 border border-gray-100 dark:border-gray-800 p-5">
      <div className="flex items-center gap-2 mb-3">
        <span className="inline-flex items-center justify-center size-6 rounded-md bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900 text-xs font-bold">
          {number}
        </span>
        <h2 className="text-sm font-semibold text-gray-900 dark:text-gray-100">{title}</h2>
      </div>
      {content}
    </div>
  )
}

function RuleCard({ type, items }: { type: 'prohibit' | 'encourage'; items: string[] }) {
  const isProhibit = type === 'prohibit'
  return (
    <div className={`rounded-lg border p-3 ${isProhibit ? 'border-red-100 dark:border-red-900/30 bg-red-50/50 dark:bg-red-950/20' : 'border-green-100 dark:border-green-900/30 bg-green-50/50 dark:bg-green-950/20'}`}>
      <div className={`flex items-center gap-1.5 mb-2 text-xs font-semibold ${isProhibit ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>
        <AlertTriangle className="size-3" />
        {isProhibit ? 'Prohibited' : 'Encouraged'}
      </div>
      <ul className="space-y-1.5">
        {items.map((item, i) => (
          <li key={i} className={`text-xs flex items-start gap-1.5 ${isProhibit ? 'text-red-700/80 dark:text-red-300/80' : 'text-green-700/80 dark:text-green-300/80'}`}>
            <span className="mt-1 size-1 rounded-full bg-current opacity-50 shrink-0" />
            {item}
          </li>
        ))}
      </ul>
    </div>
  )
}

function ContactCard({ icon, title, value, link, desc }: { icon: React.ReactNode; title: string; value: string; link?: string; desc: string }) {
  const content = (
    <div className="p-4 rounded-xl bg-gray-50 dark:bg-gray-800/80 border border-gray-100 dark:border-gray-700 hover:border-gray-200 dark:hover:border-gray-600 transition-colors">
      <div className="flex items-start gap-3">
        <div className="shrink-0 size-10 rounded-xl bg-white dark:bg-gray-700 border border-gray-100 dark:border-gray-600 flex items-center justify-center text-gray-500 dark:text-gray-400">
          {icon}
        </div>
        <div className="min-w-0">
          <p className="text-xs text-gray-400 dark:text-gray-500 mb-0.5">{title}</p>
          <p className="text-sm font-medium text-gray-900 dark:text-gray-100 break-all">{value}</p>
          <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">{desc}</p>
        </div>
      </div>
    </div>
  )

  if (link) {
    return <a href={link} className="block">{content}</a>
  }
  return content
}

function FaqItem({ question, answer }: { question: string; answer: string }) {
  return (
    <div className="rounded-lg bg-gray-50 dark:bg-gray-800/50 border border-gray-100 dark:border-gray-800 p-4">
      <h3 className="text-sm font-medium text-gray-800 dark:text-gray-200 mb-2 flex items-start gap-2">
        <FileText className="size-4 shrink-0 mt-0.5 text-gray-400" />
        {question}
      </h3>
      <p className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed pl-6">{answer}</p>
    </div>
  )
}
