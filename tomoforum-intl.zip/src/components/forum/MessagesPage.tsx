'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { toast } from 'sonner'
import {
  MessageCircle,
  ArrowLeft,
  Send,
  Loader2,
  Pencil,
  RotateCcw,
  Check,
  X,
  Search,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useForumStore, type ChatMessage, type Conversation } from '@/store/forum'
import { formatTimeAgo, getLevelInfo, truncateText } from '@/components/forum/helpers'
import { cn } from '@/lib/utils'
import { EmojiPickerInline } from './EmojiPicker'
import MentionHighlight from './MentionHighlight'

const RECALLED_MARKER = '[Recalled]'
const EDIT_TIME_LIMIT_MINUTES = 2

export default function MessagesPage() {
  const { currentUser, currentPage, navigate } = useForumStore()

  // Extract initial partnerId from page params
  const initialPartnerId = currentPage.name === 'messages'
    ? (currentPage as { partnerId?: string }).partnerId || null
    : null

  // Conversation list state
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [conversationsLoading, setConversationsLoading] = useState(false)

  // Active chat state
  const [activePartnerId, setActivePartnerId] = useState<string | null>(initialPartnerId)
  const [activePartnerName, setActivePartnerName] = useState('')
  const [activePartnerAvatar, setActivePartnerAvatar] = useState('')
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [messagesLoading, setMessagesLoading] = useState(false)
  const [newMessage, setNewMessage] = useState('')
  const [sending, setSending] = useState(false)

  // Edit state
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null)
  const [editContent, setEditContent] = useState('')
  const [editSubmitting, setEditSubmitting] = useState(false)

  // Recall state
  const [recallingId, setRecallingId] = useState<string | null>(null)

  // Mobile: show conversation list or chat
  const [showChatOnMobile, setShowChatOnMobile] = useState(false)

  // Search conversations
  const [searchQuery, setSearchQuery] = useState('')

  // Refs
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null)

  // Fetch conversations
  const fetchConversations = useCallback(async () => {
    if (!currentUser?.id) return
    try {
      const res = await fetch(`/api/messages/conversations?userId=${currentUser.id}`)
      if (res.ok) {
        const data = await res.json()
        setConversations(data)
        // Update total unread in store
        const total = data.reduce((sum: number, c: Conversation) => sum + c.unreadCount, 0)
        useForumStore.getState().setTotalUnreadMessages(total)
      }
    } catch {
      // silent fail
    }
  }, [currentUser?.id])

  // Fetch messages for active chat
  const fetchMessages = useCallback(async () => {
    if (!currentUser?.id || !activePartnerId) return
    setMessagesLoading(true)
    try {
      const res = await fetch(`/api/messages/${activePartnerId}?userId=${currentUser.id}`)
      if (res.ok) {
        const data = await res.json()
        setMessages(data)
      }
    } catch {
      // silent fail
    } finally {
      setMessagesLoading(false)
    }
  }, [currentUser?.id, activePartnerId])

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  // Focus input when opening active chat
  useEffect(() => {
    if (activePartnerId && !messagesLoading) {
      setTimeout(() => inputRef.current?.focus(), 200)
    }
  }, [activePartnerId, messagesLoading])

  // Fetch conversations on mount
  useEffect(() => {
    fetchConversations()
  }, [fetchConversations])

  // Poll conversations every 10 seconds
  useEffect(() => {
    pollRef.current = setInterval(fetchConversations, 10000)
    return () => {
      if (pollRef.current) clearInterval(pollRef.current)
    }
  }, [fetchConversations])

  // Fetch messages when partner changes
  useEffect(() => {
    if (activePartnerId) {
      fetchMessages()
    } else {
      setMessages([])
    }
  }, [activePartnerId, fetchMessages])

  // Poll messages every 5 seconds when chat is active
  useEffect(() => {
    if (!activePartnerId || !currentUser?.id) return
    const interval = setInterval(async () => {
      try {
        const res = await fetch(`/api/messages/${activePartnerId}?userId=${currentUser.id}`)
        if (res.ok) {
          const data = await res.json()
          setMessages(data)
        }
      } catch {
        // silent fail
      }
    }, 5000)
    return () => clearInterval(interval)
  }, [activePartnerId, currentUser?.id])

  // Open a conversation
  const openConversation = useCallback((conv: Conversation) => {
    setActivePartnerId(conv.partner.id)
    setActivePartnerName(conv.partner.username)
    setActivePartnerAvatar(conv.partner.avatar)
    setShowChatOnMobile(true)
    setEditingMessageId(null)
  }, [])

  // Handle initial partnerId from navigation
  useEffect(() => {
    if (initialPartnerId && !activePartnerId) {
      const conv = conversations.find(c => c.partner.id === initialPartnerId)
      if (conv) {
        openConversation(conv)
      }
    }
  }, [initialPartnerId, activePartnerId, conversations, openConversation])

  // Go back to conversation list
  const goBack = () => {
    setActivePartnerId(null)
    setActivePartnerName('')
    setActivePartnerAvatar('')
    setMessages([])
    setShowChatOnMobile(false)
    setEditingMessageId(null)
  }

  // Send message
  const sendMessage = async () => {
    if (!currentUser?.id || !activePartnerId || !newMessage.trim() || sending) return

    const content = newMessage.trim()
    setNewMessage('')
    setSending(true)

    // Optimistic update
    const optimisticMsg: ChatMessage = {
      id: `temp-${Date.now()}`,
      senderId: currentUser.id,
      receiverId: activePartnerId,
      content,
      isRead: false,
      isRecalled: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      sender: { id: currentUser.id, username: currentUser.username, avatar: currentUser.avatar },
    }
    setMessages((prev) => [...prev, optimisticMsg])

    try {
      const res = await fetch(`/api/messages/${activePartnerId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id, content }),
      })

      if (res.ok) {
        const createdMsg = await res.json()
        setMessages((prev) =>
          prev.map((m) => (m.id === optimisticMsg.id ? createdMsg : m))
        )
        fetchConversations()
      } else {
        setMessages((prev) => prev.filter((m) => m.id !== optimisticMsg.id))
        setNewMessage(content)
      }
    } catch {
      setMessages((prev) => prev.filter((m) => m.id !== optimisticMsg.id))
      setNewMessage(content)
    } finally {
      setSending(false)
    }
  }

  // Edit message
  const startEdit = (msg: ChatMessage) => {
    setEditingMessageId(msg.id)
    setEditContent(msg.content)
  }

  const cancelEdit = () => {
    setEditingMessageId(null)
    setEditContent('')
  }

  const submitEdit = async (msgId: string) => {
    if (!currentUser?.id || !editContent.trim() || editSubmitting) return

    setEditSubmitting(true)
    try {
      const res = await fetch(`/api/messages/edit/${msgId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id, content: editContent.trim() }),
      })

      if (res.ok) {
        const updated = await res.json()
        setMessages((prev) =>
          prev.map((m) => (m.id === msgId ? { ...m, content: updated.content } : m))
        )
        toast.success('Message edited')
        cancelEdit()
      } else {
        const data = await res.json().catch(() => ({}))
        toast.error(data.error || 'Edit failed')
      }
    } catch {
      toast.error('Network error')
    } finally {
      setEditSubmitting(false)
    }
  }

  // Recall message
  const recallMessage = async (msgId: string) => {
    if (!currentUser?.id || recallingId) return

    if (!window.confirm('Are you sure you want to recall this message?')) return

    setRecallingId(msgId)
    try {
      const res = await fetch(`/api/messages/edit/${msgId}?userId=${currentUser.id}`, {
        method: 'DELETE',
      })

      if (res.ok) {
        setMessages((prev) =>
          prev.map((m) => (m.id === msgId ? { ...m, content: RECALLED_MARKER } : m))
        )
        fetchConversations()
        toast.success('Message recalled')
      } else {
        const data = await res.json().catch(() => ({}))
        toast.error(data.error || 'Recall failed')
      }
    } catch {
      toast.error('Network error')
    } finally {
      setRecallingId(null)
    }
  }

  // Check if message is within edit time limit
  const canEditOrRecall = (msg: ChatMessage) => {
    if (!currentUser || msg.senderId !== currentUser.id) return false
    if (msg.content === RECALLED_MARKER) return false
    const createdTime = new Date(msg.createdAt).getTime()
    const now = Date.now()
    const diffMinutes = (now - createdTime) / (1000 * 60)
    return diffMinutes <= EDIT_TIME_LIMIT_MINUTES
  }

  // Handle enter key in textarea
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  // Filter conversations by search
  const filteredConversations = conversations.filter(conv =>
    conv.partner.username.toLowerCase().includes(searchQuery.toLowerCase())
  )

  // Get level emoji
  const getPartnerLevelEmoji = (level?: number) => {
    if (!level) return ''
    return getLevelInfo((level - 1) * 10)?.icon || ''
  }

  if (!currentUser) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-gray-400 dark:text-gray-600">
        <MessageCircle className="size-12 mb-3 opacity-40" />
        <p className="text-sm">Log in to view messages</p>
        <Button
          variant="outline"
          className="mt-4 text-sm"
          onClick={() => useForumStore.getState().setShowLoginDialog(true)}
        >
          Go to login
        </Button>
      </div>
    )
  }

  return (
    <div className="h-[calc(100vh-3.5rem)] sm:h-[calc(100vh-3.5rem)] flex flex-col -m-4 sm:-m-0">
      <div className="flex flex-1 overflow-hidden border border-gray-200 dark:border-gray-800 rounded-none sm:rounded-xl bg-white dark:bg-gray-950">
        {/* ===== Conversation List (Sidebar) ===== */}
        <div
          className={cn(
            'w-full md:w-80 lg:w-96 flex-shrink-0 border-r border-gray-200 dark:border-gray-800 flex flex-col',
            showChatOnMobile ? 'hidden md:flex' : 'flex'
          )}
        >
          {/* List Header */}
          <div className="px-4 py-3 border-b border-gray-100 dark:border-gray-800">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <MessageCircle className="h-5 w-5 text-gray-700 dark:text-gray-300" />
                <h2 className="text-base font-semibold text-gray-900 dark:text-gray-100">Messages</h2>
              </div>
              {/* Mobile: no back button here */}
              {/* Desktop: could add new message button */}
            </div>
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 size-3.5 text-gray-400" />
              <Input
                placeholder="Search conversations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 h-8 text-sm bg-gray-50 dark:bg-gray-900 border-gray-200 dark:border-gray-800"
              />
            </div>
          </div>

          {/* Conversation Items */}
          <ScrollArea className="flex-1 overflow-hidden">
            {conversationsLoading ? (
              <div className="flex items-center justify-center py-16">
                <Loader2 className="h-5 w-5 animate-spin text-gray-300 dark:text-gray-600" />
              </div>
            ) : filteredConversations.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-gray-400 dark:text-gray-600">
                <MessageCircle className="size-10 mb-2 opacity-40" />
                <p className="text-sm">{searchQuery ? 'No matching conversations' : 'No messages yet'}</p>
                <p className="text-xs mt-1 text-gray-300 dark:text-gray-700">
                  Add friends to start chatting
                </p>
              </div>
            ) : (
              <div className="flex flex-col">
                {filteredConversations.map((conv) => (
                  <button
                    key={conv.partner.id}
                    className={cn(
                      'flex items-center gap-3 px-4 py-3 transition-colors text-left w-full',
                      activePartnerId === conv.partner.id
                        ? 'bg-gray-50 dark:bg-gray-900'
                        : 'hover:bg-gray-50/80 dark:hover:bg-gray-900/50'
                    )}
                    onClick={() => openConversation(conv)}
                  >
                    <div className="relative shrink-0">
                      <Avatar className="size-11">
                        <AvatarImage src={conv.partner.avatar} alt={conv.partner.username} />
                        <AvatarFallback className="text-xs">
                          {conv.partner.username.slice(0, 1)}
                        </AvatarFallback>
                      </Avatar>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="flex items-center gap-1 text-sm font-medium text-gray-900 dark:text-gray-100 truncate">
                          {conv.partner.username}
                          <span className="text-xs">{getPartnerLevelEmoji(conv.partner.level)}</span>
                        </span>
                        {conv.lastMessage?.createdAt && (
                          <span className="text-[11px] text-gray-400 shrink-0 ml-2">
                            {formatTimeAgo(conv.lastMessage.createdAt)}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center justify-between mt-0.5">
                        <p className="text-xs text-gray-500 dark:text-gray-400 truncate pr-2">
                          {conv.lastMessage
                            ? `${conv.lastMessage.isMine ? 'You: ' : ''}${conv.lastMessage.content === RECALLED_MARKER ? 'Recalled' : truncateText(conv.lastMessage.content, 24)}`
                            : 'No messages yet'}
                        </p>
                        {conv.unreadCount > 0 && (
                          <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-red-500 px-1.5 text-[10px] font-bold text-white shrink-0">
                            {conv.unreadCount > 99 ? '99+' : conv.unreadCount}
                          </span>
                        )}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </ScrollArea>
        </div>

        {/* ===== Chat Area ===== */}
        <div
          className={cn(
            'flex-1 flex flex-col min-w-0',
            !showChatOnMobile ? 'hidden md:flex' : 'flex'
          )}
        >
          {!activePartnerId ? (
            /* Empty state */
            <div className="flex-1 flex flex-col items-center justify-center text-gray-400 dark:text-gray-600">
              <MessageCircle className="size-16 mb-3 opacity-20" />
              <p className="text-sm font-medium">Select a conversation to start chatting</p>
              <p className="text-xs mt-1 text-gray-300 dark:text-gray-700">
                Select a friend from the list
              </p>
            </div>
          ) : (
            <>
              {/* Chat Header */}
              <div className="flex items-center gap-3 px-4 py-3 border-b border-gray-100 dark:border-gray-800 shrink-0">
                {/* Mobile back button */}
                <Button
                  variant="ghost"
                  size="icon"
                  className="md:hidden h-8 w-8 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 shrink-0"
                  onClick={goBack}
                >
                  <ArrowLeft className="h-4 w-4" />
                </Button>
                <Avatar className="size-9 shrink-0">
                  <AvatarImage src={activePartnerAvatar} alt={activePartnerName} />
                  <AvatarFallback className="text-xs">
                    {activePartnerName.slice(0, 1)}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <span className="text-sm font-semibold text-gray-900 dark:text-gray-100">
                    {activePartnerName}
                  </span>
                </div>
                {/* Desktop: View profile button */}
                <Button
                  variant="ghost"
                  size="sm"
                  className="hidden md:flex h-8 text-xs text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100"
                  onClick={() => navigate({ name: 'user', userId: activePartnerId })}
                >
                  View profile
                </Button>
              </div>

              {/* Messages Area */}
              <ScrollArea className="flex-1 overflow-hidden">
                {messagesLoading ? (
                  <div className="flex items-center justify-center h-full">
                    <Loader2 className="h-5 w-5 animate-spin text-gray-300 dark:text-gray-600" />
                  </div>
                ) : messages.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full text-gray-400 dark:text-gray-600">
                    <MessageCircle className="size-10 mb-2 opacity-40" />
                    <p className="text-sm">Start chatting</p>
                    <p className="text-xs mt-1">Send the first message</p>
                  </div>
                ) : (
                  <div className="flex flex-col gap-1 p-4 max-w-3xl mx-auto w-full">
                    {messages.map((msg, index) => {
                      const isMine = msg.senderId === currentUser?.id
                      const isRecalled = msg.content === RECALLED_MARKER
                      const canAction = canEditOrRecall(msg)
                      const showAvatar = index === 0 || messages[index - 1]?.senderId !== msg.senderId
                      const showTime = index === 0 ||
                        (new Date(msg.createdAt).getTime() - new Date(messages[index - 1].createdAt).getTime()) > 3 * 60 * 1000

                      return (
                        <div key={msg.id}>
                          {/* Time separator */}
                          {showTime && (
                            <div className="flex items-center justify-center my-3">
                              <span className="text-[11px] text-gray-400 dark:text-gray-500 bg-gray-100 dark:bg-gray-900 px-3 py-0.5 rounded-full">
                                {formatTimeAgo(msg.createdAt)}
                              </span>
                            </div>
                          )}

                          {isRecalled ? (
                            /* Recalled message */
                            <div className={cn('flex justify-center py-1')}>
                              <span className="text-xs text-gray-400 dark:text-gray-600 bg-gray-50 dark:bg-gray-900 px-3 py-1 rounded-md italic">
                                {isMine ? 'You recalled a message' : 'The other party recalled a message'}
                              </span>
                            </div>
                          ) : (
                            /* Normal message */
                            <motion.div
                              className={cn(
                                'flex items-end gap-2 group',
                                isMine ? 'flex-row-reverse' : 'flex-row'
                              )}
                              initial={{ opacity: 0, y: 6 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ duration: 0.15 }}
                            >
                              {/* Avatar */}
                              {showAvatar && (
                                <Avatar className="size-8 shrink-0">
                                  <AvatarImage src={msg.sender.avatar} alt={msg.sender.username} />
                                  <AvatarFallback className="text-[10px]">
                                    {msg.sender.username.slice(0, 1)}
                                  </AvatarFallback>
                                </Avatar>
                              )}

                              {/* Message bubble + actions */}
                              <div
                                className={cn(
                                  'flex flex-col max-w-[75%]',
                                  isMine ? 'items-end' : 'items-start',
                                  !showAvatar && (isMine ? 'mr-10' : 'ml-10')
                                )}
                              >
                                {/* Editing mode */}
                                {editingMessageId === msg.id ? (
                                  <div className="w-full max-w-sm space-y-2 p-2 rounded-xl bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-800">
                                    <Textarea
                                      value={editContent}
                                      onChange={(e) => setEditContent(e.target.value)}
                                      onKeyDown={(e) => {
                                        if (e.key === 'Enter' && !e.shiftKey) {
                                          e.preventDefault()
                                          submitEdit(msg.id)
                                        }
                                        if (e.key === 'Escape') cancelEdit()
                                      }}
                                      className="text-sm min-h-[60px] resize-none border-gray-200 dark:border-gray-700"
                                      autoFocus
                                      maxLength={2000}
                                    />
                                    <div className="flex items-center gap-2 justify-end">
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        className="h-7 px-2 text-xs text-gray-500"
                                        onClick={cancelEdit}
                                        disabled={editSubmitting}
                                      >
                                        <X className="size-3 mr-1" />
                                        Cancel
                                      </Button>
                                      <Button
                                        size="sm"
                                        className="h-7 px-3 text-xs bg-gray-900 text-white hover:bg-gray-800 dark:bg-gray-100 dark:text-gray-900 dark:hover:bg-gray-200"
                                        onClick={() => submitEdit(msg.id)}
                                        disabled={!editContent.trim() || editSubmitting}
                                      >
                                        {editSubmitting ? (
                                          <Loader2 className="size-3 animate-spin" />
                                        ) : (
                                          <>
                                            <Check className="size-3 mr-1" />
                                            Save
                                          </>
                                        )}
                                      </Button>
                                    </div>
                                  </div>
                                ) : (
                                  <>
                                    {/* Bubble */}
                                    <div
                                      className={cn(
                                        'rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed break-words whitespace-pre-wrap',
                                        isMine
                                          ? 'bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900 rounded-br-md'
                                          : 'bg-gray-100 text-gray-900 dark:bg-gray-800 dark:text-gray-100 rounded-bl-md'
                                      )}
                                    >
                                      <MentionHighlight text={msg.content} />
                                    </div>

                                    {/* Action buttons (hover, only for own messages within time limit) */}
                                    {canAction && (
                                      <div
                                        className={cn(
                                          'flex items-center gap-0.5 mt-0.5 opacity-0 group-hover:opacity-100 transition-opacity',
                                          isMine ? 'flex-row-reverse' : ''
                                        )}
                                      >
                                        <button
                                          onClick={() => startEdit(msg)}
                                          className="flex items-center gap-1 px-1.5 py-0.5 rounded text-[11px] text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                                          title="Edit"
                                        >
                                          <Pencil className="size-3" />
                                        </button>
                                        <button
                                          onClick={() => recallMessage(msg.id)}
                                          disabled={recallingId === msg.id}
                                          className="flex items-center gap-1 px-1.5 py-0.5 rounded text-[11px] text-gray-400 hover:text-red-500 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                                          title="Recall"
                                        >
                                          {recallingId === msg.id ? (
                                            <Loader2 className="size-3 animate-spin" />
                                          ) : (
                                            <RotateCcw className="size-3" />
                                          )}
                                        </button>
                                      </div>
                                    )}

                                    {/* Time */}
                                    <span className="text-[10px] text-gray-400 mt-0.5 px-1">
                                      {formatTimeAgo(msg.createdAt)}
                                    </span>
                                  </>
                                )}
                              </div>
                            </motion.div>
                          )}
                        </div>
                      )
                    })}
                    <div ref={messagesEndRef} />
                  </div>
                )}
              </ScrollArea>

              {/* Input Area */}
              <div className="shrink-0 border-t border-gray-100 dark:border-gray-800 p-3">
                <div className="flex items-end gap-2 max-w-3xl mx-auto">
                  <EmojiPickerInline
                    onSelect={(emoji) => setNewMessage(prev => prev + emoji)}
                  />
                  <Textarea
                    ref={inputRef}
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Type a message... (Enter to send, Shift+Enter for new line)"
                    className="flex-1 min-h-[40px] max-h-32 text-sm resize-none border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50 px-3 py-2.5"
                    disabled={sending}
                    maxLength={2000}
                    rows={1}
                  />
                  <Button
                    size="icon"
                    className="h-10 w-10 shrink-0 bg-gray-900 text-white hover:bg-gray-800 dark:bg-gray-100 dark:text-gray-900 dark:hover:bg-gray-200 disabled:opacity-40 rounded-xl"
                    onClick={sendMessage}
                    disabled={!newMessage.trim() || sending}
                  >
                    {sending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                  </Button>
                </div>
                <p className="text-[10px] text-gray-400 dark:text-gray-600 mt-1.5 text-center">
                  Messages can be edited or recalled within 2 minutes after sending
                </p>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
