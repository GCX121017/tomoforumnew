interface ForumLogoProps {
  size?: number
  className?: string
}

/**
 * TomoForum official Logo SVG
 * Black square + white circle face + two black eyes
 */
export default function ForumLogo({ size = 32, className = '' }: ForumLogoProps) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 100 100"
      width={size}
      height={size}
      className={className}
      aria-label="TomoForum"
    >
      <rect width="100" height="100" rx="20" fill="#000" />
      <circle cx="50" cy="50" r="30" fill="#fff" />
      <circle cx="35" cy="40" r="4" fill="#000" />
      <circle cx="65" cy="40" r="4" fill="#000" />
    </svg>
  )
}
