'use client'

import { useState, useEffect, useRef, useCallback, useMemo } from 'react'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { useForumStore } from '@/store/forum'
import { AtSign, Users } from 'lucide-react'
import { cn } from '@/lib/utils'

interface Friend {
  id: string
  username: string
  avatar: string
}

interface MentionSelectorProps {
  onSelect: (friend: Friend) => void
  onClose: () => void
  query: string
  position: { top: number; left: number }
}

export default function MentionSelector({ onSelect, onClose, query, position }: MentionSelectorProps) {
  const { currentUser } = useForumStore()
  const [friends, setFriends] = useState<Friend[]>([])
  const [loading, setLoading] = useState(false)
  const [selectedIndex, setSelectedIndex] = useState(0)
  const containerRef = useRef<HTMLDivElement>(null)
  const hasFetched = useRef(false)

  // Fetch friends list once
  useEffect(() => {
    if (!currentUser?.id || hasFetched.current) return
    hasFetched.current = true
    let alive = true

    ;(async () => {
      try {
        setLoading(true)
        const res = await fetch(`/api/friends?userId=${currentUser.id}`)
        if (!alive || !res.ok) return
        const data = await res.json()
        // Defensive parsing: always ensure we have an array
        let list: any[] = []
        if (Array.isArray(data)) {
          list = data
        } else if (data && Array.isArray(data.friends)) {
          list = data.friends
        }
        // Map to Friend objects safely
        const mapped: Friend[] = []
        for (const f of list) {
          if (!f || typeof f !== 'object') continue
          mapped.push({
            id: String(f.id || ''),
            username: String(f.username || f.user?.username || ''),
            avatar: String(f.avatar || f.user?.avatar || ''),
          })
        }
        if (alive) setFriends(mapped)
      } catch {
        if (alive) setFriends([])
      } finally {
        if (alive) setLoading(false)
      }
    })()

    return () => { alive = false }
  }, [currentUser?.id])

  // Filter friends by query
  const filtered = useMemo(() => {
    if (!query.trim()) return friends
    const q = query.trim().toLowerCase()
    return friends.filter(f => f.username.toLowerCase().includes(q))
  }, [friends, query])

  // Reset selection when filtered list changes
  useEffect(() => {
    setSelectedIndex(0)
  }, [filtered.length])

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (filtered.length === 0) return
      if (e.key === 'ArrowDown') {
        e.preventDefault()
        setSelectedIndex(prev => Math.min(prev + 1, filtered.length - 1))
      } else if (e.key === 'ArrowUp') {
        e.preventDefault()
        setSelectedIndex(prev => Math.max(prev - 1, 0))
      } else if (e.key === 'Enter' || e.key === 'Tab') {
        e.preventDefault()
        if (filtered[selectedIndex]) {
          onSelect(filtered[selectedIndex])
        }
      } else if (e.key === 'Escape') {
        e.preventDefault()
        onClose()
      }
    }
    document.addEventListener('keydown', handleKeyDown)
    return () => document.removeEventListener('keydown', handleKeyDown)
  }, [filtered, selectedIndex, onSelect, onClose])

  // Click outside to close
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        onClose()
      }
    }
    // Delay to avoid immediate close on the same click that opened it
    const timer = setTimeout(() => {
      document.addEventListener('mousedown', handleClick)
    }, 100)
    return () => {
      clearTimeout(timer)
      document.removeEventListener('mousedown', handleClick)
    }
  }, [onClose])

  return (
    <div
      ref={containerRef}
      className="absolute z-50 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-lg shadow-lg overflow-hidden"
      style={{ top: Math.max(0, position.top), left: Math.max(0, position.left) }}
    >
      {loading ? (
        <div className="px-3 py-4 text-center">
          <div className="size-4 border-2 border-gray-300 dark:border-gray-600 border-t-gray-900 dark:border-t-gray-100 rounded-full animate-spin mx-auto" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="px-3 py-3 text-xs text-gray-400 dark:text-gray-500 text-center">
          {query.trim() ? 'No matching friends found' : (
            <div className="flex flex-col items-center gap-1">
              <Users className="size-5 text-gray-300 dark:text-gray-600" />
              <span>No friends yet, add some first</span>
            </div>
          )}
        </div>
      ) : (
        <>
          <div className="px-3 py-1.5 border-b border-gray-100 dark:border-gray-800">
            <span className="text-[10px] font-medium text-gray-400 dark:text-gray-500 uppercase tracking-wider">
              Select friend{query.trim() ? ` · "${query.trim()}"` : ''}
            </span>
          </div>
          <div className="py-1 max-h-48 overflow-y-auto">
            {filtered.map((friend, i) => (
              <button
                key={friend.id}
                type="button"
                onClick={() => onSelect(friend)}
                className={cn(
                  'w-full flex items-center gap-2.5 px-3 py-2 text-left transition-colors',
                  i === selectedIndex
                    ? 'bg-gray-100 dark:bg-gray-800'
                    : 'hover:bg-gray-50 dark:hover:bg-gray-800/50'
                )}
              >
                <Avatar className="size-6">
                  <AvatarImage src={friend.avatar} alt={friend.username} />
                  <AvatarFallback className="text-[10px] bg-gray-100 dark:bg-gray-800">
                    {friend.username.charAt(0) || '?'}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <span className="text-sm text-gray-900 dark:text-gray-100 truncate block">
                    {friend.username || 'Unknown user'}
                  </span>
                </div>
                <AtSign className="size-3 text-gray-300 dark:text-gray-600 shrink-0" />
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  )
}

/**
 * Hook for @mention detection in textareas.
 * Call handleChange(e) in the textarea's onChange handler.
 * Render <MentionSelector> when selectorProps is non-null.
 */
export function useMention(
  textareaRef: React.RefObject<HTMLTextAreaElement | null>,
  onSelectFriend: (friend: { id: string; username: string; avatar: string }) => void
) {
  const [show, setShow] = useState(false)
  const [query, setQuery] = useState('')
  const [position, setPosition] = useState({ top: 0, left: 0 })
  const [atStartIndex, setAtStartIndex] = useState(-1)

  const close = useCallback(() => {
    setShow(false)
    setQuery('')
    setAtStartIndex(-1)
  }, [])

  const handleChange = useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const textarea = textareaRef.current
    if (!textarea) return

    const value = e.target.value
    const cursorPos = textarea.selectionStart

    // Walk backwards from cursor to find the start of the current word
    let searchStart = cursorPos - 1
    while (searchStart >= 0 && value[searchStart] !== ' ' && value[searchStart] !== '\n') {
      searchStart--
    }
    const word = value.substring(searchStart + 1, cursorPos)

    if (word.startsWith('@') && word.length >= 1) {
      setQuery(word.substring(1))
      setAtStartIndex(searchStart + 1)
      setShow(true)

      // Calculate dropdown position: place it below the @ character
      try {
        const textareaRect = textarea.getBoundingClientRect()
        const parentEl = textarea.closest('.relative') || textarea.parentElement
        const parentRect = parentEl?.getBoundingClientRect() || textareaRect

        // Estimate position based on text before the @ sign
        // Use a simple approach: place below the textarea's top
        const linesBeforeAt = value.substring(0, searchStart + 1).split('\n')
        const currentLine = linesBeforeAt.length - 1
        const charsInLine = linesBeforeAt[linesBeforeAt.length - 1]?.length || 0

        // Estimate pixel position (rough: ~8px per char, ~24px per line)
        const lineHeight = 24
        const charWidth = 8
        const approxX = Math.min(charsInLine * charWidth, (parentRect.width || 300) - 200)
        const approxY = (currentLine + 1) * lineHeight

        setPosition({
          top: Math.min(approxY, textarea.offsetHeight - 50),
          left: Math.max(0, approxX),
        })
      } catch {
        // Fallback: place below the textarea
        setPosition({ top: textarea.offsetHeight + 4, left: 0 })
      }
    } else {
      close()
    }
  }, [textareaRef, close])

  const handleSelect = useCallback((friend: { id: string; username: string; avatar: string }) => {
    if (atStartIndex < 0) return

    // Read the current textarea value from the DOM
    const textarea = textareaRef.current
    if (!textarea) return

    const value = textarea.value
    const cursorPos = textarea.selectionStart

    // Replace the @query text with @username
    const before = value.substring(0, atStartIndex)
    const after = value.substring(cursorPos)
    const newValue = `${before}@${friend.username} ${after}`

    // Call the parent's callback to update state
    onSelectFriend(friend)
    close()

    // Restore focus and cursor position
    setTimeout(() => {
      textarea.focus()
      const newCursorPos = before.length + friend.username.length + 2
      textarea.setSelectionRange(newCursorPos, newCursorPos)
    }, 0)
  }, [textareaRef, atStartIndex, onSelectFriend, close])

  const selectorProps = show
    ? { onSelect: handleSelect, onClose: close, query, position }
    : null

  return { show, handleChange, selectorProps, close }
}
