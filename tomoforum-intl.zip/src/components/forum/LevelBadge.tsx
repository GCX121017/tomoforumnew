'use client'

import { cn } from '@/components/forum/helpers'
import { getUserLevel, getLevelProgress, LEVELS } from '@/lib/levels'
import type { LevelInfo } from '@/lib/levels'

interface LevelBadgeProps {
  level: number
  points?: number
  role?: string
  showProgress?: boolean
  size?: 'sm' | 'md'
}

export default function LevelBadge({
  level: levelProp,
  points = 0,
  role,
  showProgress = false,
  size = 'md',
}: LevelBadgeProps) {
  const levelInfo: LevelInfo = getUserLevel(role || 'user', points)

  const isOfficial = role === 'official'

  const progress = !isOfficial && points > 0 ? getLevelProgress(points) : 0

  // Find next level info for progress bar
  const nextLevelIdx = LEVELS.findIndex((l) => l.level === levelInfo.level) + 1
  const nextLevel = !isOfficial && nextLevelIdx < LEVELS.length ? LEVELS[nextLevelIdx] : null

  return (
    <div className="inline-flex flex-col items-start">
      <span
        className={cn(
          'inline-flex items-center gap-0.5 rounded-full font-medium whitespace-nowrap',
          isOfficial
            ? 'bg-gradient-to-r from-amber-50 to-rose-50 dark:from-amber-900/30 dark:to-rose-900/30 text-rose-600 dark:text-rose-400 border border-rose-200/60 dark:border-rose-800/40'
            : cn(levelInfo.bgColor, levelInfo.color),
          size === 'sm'
            ? 'text-[10px] px-1.5 py-px'
            : 'text-xs px-2 py-0.5'
        )}
      >
        <span className={size === 'sm' ? 'text-[10px]' : 'text-xs'}>{levelInfo.icon}</span>
        <span>{levelInfo.name}</span>
      </span>

      {showProgress && !isOfficial && (
        <div className="mt-1 w-full min-w-[60px]">
          <div className="w-full h-1 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
            <div
              className="h-full bg-gray-600 dark:bg-gray-400 rounded-full transition-all duration-500"
              style={{ width: `${Math.min(progress, 100)}%` }}
            />
          </div>
          {nextLevel && (
            <p className="text-[10px] text-gray-400 dark:text-gray-500 mt-0.5 leading-tight">
              {progress}% → {nextLevel.icon}{nextLevel.name}
            </p>
          )}
        </div>
      )}
    </div>
  )
}
