'use client'

import { useReducer, useEffect, useState, useCallback } from 'react'
import { useForumStore, type Post, type ForumUser } from '@/store/forum'
import { cn, getLevelInfo, getNextLevelInfo, getLevelProgress } from '@/components/forum/helpers'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { Skeleton } from '@/components/ui/skeleton'
import { Button } from '@/components/ui/button'
import PostCard from './PostCard'
import LevelBadge from './LevelBadge'
import PointsDisplay from './PointsDisplay'
import { ArrowLeft, FileText, Bookmark, User, Settings, Users, UserPlus, Info } from 'lucide-react'
import EditProfile from './EditProfile'
import { motion } from 'framer-motion'

interface FollowUser {
  id: string
  username: string
  avatar: string
  bio: string
  level: number
  points: number
  isFollowing?: boolean
}

interface ProfileState {
  user: ForumUser | null
  userPosts: Post[]
  bookmarkedPosts: Post[]
  bookmarkCount: number
  bookmarksLoading: boolean
  loading: boolean
  activeTab: 'posts' | 'bookmarks' | 'following' | 'followers'
  isFollowing: boolean
  followerCount: number
  followingCount: number
  followUsers: FollowUser[]
  followUsersLoading: boolean
  followLoading: boolean
}

type ProfileAction =
  | { type: 'SET_LOADING' }
  | { type: 'SET_USER'; user: ForumUser }
  | { type: 'SET_USER_POSTS'; posts: Post[] }
  | { type: 'SET_BOOKMARKED_POSTS'; posts: Post[] }
  | { type: 'SET_BOOKMARK_COUNT'; value: number }
  | { type: 'SET_BOOKMARKS_LOADING'; value: boolean }
  | { type: 'SET_LOADING_DONE' }
  | { type: 'RESET' }
  | { type: 'SET_TAB'; tab: 'posts' | 'bookmarks' | 'following' | 'followers' }
  | { type: 'SET_IS_FOLLOWING'; value: boolean }
  | { type: 'SET_FOLLOWER_COUNT'; value: number }
  | { type: 'SET_FOLLOWING_COUNT'; value: number }
  | { type: 'SET_FOLLOW_USERS'; users: FollowUser[] }
  | { type: 'SET_FOLLOW_USERS_LOADING'; value: boolean }
  | { type: 'SET_FOLLOW_LOADING'; value: boolean }

function profileReducer(state: ProfileState, action: ProfileAction): ProfileState {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, loading: true }
    case 'SET_USER':
      return { ...state, user: action.user }
    case 'SET_USER_POSTS':
      return { ...state, userPosts: action.posts }
    case 'SET_BOOKMARKED_POSTS':
      return { ...state, bookmarkedPosts: action.posts }
    case 'SET_BOOKMARK_COUNT':
      return { ...state, bookmarkCount: action.value }
    case 'SET_BOOKMARKS_LOADING':
      return { ...state, bookmarksLoading: action.value }
    case 'SET_LOADING_DONE':
      return { ...state, loading: false }
    case 'RESET':
      return {
        ...state,
        user: null,
        userPosts: [],
        bookmarkedPosts: [],
        bookmarkCount: 0,
        bookmarksLoading: false,
        followUsers: [],
        loading: true,
        isFollowing: false,
        followerCount: 0,
        followingCount: 0,
        followUsersLoading: false,
      }
    case 'SET_TAB':
      return { ...state, activeTab: action.tab }
    case 'SET_IS_FOLLOWING':
      return { ...state, isFollowing: action.value }
    case 'SET_FOLLOWER_COUNT':
      return { ...state, followerCount: action.value }
    case 'SET_FOLLOWING_COUNT':
      return { ...state, followingCount: action.value }
    case 'SET_FOLLOW_USERS':
      return { ...state, followUsers: action.users }
    case 'SET_FOLLOW_USERS_LOADING':
      return { ...state, followUsersLoading: action.value }
    case 'SET_FOLLOW_LOADING':
      return { ...state, followLoading: action.value }
    default:
      return state
  }
}

export default function UserProfile() {
  const { currentPage, navigate, currentUser, setShowFriendsPanel } = useForumStore()
  const [editProfileOpen, setEditProfileOpen] = useState(false)
  const [friendStatus, setFriendStatus] = useState<'none' | 'pending' | 'sent' | 'accepted' | 'rejected'>('none')
  const [friendRequestLoading, setFriendRequestLoading] = useState(false)

  const [state, dispatch] = useReducer(profileReducer, {
    user: null,
    userPosts: [],
    bookmarkedPosts: [],
    bookmarkCount: 0,
    bookmarksLoading: false,
    loading: true,
    activeTab: 'posts' as const,
    isFollowing: false,
    followerCount: 0,
    followingCount: 0,
    followUsers: [],
    followUsersLoading: false,
    followLoading: false,
  })

  const userId = currentPage.name === 'user' ? currentPage.userId : ''
  const isOwnProfile = currentUser && currentUser.id === userId

  // Track userId changes using state comparison
  const [prevUserId, setPrevUserId] = useReducer(
    (_prev: string, next: string) => next,
    userId
  )
  if (prevUserId !== userId) {
    setPrevUserId(userId)
    dispatch({ type: 'RESET' })
  }

  // Fetch follow status and counts
  const fetchFollowInfo = useCallback(async (cancelled: boolean) => {
    if (!userId || !currentUser || isOwnProfile) return
    try {
      // Check if current user is following this profile user
      const followersRes = await fetch(`/api/users/${userId}/follows?type=followers&limit=100&viewerId=${currentUser.id}`)
      if (!cancelled && followersRes.ok) {
        const followersData = await followersRes.json()
        const currentFollow = followersData.users?.find((u: FollowUser) => u.id === currentUser.id)
        dispatch({ type: 'SET_IS_FOLLOWING', value: !!currentFollow?.isFollowing })
      }

      // Get follower and following counts
      const followerRes = await fetch(`/api/users/${userId}/follows?type=followers&limit=1`)
      const followingRes = await fetch(`/api/users/${userId}/follows?type=following&limit=1`)
      if (!cancelled) {
        if (followerRes.ok) {
          const followerData = await followerRes.json()
          dispatch({ type: 'SET_FOLLOWER_COUNT', value: followerData.total || 0 })
        }
        if (followingRes.ok) {
          const followingData = await followingRes.json()
          dispatch({ type: 'SET_FOLLOWING_COUNT', value: followingData.total || 0 })
        }
      }
    } catch { /* ignore */ }
  }, [userId, currentUser, isOwnProfile])

  useEffect(() => {
    if (!userId) return
    let cancelled = false
    dispatch({ type: 'SET_LOADING' })
    ;(async () => {
      try {
        const res = await fetch(`/api/users/${userId}`)
        if (!cancelled && res.ok) {
          const data = await res.json()

          dispatch({
            type: 'SET_USER',
            user: {
              id: data.id,
              username: data.username,
              avatar: data.avatar || `https://api.dicebear.com/9.x/notionists/svg?seed=${encodeURIComponent(data.username)}`,
              avatarColor: data.avatarColor || '',
              avatarType: data.avatarType || 'preset',
              bio: data.bio || '',
              role: data.role || 'user',
              level: data.level || 1,
              points: data.points || 0,
              postCount: data._count?.posts || 0,
              commentCount: data._count?.comments || 0,
            },
          })

          const postsRes = await fetch(`/api/posts?authorId=${userId}&limit=50&sort=latest`)
          if (!cancelled && postsRes.ok) {
            const postsData = await postsRes.json()
            dispatch({
              type: 'SET_USER_POSTS',
              posts: postsData.posts || [],
            })
          }

          // Fetch bookmarked posts for this user
          const bookmarksRes = await fetch(`/api/posts?bookmarked=true&userId=${userId}&limit=50`)
          if (!cancelled && bookmarksRes.ok) {
            const bookmarksData = await bookmarksRes.json()
            dispatch({ type: 'SET_BOOKMARKED_POSTS', posts: bookmarksData.posts || [] })
            dispatch({ type: 'SET_BOOKMARK_COUNT', value: bookmarksData.total || 0 })
          }
        }
      } catch { /* ignore */ }

      // Fetch follow info
      await fetchFollowInfo(cancelled)

      if (!cancelled) dispatch({ type: 'SET_LOADING_DONE' })
    })()
    return () => { cancelled = true }
  }, [userId, fetchFollowInfo])

  // Fetch follow users list when tab changes
  useEffect(() => {
    if (!userId || (state.activeTab !== 'followers' && state.activeTab !== 'following')) return
    let cancelled = false
    dispatch({ type: 'SET_FOLLOW_USERS_LOADING', value: true })
    ;(async () => {
      try {
        const viewerParam = currentUser ? `&viewerId=${currentUser.id}` : ''
        const res = await fetch(`/api/users/${userId}/follows?type=${state.activeTab}&limit=50${viewerParam}`)
        if (!cancelled && res.ok) {
          const data = await res.json()
          dispatch({ type: 'SET_FOLLOW_USERS', users: data.users || [] })
        }
      } catch { /* ignore */ }
      if (!cancelled) dispatch({ type: 'SET_FOLLOW_USERS_LOADING', value: false })
    })()
    return () => { cancelled = true }
  }, [userId, state.activeTab, currentUser])

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [userId])

  // Check friend status
  useEffect(() => {
    if (!userId || !currentUser || isOwnProfile) return
    let cancelled = false
    ;(async () => {
      try {
        const res = await fetch(`/api/friends?userId=${currentUser.id}`)
        if (!cancelled && res.ok) {
          const friends = await res.json()
          if (friends.some((f: { id: string }) => f.id === userId)) {
            setFriendStatus('accepted')
            return
          }
        }
        if (cancelled) return
        // Check if there's a pending request (either direction)
        const reqRes = await fetch(`/api/friends/requests?userId=${currentUser.id}`)
        if (!cancelled && reqRes.ok) {
          const requests = await reqRes.json()
          const request = requests.find((r: { fromUserId: string }) => r.fromUserId === userId)
          if (request) {
            setFriendStatus('pending')
            return
          }
        }
        if (!cancelled) setFriendStatus('none')
      } catch {
        if (!cancelled) setFriendStatus('none')
      }
    })()
    return () => { cancelled = true }
  }, [userId, currentUser, isOwnProfile])

  // Handle send friend request
  const handleSendFriendRequest = async () => {
    if (!currentUser || !userId || !state.user || friendRequestLoading) return
    if (friendStatus === 'pending' || friendStatus === 'sent' || friendStatus === 'accepted') return
    setFriendRequestLoading(true)
    try {
      const res = await fetch('/api/friends', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id, targetUsername: state.user.username }),
      })
      if (res.ok) {
        setFriendStatus('sent')
      } else {
        const data = await res.json()
        // If already exists as accepted, update status
        if (data.error?.includes('already friends')) {
          setFriendStatus('accepted')
        }
      }
    } catch { /* ignore */ }
    setFriendRequestLoading(false)
  }

  // Handle follow/unfollow
  const handleToggleFollow = async () => {
    if (!currentUser || !userId || state.followLoading) return
    dispatch({ type: 'SET_FOLLOW_LOADING', value: true })
    try {
      const res = await fetch(`/api/users/${userId}/follow`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ followerId: currentUser.id }),
      })
      if (res.ok) {
        const data = await res.json()
        dispatch({ type: 'SET_IS_FOLLOWING', value: data.following })
        dispatch({ type: 'SET_FOLLOWER_COUNT', value: data.followerCount })
        dispatch({ type: 'SET_FOLLOWING_COUNT', value: data.followingCount })
      }
    } catch { /* ignore */ }
    dispatch({ type: 'SET_FOLLOW_LOADING', value: false })
  }

  // Handle follow from within the user list
  const handleFollowUser = async (targetUserId: string) => {
    if (!currentUser || !targetUserId) return
    try {
      const res = await fetch(`/api/users/${targetUserId}/follow`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ followerId: currentUser.id }),
      })
      if (res.ok) {
        const data = await res.json()
        // Update the user list's isFollowing state
        dispatch({
          type: 'SET_FOLLOW_USERS',
          users: state.followUsers.map((u) =>
            u.id === targetUserId ? { ...u, isFollowing: data.following } : u
          ),
        })
        // Also update own following count if applicable
        if (userId === currentUser.id) {
          dispatch({ type: 'SET_FOLLOWING_COUNT', value: data.followingCount })
        }
      }
    } catch { /* ignore */ }
  }

  if (state.loading) {
    return (
      <div className="flex-1 max-w-3xl mx-auto w-full px-4 py-6">
        <Skeleton className="h-6 w-20 mb-6" />
        <div className="flex items-center gap-4 mb-6">
          <Skeleton className="size-20 rounded-full" />
          <div className="space-y-2 flex-1">
            <Skeleton className="h-6 w-32" />
            <Skeleton className="h-4 w-48" />
          </div>
        </div>
        <div className="space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-20 w-full rounded-lg" />
          ))}
        </div>
      </div>
    )
  }

  if (!state.user) return null

  return (
    <motion.div
      initial={{ opacity: 0, x: 10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.3 }}
      className="flex-1 max-w-3xl mx-auto w-full"
    >
      {/* Back button */}
      <div className="px-4 py-3">
        <button
          onClick={() => navigate({ name: 'home' })}
          className="flex items-center gap-1.5 text-sm text-gray-400 hover:text-gray-700 dark:text-gray-500 dark:hover:text-gray-300 transition-colors"
        >
          <ArrowLeft className="size-4" />
          Back
        </button>
      </div>

      {/* Profile Header */}
      <div className="px-4 pb-5">
        <div className="flex items-start gap-4">
          <div className="relative">
            <Avatar className="size-20">
              <AvatarImage src={state.user.avatar} alt={state.user.username} />
              <AvatarFallback className="text-2xl bg-gray-100 dark:bg-gray-800">
                {state.user.username.charAt(0)}
              </AvatarFallback>
            </Avatar>
            {(() => {
              const level = getLevelInfo(state.user.points ?? 0)
              return (
                <span className="absolute -bottom-1 -right-1 size-6 rounded-full bg-white dark:bg-gray-900 border-2 border-white dark:border-gray-900 shadow-sm text-sm flex items-center justify-center leading-none">
                  {level.icon}
                </span>
              )
            })()}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h1 className="text-xl font-bold text-gray-900 dark:text-gray-100">{state.user.username}</h1>
              <LevelBadge
                level={state.user.level ?? 0}
                points={state.user.points ?? 0}
                role={state.user.role}
                size="md"
              />
              {isOwnProfile && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setEditProfileOpen(true)}
                  className="h-7 w-7 p-0 text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
                >
                  <Settings className="size-3.5" />
                </Button>
              )}
            </div>
            {state.user.bio && (
              <p className="text-sm text-gray-500 dark:text-gray-400 mb-3 leading-relaxed">{state.user.bio}</p>
            )}
            {/* Level & Points Section */}
            <div className="p-3 rounded-lg bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700 mb-3">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5">
                  <span className="text-sm">{getLevelInfo(state.user.points ?? 0).icon}</span>
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{getLevelInfo(state.user.points ?? 0).name}</span>
                </div>
                <PointsDisplay
                  points={state.user.points ?? 0}
                  postCount={state.user.postCount ?? 0}
                  likeReceived={0}
                  commentReceived={0}
                  bookmarkReceived={0}
                  showBreakdown={true}
                  compact={true}
                />
              </div>
              <div className="w-full h-1.5 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gray-700 dark:bg-gray-400 rounded-full transition-all duration-500"
                  style={{ width: `${getLevelProgress(state.user.points ?? 0)}%` }}
                />
              </div>
              {(() => {
                const next = getNextLevelInfo(state.user.points ?? 0)
                const progress = getLevelProgress(state.user.points ?? 0)
                return next ? (
                  <p className="text-[10px] text-gray-400 mt-1.5">{next.minPoints - (state.user.points ?? 0)} points needed for {next.icon} {next.name} ({progress}%)</p>
                ) : (
                  <p className="text-[10px] text-gray-400 mt-1.5">Max level reached (100%)</p>
                )
              })()}
              {/* Points rule info */}
              <div className="mt-2 pt-2 border-t border-gray-200/60 dark:border-gray-700/60">
                <div className="flex items-center gap-1 mb-1">
                  <Info className="size-3 text-gray-400" />
                  <span className="text-[10px] text-gray-400 font-medium">Points Rules</span>
                </div>
                <div className="grid grid-cols-2 gap-x-3 gap-y-0.5 text-[10px] text-gray-400 dark:text-gray-500">
                  <span>📝 Post +10</span>
                  <span>❤️ Like received +2</span>
                  <span>💬 Comment received +3</span>
                  <span>⭐ Bookmark +5</span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-4 flex-wrap">
              <button
                onClick={() => dispatch({ type: 'SET_TAB', tab: 'posts' })}
                className="flex items-center gap-1.5 text-sm text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
              >
                <FileText className="size-4" />
                <span className="font-medium text-gray-700 dark:text-gray-300">{state.user.postCount || 0}</span>
                <span>Posts</span>
              </button>
              <button
                onClick={() => dispatch({ type: 'SET_TAB', tab: 'followers' })}
                className="flex items-center gap-1.5 text-sm text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
              >
                <Users className="size-4" />
                <span className="font-medium text-gray-700 dark:text-gray-300">{state.followerCount}</span>
                <span>Followers</span>
              </button>
              <button
                onClick={() => dispatch({ type: 'SET_TAB', tab: 'following' })}
                className="flex items-center gap-1.5 text-sm text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
              >
                <UserPlus className="size-4" />
                <span className="font-medium text-gray-700 dark:text-gray-300">{state.followingCount}</span>
                <span>Following</span>
              </button>
              {/* Follow Button + Friend Button */}
              {!isOwnProfile && currentUser && (
                <div className="ml-auto flex items-center gap-2">
                  <Button
                    size="sm"
                    disabled={state.followLoading || friendRequestLoading}
                    onClick={handleSendFriendRequest}
                    className={cn(
                      'h-8 px-3 text-xs font-medium transition-all',
                      friendStatus === 'accepted'
                        ? 'bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 dark:hover:bg-emerald-950/50'
                        : friendStatus === 'pending'
                          ? 'bg-amber-50 dark:bg-amber-950/30 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800 cursor-default'
                          : 'bg-transparent border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                    )}
                  >
                    {friendRequestLoading ? (
                      <span className="size-3.5 border-2 border-current border-t-transparent rounded-full animate-spin" />
                    ) : friendStatus === 'accepted' ? (
                      'Friends ✓'
                    ) : friendStatus === 'pending' ? (
                      'Pending'
                    ) : friendStatus === 'rejected' ? (
                      'Add Friend'
                    ) : friendStatus === 'sent' ? (
                      'Pending'
                    ) : (
                      'Add Friend'
                    )}
                  </Button>
                  <Button
                    size="sm"
                    disabled={state.followLoading}
                    onClick={handleToggleFollow}
                    className={cn(
                      'h-8 px-3 text-xs font-medium transition-all',
                      state.isFollowing
                        ? 'bg-gray-900 hover:bg-gray-800 text-white dark:bg-gray-100 dark:hover:bg-gray-200 dark:text-gray-900'
                        : 'bg-transparent border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                    )}
                  >
                    {state.followLoading ? (
                      <span className="size-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                    ) : state.isFollowing ? (
                      'Following'
                    ) : (
                      'Follow'
                    )}
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Edit Profile Dialog */}
      <EditProfile open={editProfileOpen} onOpenChange={setEditProfileOpen} />

      {/* Tabs */}
      <div className="px-4 border-b border-gray-100 dark:border-gray-800">
        <div className="flex gap-4 overflow-x-auto">
          <button
            onClick={() => dispatch({ type: 'SET_TAB', tab: 'posts' })}
            className={cn(
              'pb-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap',
              state.activeTab === 'posts'
                ? 'border-gray-900 text-gray-900 dark:border-gray-100 dark:text-gray-100'
                : 'border-transparent text-gray-400 hover:text-gray-600 dark:hover:text-gray-300'
            )}
          >
            Posts ({state.userPosts.length})
          </button>
          <button
            onClick={() => dispatch({ type: 'SET_TAB', tab: 'bookmarks' })}
            className={cn(
              'pb-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap',
              state.activeTab === 'bookmarks'
                ? 'border-gray-900 text-gray-900 dark:border-gray-100 dark:text-gray-100'
                : 'border-transparent text-gray-400 hover:text-gray-600 dark:hover:text-gray-300'
            )}
          >
            <span className="flex items-center gap-1.5">
              <Bookmark className={cn(
                'size-3.5 transition-transform duration-300',
                state.activeTab === 'bookmarks' && 'scale-110 -translate-y-[1px]'
              )} />
              Bookmarks ({state.bookmarkCount || state.bookmarkedPosts.length})
            </span>
          </button>
          <button
            onClick={() => dispatch({ type: 'SET_TAB', tab: 'following' })}
            className={cn(
              'pb-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap',
              state.activeTab === 'following'
                ? 'border-gray-900 text-gray-900 dark:border-gray-100 dark:text-gray-100'
                : 'border-transparent text-gray-400 hover:text-gray-600 dark:hover:text-gray-300'
            )}
          >
            <span className="flex items-center gap-1.5">
              <UserPlus className="size-3.5" />
              Following ({state.followingCount})
            </span>
          </button>
          <button
            onClick={() => dispatch({ type: 'SET_TAB', tab: 'followers' })}
            className={cn(
              'pb-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap',
              state.activeTab === 'followers'
                ? 'border-gray-900 text-gray-900 dark:border-gray-100 dark:text-gray-100'
                : 'border-transparent text-gray-400 hover:text-gray-600 dark:hover:text-gray-300'
            )}
          >
            <span className="flex items-center gap-1.5">
              <Users className="size-3.5" />
              Followers ({state.followerCount})
            </span>
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-lg mt-3 overflow-hidden">
        {state.activeTab === 'posts' && (
          state.userPosts.length === 0 ? (
            <div className="py-12 text-center text-gray-400 text-sm">No posts yet</div>
          ) : (
            state.userPosts.map((post, index) => (
              <PostCard key={post.id} post={post} index={index} />
            ))
          )
        )}

        {state.activeTab === 'bookmarks' && (
          <div>
            {/* Bookmarks header label */}
            <div className="flex items-center gap-2 px-4 py-3 border-b border-gray-50 dark:border-gray-800/50">
              <Bookmark className="size-4 text-gray-400" />
              <span className="text-sm text-gray-500 dark:text-gray-400">Bookmarked Posts</span>
              <span className="text-xs text-gray-300 dark:text-gray-600">{state.bookmarkCount || state.bookmarkedPosts.length}</span>
            </div>
            {/* Bookmarks list */}
            {state.loading ? (
              <div className="divide-y divide-gray-50 dark:divide-gray-800">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="px-4 py-3">
                    <Skeleton className="h-4 w-3/4 mb-2" />
                    <Skeleton className="h-3 w-1/2" />
                  </div>
                ))}
              </div>
            ) : state.bookmarkedPosts.length === 0 ? (
              <div className="py-16 flex flex-col items-center gap-3">
                <div className="size-12 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
                  <Bookmark className="size-5 text-gray-300 dark:text-gray-600" />
                </div>
                <p className="text-sm text-gray-400 dark:text-gray-500">No bookmarked posts yet</p>
                <p className="text-xs text-gray-300 dark:text-gray-600">Click the bookmark icon on any post to save it</p>
              </div>
            ) : (
              state.bookmarkedPosts.map((post, index) => (
                <PostCard key={post.id} post={post} index={index} />
              ))
            )}
          </div>
        )}

        {(state.activeTab === 'followers' || state.activeTab === 'following') && (
          <div className="divide-y divide-gray-50 dark:divide-gray-800">
            {state.followUsersLoading ? (
              // Loading skeleton for user list
              Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="flex items-center gap-3 px-4 py-3">
                  <Skeleton className="size-10 rounded-full shrink-0" />
                  <div className="flex-1 space-y-1.5">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-3 w-40" />
                  </div>
                  <Skeleton className="h-7 w-14 rounded-full" />
                </div>
              ))
            ) : state.followUsers.length === 0 ? (
              <div className="py-12 text-center text-gray-400 text-sm">
                {state.activeTab === 'followers' ? 'No followers yet' : 'Not following anyone'}
              </div>
            ) : (
              state.followUsers.map((fu) => (
                <div
                  key={fu.id}
                  className="flex items-center gap-3 px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors"
                >
                  <button
                    onClick={() => navigate({ name: 'user', userId: fu.id })}
                    className="shrink-0"
                  >
                    <Avatar className="size-10">
                      <AvatarImage src={fu.avatar} alt={fu.username} />
                      <AvatarFallback className="text-sm bg-gray-100 dark:bg-gray-800">
                        {fu.username.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                  </button>
                  <button
                    onClick={() => navigate({ name: 'user', userId: fu.id })}
                    className="flex-1 min-w-0 text-left"
                  >
                    <div className="flex items-center gap-1.5">
                      <span className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">
                        {fu.username}
                      </span>
                      <span className="text-xs">{getLevelInfo(fu.points).icon}</span>
                    </div>
                    {fu.bio ? (
                      <p className="text-xs text-gray-400 truncate mt-0.5">{fu.bio}</p>
                    ) : (
                      <p className="text-xs text-gray-300 dark:text-gray-600 mt-0.5">No bio</p>
                    )}
                  </button>
                  {currentUser && fu.id !== currentUser.id && (
                    <Button
                      size="sm"
                      variant={fu.isFollowing ? 'default' : 'outline'}
                      onClick={(e) => {
                        e.stopPropagation()
                        handleFollowUser(fu.id)
                      }}
                      className={cn(
                        'h-7 px-3 text-xs shrink-0',
                        fu.isFollowing
                          ? 'bg-gray-900 hover:bg-gray-800 text-white dark:bg-gray-100 dark:hover:bg-gray-200 dark:text-gray-900'
                          : 'border-gray-300 dark:border-gray-600 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
                      )}
                    >
                      {fu.isFollowing ? 'Following' : 'Follow'}
                    </Button>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </motion.div>
  )
}
