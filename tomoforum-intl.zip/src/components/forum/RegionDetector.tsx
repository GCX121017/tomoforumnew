'use client'

import { useState, useEffect } from 'react'
import { X, MapPin } from 'lucide-react'

// Multi-source IP detection with fallback
async function detectCountry(): Promise<string | null> {
  const sources: { url: string; extract: (data: any) => string | null }[] = [
    {
      url: 'https://ipwho.is/',
      extract: (d) => d?.country_code ?? null,
    },
    {
      url: 'https://ipapi.co/json/',
      extract: (d) => d?.country_code ?? null,
    },
    {
      url: 'https://freeipapi.com/api/json',
      extract: (d) => d?.countryCode ?? null,
    },
  ]

  for (const source of sources) {
    try {
      const controller = new AbortController()
      const timeout = setTimeout(() => controller.abort(), 4000)
      const res = await fetch(source.url, {
        signal: controller.signal,
        headers: { 'Accept': 'application/json' },
      })
      clearTimeout(timeout)

      if (!res.ok) continue
      const data = await res.json()
      const code = source.extract(data)
      if (code && code.length === 2) return code
    } catch {
      // Try next source
    }
  }

  return null
}

export default function RegionDetector() {
  const [showBanner, setShowBanner] = useState(false)
  const [dismissed, setDismissed] = useState(false)

  useEffect(() => {
    const dismissedKey = 'tomoforum_region_dismissed'
    if (localStorage.getItem(dismissedKey)) return

    ;(async () => {
      try {
        const countryCode = await detectCountry()
        if (countryCode === 'CN') {
          setShowBanner(true)
        }
      } catch {
        // Silently fail
      }
    })()
  }, [])

  const handleDismiss = () => {
    setDismissed(true)
    setShowBanner(false)
    localStorage.setItem('tomoforum_region_dismissed', '1')
  }

  if (!showBanner || dismissed) return null

  return (
    <div className="fixed top-0 left-0 right-0 z-[9999] animate-slide-down">
      <div className="bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-950/80 dark:to-orange-950/80 border-b border-amber-200 dark:border-amber-800 backdrop-blur-sm">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          <div className="flex items-start gap-3 flex-1 min-w-0">
            <div className="shrink-0 mt-0.5">
              <MapPin className="size-5 text-amber-600 dark:text-amber-400" />
            </div>
            <div className="min-w-0">
              <p className="text-sm font-medium text-amber-900 dark:text-amber-100">
                检测到您在中国大陆 · Detected you are in Mainland China
              </p>
              <p className="text-xs text-amber-700 dark:text-amber-300 mt-0.5">
                前往{' '}
                <a
                  href="https://mintianhou.netlify.app"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="underline font-medium hover:text-amber-900 dark:hover:text-amber-100 transition-colors"
                >
                  mintianhou.netlify.app
                </a>
                {' '}可获得更佳体验 · Visit{' '}
                <a
                  href="https://mintianhou.netlify.app"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="underline font-medium hover:text-amber-900 dark:hover:text-amber-100 transition-colors"
                >
                  mintianhou.netlify.app
                </a>
                {' '}for a better experience
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleDismiss}
              className="text-xs px-3 py-1.5 rounded-md bg-amber-100 dark:bg-amber-900/50 text-amber-800 dark:text-amber-200 hover:bg-amber-200 dark:hover:bg-amber-900/80 transition-colors font-medium"
            >
              Continue / 继续
            </button>
            <button
              onClick={handleDismiss}
              className="p-1 rounded-md text-amber-400 hover:text-amber-600 dark:hover:text-amber-300 transition-colors"
              aria-label="Dismiss"
            >
              <X className="size-4" />
            </button>
          </div>
        </div>
      </div>
      {/* Spacer to push content down */}
      <div className="h-[88px] md:h-[76px]" />
    </div>
  )
}
