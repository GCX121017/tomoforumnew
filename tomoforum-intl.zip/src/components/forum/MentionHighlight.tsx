'use client'

import { useEffect, useState, useMemo, useCallback } from 'react'
import { useForumStore } from '@/store/forum'
import { toast } from 'sonner'

/** Regex matching @mention: @ followed by CJK chars, letters, numbers, underscores */
const MENTION_REGEX = /@([a-zA-Z0-9_\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]{1,20})/g

export interface ResolvedUser {
  id: string
  username: string
  avatar: string
}

/** Global cache for resolved mentions to avoid repeated API calls */
const mentionCache: Record<string, ResolvedUser> = {}
const pendingFetches: Record<string, Promise<void>> = {}

/**
 * Resolve mention display names to user IDs via API.
 * Results are cached globally for the session.
 */
async function resolveMentions(names: string[]): Promise<Record<string, ResolvedUser>> {
  // Return cached results
  const result: Record<string, ResolvedUser> = {}
  const uncached: string[] = []

  for (const name of names) {
    if (mentionCache[name]) {
      result[name] = mentionCache[name]
    } else if (!uncached.includes(name)) {
      uncached.push(name)
    }
  }

  if (uncached.length === 0) return result

  // Deduplicate pending fetches
  const cacheKey = uncached.sort().join(',')
  if (pendingFetches[cacheKey]) {
    await pendingFetches[cacheKey]
    // Return from cache after pending resolves
    for (const name of names) {
      if (mentionCache[name]) result[name] = mentionCache[name]
    }
    return result
  }

  const fetchPromise = (async () => {
    try {
      const res = await fetch(`/api/mentions/resolve?names=${encodeURIComponent(uncached.join(','))}`)
      if (res.ok) {
        const data = await res.json()
        for (const [name, user] of Object.entries(data)) {
          mentionCache[name] = user as ResolvedUser
        }
      }
    } catch {
      // silent fail
    }
  })()

  pendingFetches[cacheKey] = fetchPromise
  await fetchPromise
  delete pendingFetches[cacheKey]

  // Return from cache after fetch
  for (const name of names) {
    if (mentionCache[name]) result[name] = mentionCache[name]
  }
  return result
}

interface MentionHighlightProps {
  text: string
  className?: string
}

/**
 * Renders text with @mentions highlighted and clickable.
 * Clicking an @mention navigates to the mentioned user's profile.
 */
export default function MentionHighlight({ text, className }: MentionHighlightProps) {
  const navigate = useForumStore(s => s.navigate)
  const [resolved, setResolved] = useState<Record<string, ResolvedUser>>({})

  // Extract all @mentions from text
  const mentions = useMemo(() => {
    const found: string[] = []
    let match: RegExpExecArray | null
    const regex = new RegExp(MENTION_REGEX.source, MENTION_REGEX.flags)
    while ((match = regex.exec(text)) !== null) {
      const name = match[1]
      if (!found.includes(name)) found.push(name)
    }
    return found
  }, [text])

  // Resolve mentions on mount
  useEffect(() => {
    if (mentions.length === 0) return
    let cancelled = false

    resolveMentions(mentions).then(data => {
      if (!cancelled && Object.keys(data).length > 0) {
        setResolved(prev => ({ ...prev, ...data }))
      }
    })

    return () => { cancelled = true }
  }, [mentions])

  const handleClick = useCallback((username: string) => {
    const user = resolved[username]
    if (user) {
      navigate({ name: 'user', userId: user.id })
    } else {
      toast.info('User not found')
    }
  }, [resolved, navigate])

  // Parse text into segments
  const segments = useMemo(() => {
    const parts: Array<{ type: 'text'; content: string } | { type: 'mention'; name: string }> = []
    let lastIndex = 0
    const regex = new RegExp(MENTION_REGEX.source, MENTION_REGEX.flags)
    let match: RegExpExecArray | null

    while ((match = regex.exec(text)) !== null) {
      // Text before mention
      if (match.index > lastIndex) {
        parts.push({ type: 'text', content: text.substring(lastIndex, match.index) })
      }
      parts.push({ type: 'mention', name: match[1] })
      lastIndex = match.index + match[0].length
    }

    // Remaining text
    if (lastIndex < text.length) {
      parts.push({ type: 'text', content: text.substring(lastIndex) })
    }

    return parts
  }, [text])

  return (
    <span className={className}>
      {segments.map((seg, i) => {
        if (seg.type === 'text') {
          return <span key={i}>{seg.content}</span>
        }
        const isResolved = !!resolved[seg.name]
        return (
          <button
            key={i}
            type="button"
            onClick={(e) => {
              e.stopPropagation()
              handleClick(seg.name)
            }}
            className={`
              inline-flex items-center gap-0.5 px-0.5 rounded
              font-medium transition-colors cursor-pointer
              ${isResolved
                ? 'text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 hover:bg-blue-50 dark:hover:bg-blue-900/20'
                : 'text-blue-500/60 dark:text-blue-400/50'
              }
            `}
            title={isResolved ? `View ${seg.name}'s profile` : '@' + seg.name}
          >
            <span>@</span>
            <span>{seg.name}</span>
          </button>
        )
      })}
    </span>
  )
}

/**
 * Utility: extract @mention names from a string.
 */
export function extractMentionNames(text: string): string[] {
  const found: string[] = []
  const regex = new RegExp(MENTION_REGEX.source, MENTION_REGEX.flags)
  let match: RegExpExecArray | null
  while ((match = regex.exec(text)) !== null) {
    if (!found.includes(match[1])) found.push(match[1])
  }
  return found
}

/**
 * ReactMarkdown component: render paragraph text with @mention highlighting.
 * Usage in ReactMarkdown components={{ p: MentionParagraph }}
 */
export function MentionParagraph({
  children,
  ...props
}: React.HTMLAttributes<HTMLParagraphElement> & { children?: React.ReactNode }) {
  return (
    <p {...props}>
      {typeof children === 'string' ? (
        <InlineMentionText text={children} />
      ) : Array.isArray(children) ? (
        children.map((child, i) =>
          typeof child === 'string' ? (
            <InlineMentionText key={i} text={child} />
          ) : (
            <span key={i}>{child}</span>
          )
        )
      ) : (
        children
      )}
    </p>
  )
}

/**
 * ReactMarkdown component: render span/text nodes with @mention highlighting.
 */
export function MentionSpan({
  children,
  ...props
}: React.HTMLAttributes<HTMLSpanElement> & { children?: React.ReactNode }) {
  return (
    <span {...props}>
      {typeof children === 'string' ? (
        <InlineMentionText text={children} />
      ) : children}
    </span>
  )
}

/**
 * ReactMarkdown component: render list item text with @mention highlighting.
 */
export function MentionListItem({
  children,
  ...props
}: React.HTMLAttributes<HTMLLIElement> & { children?: React.ReactNode }) {
  return (
    <li {...props}>
      {typeof children === 'string' ? (
        <InlineMentionText text={children} />
      ) : Array.isArray(children) ? (
        children.map((child, i) =>
          typeof child === 'string' ? (
            <InlineMentionText key={i} text={child} />
          ) : (
            <span key={i}>{child}</span>
          )
        )
      ) : (
        children
      )}
    </li>
  )
}

/**
 * ReactMarkdown component: render blockquote text with @mention highlighting.
 */
export function MentionBlockquote({
  children,
  ...props
}: React.HTMLAttributes<HTMLQuoteElement> & { children?: React.ReactNode }) {
  return (
    <blockquote {...props}>
      {typeof children === 'string' ? (
        <InlineMentionText text={children} />
      ) : Array.isArray(children) ? (
        children.map((child, i) =>
          typeof child === 'string' ? (
            <InlineMentionText key={i} text={child} />
          ) : (
            <span key={i}>{child}</span>
          )
        )
      ) : (
        children
      )}
    </blockquote>
  )
}

/**
 * Inline version of MentionHighlight for use inside ReactMarkdown components.
 * Does not wrap in an extra element, just returns the parsed content.
 */
function InlineMentionText({ text }: { text: string }) {
  const navigate = useForumStore(s => s.navigate)
  const [resolved, setResolved] = useState<Record<string, ResolvedUser>>({})

  const mentions = useMemo(() => extractMentionNames(text), [text])

  useEffect(() => {
    if (mentions.length === 0) return
    let cancelled = false

    resolveMentions(mentions).then(data => {
      if (!cancelled && Object.keys(data).length > 0) {
        setResolved(prev => ({ ...prev, ...data }))
      }
    })

    return () => { cancelled = true }
  }, [mentions])

  const handleClick = useCallback((e: React.MouseEvent, username: string) => {
    e.stopPropagation()
    const user = resolved[username]
    if (user) {
      navigate({ name: 'user', userId: user.id })
    } else {
      toast.info('User not found')
    }
  }, [resolved, navigate])

  const segments = useMemo(() => {
    const parts: Array<{ type: 'text'; content: string } | { type: 'mention'; name: string }> = []
    let lastIndex = 0
    const regex = new RegExp(MENTION_REGEX.source, MENTION_REGEX.flags)
    let match: RegExpExecArray | null

    while ((match = regex.exec(text)) !== null) {
      if (match.index > lastIndex) {
        parts.push({ type: 'text', content: text.substring(lastIndex, match.index) })
      }
      parts.push({ type: 'mention', name: match[1] })
      lastIndex = match.index + match[0].length
    }

    if (lastIndex < text.length) {
      parts.push({ type: 'text', content: text.substring(lastIndex) })
    }

    return parts
  }, [text])

  return (
    <>
      {segments.map((seg, i) => {
        if (seg.type === 'text') {
          return <span key={i}>{seg.content}</span>
        }
        const isResolved = !!resolved[seg.name]
        return (
          <span
            key={i}
            role="button"
            onClick={(e) => handleClick(e, seg.name)}
            className={`
              inline cursor-pointer font-medium transition-colors
              ${isResolved
                ? 'text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 hover:bg-blue-50 dark:hover:bg-blue-900/20 px-0.5 rounded'
                : 'text-blue-500/60 dark:text-blue-400/50'
              }
            `}
            title={isResolved ? `View ${seg.name}'s profile` : undefined}
          >
            @{seg.name}
          </span>
        )
      })}
    </>
  )
}
