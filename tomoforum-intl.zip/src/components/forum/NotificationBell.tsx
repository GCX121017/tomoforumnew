'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { Bell, Check, CheckCheck, Heart, MessageCircle, MessageSquare, AtSign, UserPlus, UserCheck, Bookmark, Send } from 'lucide-react'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { useForumStore } from '@/store/forum'
import { formatTimeAgo } from '@/components/forum/helpers'
import { motion, AnimatePresence } from 'framer-motion'
import { cn } from '@/components/forum/helpers'

function getNotificationIcon(type: string) {
  switch (type) {
    case 'like':
      return <Heart className="size-3.5 text-red-500" />
    case 'comment':
      return <MessageCircle className="size-3.5 text-blue-500 dark:text-blue-400" />
    case 'reply':
      return <MessageSquare className="size-3.5 text-green-500 dark:text-green-400" />
    case 'mention':
      return <AtSign className="size-3.5 text-orange-500 dark:text-orange-400" />
    case 'follow':
      return <UserPlus className="size-3.5 text-purple-500 dark:text-purple-400" />
    case 'friend_request':
      return <UserPlus className="size-3.5 text-amber-500 dark:text-amber-400" />
    case 'friend_accept':
      return <UserCheck className="size-3.5 text-emerald-500 dark:text-emerald-400" />
    case 'bookmark':
      return <Bookmark className="size-3.5 text-yellow-500 dark:text-yellow-400" />
    case 'private_message':
      return <Send className="size-3.5 text-sky-500 dark:text-sky-400" />
    default:
      return <Bell className="size-3.5 text-gray-500 dark:text-gray-400" />
  }
}

export default function NotificationBell() {
  const {
    currentUser,
    notifications,
    setNotifications,
    unreadCount,
    setUnreadCount,
    navigate,
    showNotifications,
    setShowNotifications,
  } = useForumStore()

  const open = showNotifications
  const setOpen = setShowNotifications
  const [loading, setLoading] = useState(false)
  const [markingAll, setMarkingAll] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)
  const fetchIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const fetchNotifications = useCallback(async () => {
    if (!currentUser) return
    try {
      const [listRes, countRes] = await Promise.all([
        fetch(`/api/notifications?userId=${currentUser.id}`),
        fetch(`/api/notifications?userId=${currentUser.id}&unread=true`),
      ])
      const [listData, countData] = await Promise.all([listRes.json(), countRes.json()])
      if (listRes.ok) setNotifications(listData)
      if (countRes.ok) setUnreadCount(countData.count)
    } catch {
      // silently ignore
    }
  }, [currentUser, setNotifications, setUnreadCount])

  const fetchUnreadCount = useCallback(async () => {
    if (!currentUser) return
    try {
      const res = await fetch(`/api/notifications?userId=${currentUser.id}&unread=true`)
      const data = await res.json()
      if (res.ok) setUnreadCount(data.count)
    } catch {
      // silently ignore
    }
  }, [currentUser, setUnreadCount])

  // Fetch full notifications when dropdown opens
  useEffect(() => {
    if (open && currentUser) {
      setLoading(true)
      fetchNotifications().finally(() => setLoading(false))
    }
  }, [open, currentUser, fetchNotifications])

  // Poll for unread count periodically when logged in
  useEffect(() => {
    if (currentUser) {
      fetchUnreadCount()
      fetchIntervalRef.current = setInterval(fetchUnreadCount, 15000)
    }
    return () => {
      if (fetchIntervalRef.current) clearInterval(fetchIntervalRef.current)
    }
  }, [currentUser, fetchUnreadCount])

  // Close dropdown on outside click
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setOpen(false)
      }
    }
    if (open) {
      document.addEventListener('mousedown', handleClickOutside)
    }
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [open])

  const markAsRead = async (notificationId: string, postId: string | null) => {
    if (!currentUser) return
    try {
      await fetch(`/api/notifications/${notificationId}/read`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id }),
      })
      setNotifications(
        notifications.map((n) =>
          n.id === notificationId ? { ...n, isRead: true } : n
        )
      )
      setUnreadCount(Math.max(0, unreadCount - 1))
      if (postId) {
        navigate({ name: 'post', postId })
        setOpen(false)
      }
    } catch {
      // silently ignore
    }
  }

  const handleNotificationClick = async (notification: typeof notifications[0]) => {
    // Mark as read first
    if (!notification.isRead) {
      await markAsRead(notification.id, notification.postId)
    }
    // For friend_request, open friends panel
    if (notification.type === 'friend_request') {
      const { setShowFriendsPanel } = useForumStore.getState()
      setShowFriendsPanel(true)
      setOpen(false)
      return
    }
    // For private_message, navigate to messages page with partner
    if (notification.type === 'private_message') {
      navigate({ name: 'messages', partnerId: notification.fromUserId })
      setOpen(false)
      return
    }
    // For other types with postId, navigate
    if (notification.postId) {
      navigate({ name: 'post', postId: notification.postId })
      setOpen(false)
    }
  }

  const markAllAsRead = async () => {
    if (!currentUser) return
    setMarkingAll(true)
    try {
      await fetch('/api/notifications/read-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id }),
      })
      setNotifications(notifications.map((n) => ({ ...n, isRead: true })))
      setUnreadCount(0)
    } catch {
      // silently ignore
    } finally {
      setMarkingAll(false)
    }
  }

  if (!currentUser) return null

  return (
    <div className="relative" ref={dropdownRef}>
      {/* Bell button */}
      <button
        onClick={() => setOpen(!open)}
        className={cn(
          'relative size-9 flex items-center justify-center rounded-md transition-colors',
          'hover:bg-gray-100 dark:hover:bg-gray-800',
          'text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100'
        )}
        aria-label="Notifications"
      >
        <Bell className="size-4" />
        {unreadCount > 0 && (
          <motion.span
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className={cn(
              'absolute -top-0.5 -right-0.5 flex items-center justify-center',
              'min-w-[16px] h-4 px-1 rounded-full',
              'bg-red-500 text-white text-[10px] font-bold leading-none',
              'badge-pulse',
              unreadCount > 9 && 'min-w-[18px]'
            )}
          >
            {unreadCount > 99 ? '99+' : unreadCount}
          </motion.span>
        )}
      </button>

      {/* Dropdown panel */}
      <AnimatePresence>
        {open && (
          <>
            {/* Backdrop for mobile */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-40 md:hidden"
              onClick={() => setOpen(false)}
            />

            <motion.div
              initial={{ opacity: 0, y: -8, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -8, scale: 0.96 }}
              transition={{ duration: 0.15, ease: 'easeOut' }}
              className={cn(
                'absolute right-0 top-full mt-2 z-50',
                'w-80 sm:w-96 max-h-[420px]',
                'bg-white dark:bg-gray-900',
                'border border-gray-200 dark:border-gray-800',
                'rounded-xl shadow-lg shadow-gray-200/50 dark:shadow-black/30',
                'overflow-hidden flex flex-col'
              )}
            >
              {/* Header */}
              <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100 dark:border-gray-800">
                <div className="flex items-center gap-2">
                  <Bell className="size-4 text-gray-900 dark:text-gray-100" />
                  <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100">Notifications</h3>
                  {unreadCount > 0 && (
                    <span className="inline-flex items-center justify-center min-w-[18px] h-5 px-1.5 rounded-full bg-red-500/10 text-red-600 dark:text-red-400 text-xs font-medium">
                      {unreadCount}
                    </span>
                  )}
                </div>
                {unreadCount > 0 && (
                  <button
                    onClick={markAllAsRead}
                    disabled={markingAll}
                    className={cn(
                      'flex items-center gap-1 text-xs font-medium transition-colors rounded-md px-2 py-1',
                      'text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100',
                      'hover:bg-gray-100 dark:hover:bg-gray-800',
                      markingAll && 'opacity-50 cursor-not-allowed'
                    )}
                  >
                    <CheckCheck className="size-3.5" />
                    Mark all read
                  </button>
                )}
              </div>

              {/* Notification list */}
              <div className="flex-1 overflow-y-auto max-h-[340px]">
                {loading ? (
                  <div className="flex items-center justify-center py-12">
                    <div className="size-5 border-2 border-gray-300 dark:border-gray-600 border-t-gray-900 dark:border-t-gray-100 rounded-full animate-spin" />
                  </div>
                ) : notifications.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-gray-400 dark:text-gray-500">
                    <Bell className="size-8 mb-2 opacity-40" />
                    <p className="text-sm">No notifications</p>
                  </div>
                ) : (
                  <div className="divide-y divide-gray-50 dark:divide-gray-800/50">
                    {notifications.map((notification) => (
                      <motion.div
                        key={notification.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        onClick={() => handleNotificationClick(notification)}
                        className={cn(
                          'w-full flex items-start gap-3 px-4 py-3 text-left transition-colors',
                          'hover:bg-gray-50 dark:hover:bg-gray-800/50',
                          !notification.isRead && 'bg-blue-50/50 dark:bg-blue-950/20'
                        )}
                      >
                        {/* Unread dot */}
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <div className="relative shrink-0">
                            <Avatar className="size-8">
                              <AvatarImage
                                src={notification.fromUser.avatar}
                                alt={notification.fromUser.username}
                              />
                              <AvatarFallback className="text-xs bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-gray-100">
                                {notification.fromUser.username.charAt(0)}
                              </AvatarFallback>
                            </Avatar>
                            <div className="absolute -bottom-0.5 -right-0.5 bg-white dark:bg-gray-900 rounded-full p-0.5">
                              {getNotificationIcon(notification.type)}
                            </div>
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-gray-900 dark:text-gray-100 leading-snug">
                              <span className="font-medium">
                                {notification.fromUser.username}
                              </span>
                              <span className="text-gray-600 dark:text-gray-400">
                                {notification.content}
                              </span>
                            </p>
                            <p className="text-xs text-gray-400 dark:text-gray-500 mt-0.5">
                              {formatTimeAgo(notification.createdAt)}
                            </p>
                          </div>
                          {!notification.isRead && (
                            <div className="mt-1.5 shrink-0">
                              <div className="size-2 rounded-full bg-blue-500 dark:bg-blue-400" />
                            </div>
                          )}
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}
