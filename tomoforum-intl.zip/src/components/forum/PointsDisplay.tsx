'use client'

import { Sparkles, Info } from 'lucide-react'
import { POINTS_WEIGHTS } from '@/lib/levels'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'

interface PointsDisplayProps {
  points: number
  postCount?: number
  likeReceived?: number
  commentReceived?: number
  bookmarkReceived?: number
  showBreakdown?: boolean
  compact?: boolean
}

export default function PointsDisplay({
  points,
  postCount = 0,
  likeReceived = 0,
  commentReceived = 0,
  bookmarkReceived = 0,
  showBreakdown = true,
  compact = false,
}: PointsDisplayProps) {
  const postPoints = postCount * POINTS_WEIGHTS.POST
  const likePoints = likeReceived * POINTS_WEIGHTS.LIKE_RECEIVED
  const commentPoints = commentReceived * POINTS_WEIGHTS.COMMENT_RECEIVED
  const bookmarkPoints = bookmarkReceived * POINTS_WEIGHTS.BOOKMARK_RECEIVED

  const breakdown = (
    <div className="space-y-1 text-xs text-gray-500 dark:text-gray-400">
      <p className="font-medium text-gray-700 dark:text-gray-300 mb-1.5">Points Rules</p>
      <div className="flex items-center justify-between gap-4">
        <span>📝 Post x {postCount}</span>
        <span className="font-medium">+{postPoints}</span>
      </div>
      <div className="flex items-center justify-between gap-4">
        <span>❤️ Likes x {likeReceived}</span>
        <span className="font-medium">+{likePoints}</span>
      </div>
      <div className="flex items-center justify-between gap-4">
        <span>💬 Comments x {commentReceived}</span>
        <span className="font-medium">+{commentPoints}</span>
      </div>
      <div className="flex items-center justify-between gap-4">
        <span>⭐ Bookmarks x {bookmarkReceived}</span>
        <span className="font-medium">+{bookmarkPoints}</span>
      </div>
      <div className="border-t border-gray-100 dark:border-gray-700 pt-1 mt-1 flex items-center justify-between gap-4">
        <span className="font-medium text-gray-700 dark:text-gray-300">Total</span>
        <span className="font-bold text-gray-900 dark:text-gray-100">{postPoints + likePoints + commentPoints + bookmarkPoints}</span>
      </div>
    </div>
  )

  if (compact) {
    return (
      <div className="inline-flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400">
        <Sparkles className="size-3" />
        <span>{points}</span>
        <span>Points</span>
      </div>
    )
  }

  return (
    <div>
      <div className="flex items-center gap-2 mb-2">
        <div className="flex items-center gap-1">
          <Sparkles className="size-4 text-gray-400" />
          <span className="text-lg font-bold text-gray-900 dark:text-gray-100">{points}</span>
          <span className="text-xs text-gray-500 dark:text-gray-400">积分</span>
        </div>
        {showBreakdown && (
          <TooltipProvider delayDuration={200}>
            <Tooltip>
              <TooltipTrigger asChild>
                <button className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors">
                  <Info className="size-3.5" />
                </button>
              </TooltipTrigger>
              <TooltipContent side="bottom" align="start" className="p-3 max-w-[220px]">
                {breakdown}
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}
      </div>

      {showBreakdown && (
        <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-[11px] text-gray-400 dark:text-gray-500">
          <span>📝 Post +{postPoints}</span>
          <span>❤️ Likes +{likePoints}</span>
          <span>💬 Comments +{commentPoints}</span>
          <span>⭐ Bookmarks +{bookmarkPoints}</span>
        </div>
      )}
    </div>
  )
}
