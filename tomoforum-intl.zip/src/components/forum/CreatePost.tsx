'use client'

import { useEffect, useState, useRef, useCallback } from 'react'
import { useForumStore, type Tag } from '@/store/forum'
import { cn } from '@/components/forum/helpers'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import { ArrowLeft, X, Plus, Loader2, Eye, EyeOff, Hash, ImagePlus, Image as ImageIcon, Paperclip, Upload } from 'lucide-react'
import { EmojiPickerInline } from './EmojiPicker'
import { CodeBlock, InlineCode } from './CodeBlock'
import FormatToolbar from './FormatToolbar'
import MentionSelector, { useMention } from './MentionSelector'
import { motion, AnimatePresence } from 'framer-motion'
import { toast } from 'sonner'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'

export default function CreatePost() {
  const {
    currentPage,
    currentUser,
    categories,
    setCategories,
    navigate,
  } = useForumStore()

  const isEditing = currentPage.name === 'edit'
  const postId = isEditing ? currentPage.postId : ''
  const draftKey = `forum_draft_${currentUser?.id || 'anonymous'}`

  // Lazy initializers for draft restoration
  const getDraft = (): { title: string; content: string; categoryId: string; tags: string[] } | null => {
    if (isEditing) return null
    try {
      const saved = localStorage.getItem(draftKey)
      if (saved) {
        const draft = JSON.parse(saved)
        if (draft.title || draft.content) return draft
      }
    } catch { /* ignore */ }
    return null
  }
  const initialDraft = getDraft()

  const [title, setTitle] = useState(initialDraft?.title || '')
  const [content, setContent] = useState(initialDraft?.content || '')
  const [categoryId, setCategoryId] = useState(initialDraft?.categoryId || '')
  const [tags, setTags] = useState<string[]>(initialDraft?.tags || [])
  const [tagInput, setTagInput] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [loading, setLoading] = useState(true)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [showPreview, setShowPreview] = useState(false)
  const [hasDraft, setHasDraft] = useState(!!initialDraft)
  const [draftRestored, setDraftRestored] = useState(!!initialDraft)
  const [availableTags, setAvailableTags] = useState<Tag[]>([])
  const [showTagSuggestions, setShowTagSuggestions] = useState(false)
  const draftSaveTimerRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const lastSavedRef = useRef(initialDraft ? JSON.stringify(initialDraft) : '')
  // Use refs to hold mutable state for auto-save (avoids stale closure in setInterval)
  const titleRef = useRef(title)
  const contentRef = useRef(content)
  const categoryIdRef = useRef(categoryId)
  const tagsRef = useRef(tags)
  const tagInputRef = useRef<HTMLInputElement>(null)
  const tagSuggestionsRef = useRef<HTMLDivElement>(null)
  const blurTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const fileAttachInputRef = useRef<HTMLInputElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const [uploading, setUploading] = useState(false)
  const [isDragging, setIsDragging] = useState(false)

  // @mention for post content
  const contentMention = useMention(textareaRef, (friend) => {
    const textarea = textareaRef.current
    if (!textarea) return
    // Read from DOM to avoid stale closure
    const value = textarea.value
    const cursorPos = textarea.selectionStart
    let searchStart = cursorPos - 1
    while (searchStart >= 0 && value[searchStart] !== ' ' && value[searchStart] !== '\n') searchStart--
    const before = value.substring(0, searchStart + 1)
    const after = value.substring(cursorPos)
    setContent(`${before}@${friend.username} ${after}`)
  })

  // Auto-save draft every 3 seconds (using refs to avoid stale closure)
  useEffect(() => {
    if (isEditing) return
    draftSaveTimerRef.current = setInterval(() => {
      const draftData = JSON.stringify({ title: titleRef.current, content: contentRef.current, categoryId: categoryIdRef.current, tags: tagsRef.current })
      if (draftData !== lastSavedRef.current && (titleRef.current.trim() || contentRef.current.trim())) {
        try {
          localStorage.setItem(draftKey, JSON.stringify({ title: titleRef.current, content: contentRef.current, categoryId: categoryIdRef.current, tags: tagsRef.current }))
          lastSavedRef.current = draftData
          toast.success('Draft auto-saved', { duration: 1500, description: '' })
        } catch { /* ignore */ }
      }
    }, 3000)
    return () => {
      if (draftSaveTimerRef.current) clearInterval(draftSaveTimerRef.current)
    }
  }, [draftKey, isEditing])

  // Keep refs in sync with state
  useEffect(() => { titleRef.current = title }, [title])
  useEffect(() => { contentRef.current = content }, [content])
  useEffect(() => { categoryIdRef.current = categoryId }, [categoryId])
  useEffect(() => { tagsRef.current = tags }, [tags])

  const clearDraft = useCallback(() => {
    try {
      localStorage.removeItem(draftKey)
      setHasDraft(false)
      setDraftRestored(false)
      lastSavedRef.current = ''
      toast.success('Draft cleared', { duration: 1500 })
    } catch { /* ignore */ }
  }, [draftKey, setHasDraft, setDraftRestored])

  // Upload file and insert markdown
  const uploadFile = useCallback(async (file: File, preferImage = false) => {
    const isImage = file.type.startsWith('image/')
    if (!isImage && !preferImage) {
      // Non-image: max 20MB
      if (file.size > 20 * 1024 * 1024) {
        toast.error('File size cannot exceed 20MB')
        return
      }
    } else {
      // Image: max 5MB
      if (file.size > 5 * 1024 * 1024) {
        toast.error('Image size cannot exceed 5MB')
        return
      }
    }
    setUploading(true)
    try {
      const formData = new FormData()
      formData.append('file', file)
      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      })
      if (res.ok) {
        const data = await res.json()
        let markdown: string
        if (data.mediaType === 'image') {
          markdown = `![${data.filename}](${data.url})\n`
          toast.success('Image inserted')
        } else if (data.mediaType === 'audio') {
          markdown = `[🎵 ${data.filename}](${data.url})\n`
          toast.success('Audio inserted')
        } else if (data.mediaType === 'video') {
          markdown = `[🎬 ${data.filename}](${data.url})\n`
          toast.success('Video inserted')
        } else {
          markdown = `[📎 ${data.filename}](${data.url})\n`
          toast.success('File inserted')
        }
        setContent(prev => prev + markdown)
      } else {
        const err = await res.json()
        toast.error(err.error || 'File upload failed')
      }
    } catch {
      toast.error('File upload failed')
    }
    setUploading(false)
  }, [setContent])

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return
    Array.from(files).forEach(file => uploadFile(file, true))
    if (fileInputRef.current) fileInputRef.current.value = ''
  }, [uploadFile])

  const handleAttachSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return
    Array.from(files).forEach(file => uploadFile(file, false))
    if (fileAttachInputRef.current) fileAttachInputRef.current.value = ''
  }, [uploadFile])

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(false)
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(false)
    const files = Array.from(e.dataTransfer.files)
    if (files.length === 0) return
    files.forEach(file => uploadFile(file))
  }, [uploadFile])

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      try {
        const res = await fetch('/api/categories')
        if (!cancelled && res.ok) {
          const data = await res.json()
          setCategories(data)
        }
      } catch { /* ignore */ }
      if (!cancelled) setLoading(false)
    })()
    return () => { cancelled = true }
  }, [setCategories])

  // Fetch available tags for suggestions
  useEffect(() => {
    let cancelled = false
    ;(async () => {
      try {
        const res = await fetch('/api/posts?limit=50&sort=latest')
        if (!cancelled && res.ok) {
          const data = await res.json()
          const tagMap = new Map<string, Tag>()
          data.posts?.forEach((post: { tags?: Tag[] }) => {
            post.tags?.forEach((tag) => {
              if (!tagMap.has(tag.id)) {
                tagMap.set(tag.id, tag)
              }
            })
          })
          setAvailableTags(Array.from(tagMap.values()))
        }
      } catch { /* ignore */ }
    })()
    return () => { cancelled = true }
  }, [])

  useEffect(() => {
    if (!isEditing || !postId) return
    let cancelled = false
    ;(async () => {
      try {
        const res = await fetch(`/api/posts/${postId}`)
        if (!cancelled && res.ok) {
          const data = await res.json()
          setTitle(data.title || '')
          setContent(data.content || '')
          setCategoryId(data.categoryId || '')
          setTags(data.tags?.map((t: { name: string }) => t.name) || [])
        }
      } catch { /* ignore */ }
    })()
    return () => { cancelled = true }
  }, [isEditing, postId])

  const addTag = (tagName: string) => {
    const trimmed = tagName.trim()
    if (trimmed && !tags.includes(trimmed) && tags.length < 5) {
      setTags([...tags, trimmed])
    }
    setTagInput('')
    setShowTagSuggestions(false)
    tagInputRef.current?.focus()
  }

  const handleAddTag = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && tagInput.trim()) {
      e.preventDefault()
      addTag(tagInput)
    }
    if (e.key === 'Escape') {
      setShowTagSuggestions(false)
      tagInputRef.current?.blur()
    }
  }

  const handleRemoveTag = (tag: string) => {
    setTags(tags.filter((t) => t !== tag))
  }

  const handleTagInputFocus = () => {
    if (blurTimerRef.current) {
      clearTimeout(blurTimerRef.current)
      blurTimerRef.current = null
    }
    setShowTagSuggestions(true)
  }

  const handleTagInputBlur = () => {
    blurTimerRef.current = setTimeout(() => {
      setShowTagSuggestions(false)
    }, 200)
  }

  const filteredSuggestions = availableTags
    .filter((tag) => !tags.includes(tag.name))
    .filter((tag) => {
      if (!tagInput.trim()) return true
      return tag.name.toLowerCase().includes(tagInput.trim().toLowerCase())
    })
    .slice(0, 8)

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {}
    if (!title.trim()) newErrors.title = 'Please enter a title'
    if (!categoryId) newErrors.category = 'Please select a category'
    if (!content.trim()) newErrors.content = 'Please enter content'
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async () => {
    if (!currentUser) return
    if (!validate()) return

    setSubmitting(true)
    try {
      const body = {
        title: title.trim(),
        content: content.trim(),
        categoryId,
        authorId: currentUser.id,
        tags,
      }

      let res: Response
      if (isEditing) {
        res = await fetch(`/api/posts/${postId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body),
        })
      } else {
        res = await fetch('/api/posts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body),
        })
      }

      if (res.ok) {
        const data = await res.json()
        // Clear draft on successful submit
        if (!isEditing) {
          try { localStorage.removeItem(draftKey) } catch { /* ignore */ }
          setHasDraft(false)
          lastSavedRef.current = ''
        }
        toast.success(isEditing ? 'Post updated' : 'Post published successfully!')
        navigate({ name: 'post', postId: data.id || postId })
      }
    } catch { /* ignore */ }
    setSubmitting(false)
  }

  if (!currentUser) {
    return (
      <div className="flex-1 max-w-3xl mx-auto w-full px-4 py-16 text-center">
        <p className="text-gray-400">Please log in to create a post</p>
      </div>
    )
  }

  return (
    <motion.div
      initial={{ opacity: 0, x: 10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.3 }}
      className="flex-1 max-w-3xl mx-auto w-full px-4 py-6"
    >
      {/* Back button */}
      <button
        onClick={() => navigate({ name: 'home' })}
        className="flex items-center gap-1.5 text-sm text-gray-400 hover:text-gray-700 dark:text-gray-500 dark:hover:text-gray-300 transition-colors mb-5"
      >
        <ArrowLeft className="size-4" />
        Back
      </button>

      <h1 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-6">
        {isEditing ? 'Edit Post' : 'New Post'}
      </h1>

      <div className="space-y-5">
        {/* Title */}
        <div>
          <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">
            Title <span className="text-red-400">*</span>
          </label>
          <Input
            placeholder="Enter post title"
            value={title}
            onChange={(e) => {
              setTitle(e.target.value)
              if (errors.title) setErrors({ ...errors, title: '' })
            }}
            maxLength={100}
            className={cn(
              'text-base',
              errors.title && 'border-red-300 focus-visible:border-red-400'
            )}
          />
          <div className="flex justify-between mt-1">
            {errors.title && <p className="text-xs text-red-500">{errors.title}</p>}
            <p className="text-xs text-gray-400 ml-auto">{title.length}/100</p>
          </div>
        </div>

        {/* Category */}
        <div>
          <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">
            Category <span className="text-red-400">*</span>
          </label>
          {loading ? (
            <Skeleton className="h-9 w-full" />
          ) : (
            <Select
              value={categoryId}
              onValueChange={(val) => {
                setCategoryId(val)
                if (errors.category) setErrors({ ...errors, category: '' })
              }}
            >
              <SelectTrigger className={cn(
                'w-full',
                errors.category && 'border-red-300'
              )}>
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat.id} value={cat.id}>
                    {cat.icon} {cat.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          {errors.category && (
            <p className="text-xs text-red-500 mt-1">{errors.category}</p>
          )}
        </div>

        {/* Tags */}
        <div>
          <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">
            Tags
            <span className="text-xs font-normal text-gray-400 ml-2">
              Up to 5, press Enter to add
            </span>
          </label>
          <div className="flex flex-wrap gap-1.5 mb-2">
            <AnimatePresence>
              {tags.map((tag) => (
                <motion.div
                  key={tag}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                >
                  <Badge
                    variant="secondary"
                    className="px-2 py-1 bg-gray-100 text-gray-600 border-0 gap-1 dark:bg-gray-800 dark:text-gray-300"
                  >
                    {tag}
                    <button
                      onClick={() => handleRemoveTag(tag)}
                      className="hover:text-red-500 transition-colors"
                    >
                      <X className="size-3" />
                    </button>
                  </Badge>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
          {tags.length < 5 && (
            <div className="relative">
              <div className="flex items-center gap-2">
                <Hash className="size-4 text-gray-400 dark:text-gray-500 shrink-0" />
                <Input
                  ref={tagInputRef}
                  placeholder="Enter a tag and press Enter"
                  value={tagInput}
                  onChange={(e) => {
                    setTagInput(e.target.value)
                    if (!showTagSuggestions) setShowTagSuggestions(true)
                  }}
                  onKeyDown={handleAddTag}
                  onFocus={handleTagInputFocus}
                  onBlur={handleTagInputBlur}
                  className="text-sm"
                />
              </div>

              {/* Tag suggestions dropdown */}
              {showTagSuggestions && filteredSuggestions.length > 0 && (
                <div
                  ref={tagSuggestionsRef}
                  className="absolute left-0 right-0 top-full mt-1 z-50 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-lg shadow-lg max-h-64 overflow-y-auto"
                >
                  <div className="px-3 py-2 border-b border-gray-100 dark:border-gray-800">
                    <span className="text-[11px] font-medium text-gray-400 dark:text-gray-500 uppercase tracking-wider">
                      {tagInput.trim() ? 'Matching tags' : 'Suggested tags'}
                    </span>
                  </div>
                  {filteredSuggestions.map((suggestion) => (
                    <button
                      key={suggestion.id}
                      type="button"
                      onMouseDown={(e) => e.preventDefault()}
                      onClick={() => addTag(suggestion.name)}
                      className="w-full text-left px-3 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors flex items-center gap-2 last:rounded-b-lg"
                    >
                      <Hash className="size-3.5 text-gray-400 dark:text-gray-500" />
                      <span>{suggestion.name}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Draft restored indicator */}
        {draftRestored && !isEditing && (
          <div className="flex items-center justify-between bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg px-4 py-2.5">
            <span className="text-xs text-yellow-700 dark:text-yellow-400">📦 Unsaved draft restored</span>
            <button
              onClick={clearDraft}
              className="text-xs text-yellow-600 dark:text-yellow-500 hover:text-yellow-800 dark:hover:text-yellow-300 transition-colors"
            >
              Clear draft
            </button>
          </div>
        )}

        {/* Content */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
              Content <span className="text-red-400">*</span>
            </label>
            <div className="flex items-center gap-1.5">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                multiple
                onChange={handleFileSelect}
                className="hidden"
              />
              <input
                ref={fileAttachInputRef}
                type="file"
                multiple
                onChange={handleAttachSelect}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
                className={cn(
                  'text-xs px-2.5 py-1 rounded-md border transition-colors flex items-center gap-1',
                  'text-gray-500 border-gray-200 dark:text-gray-400 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800',
                  uploading && 'opacity-50 cursor-not-allowed'
                )}
                title="Upload image (drag & drop supported)"
              >
                {uploading ? (
                  <Loader2 className="size-3 animate-spin" />
                ) : (
                  <ImagePlus className="size-3" />
                )}
                Image
              </button>
              <button
                type="button"
                onClick={() => fileAttachInputRef.current?.click()}
                disabled={uploading}
                className={cn(
                  'text-xs px-2.5 py-1 rounded-md border transition-colors flex items-center gap-1',
                  'text-gray-500 border-gray-200 dark:text-gray-400 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800',
                  uploading && 'opacity-50 cursor-not-allowed'
                )}
                title="Upload any file (image/audio/video/document etc.)"
              >
                {uploading ? (
                  <Loader2 className="size-3 animate-spin" />
                ) : (
                  <Paperclip className="size-3" />
                )}
                Attachment
              </button>
              <button
                type="button"
                onClick={() => setShowPreview(!showPreview)}
                className={cn(
                  'text-xs px-2.5 py-1 rounded-md border transition-colors flex items-center gap-1',
                  showPreview
                    ? 'bg-gray-900 text-white border-gray-900'
                    : 'text-gray-500 border-gray-200 dark:text-gray-400 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800'
                )}
              >
                {showPreview ? <EyeOff className="size-3" /> : <Eye className="size-3" />}
                {showPreview ? 'Edit' : 'Preview'}
              </button>
            </div>
          </div>
          <div
            className="relative"
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            <FormatToolbar
              textareaRef={textareaRef}
              content={content}
              onChange={setContent}
            />
            {isDragging && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 z-10 flex items-center justify-center bg-gray-50/90 dark:bg-gray-800/90 border-2 border-dashed border-gray-400 dark:border-gray-500 rounded-lg backdrop-blur-sm"
              >
                <div className="flex flex-col items-center gap-2 text-gray-500 dark:text-gray-400">
                  <Upload className="size-8" />
                  <span className="text-sm font-medium">Drop to insert file</span>
                  <span className="text-xs text-gray-400">Supports images, audio, video, and any file</span>
                </div>
              </motion.div>
            )}
            <Textarea
              ref={textareaRef}
              placeholder="Write your thoughts... (drag & drop files, type @ to mention friends)"
              value={content}
              onChange={(e) => {
                setContent(e.target.value)
                contentMention.handleChange(e)
                if (errors.content) setErrors({ ...errors, content: '' })
              }}
              className={cn(
                'min-h-48 resize-y text-sm leading-relaxed rounded-t-none',
                errors.content && 'border-red-300 focus-visible:border-red-400'
              )}
            />
            {contentMention.selectorProps && (
              <MentionSelector {...contentMention.selectorProps} />
            )}
          </div>

          {/* Divider line between textarea and preview */}
          <AnimatePresence>
            {showPreview && content.trim() && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="my-3 border-t border-gray-200 dark:border-gray-700"
              />
            )}
          </AnimatePresence>

          {/* Markdown preview */}
          <AnimatePresence>
            {showPreview && content.trim() && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden"
              >
                <div className="prose prose-gray dark:prose-invert prose-sm max-w-none prose-headings:text-gray-900 dark:prose-headings:text-gray-100 prose-p:text-gray-700 dark:prose-p:text-gray-300 prose-strong:text-gray-900 dark:prose-strong:text-gray-100 prose-a:text-gray-600 dark:prose-a:text-gray-400 prose-blockquote:border-gray-200 dark:prose-blockquote:border-gray-700 prose-li:text-gray-700 dark:prose-li:text-gray-300 bg-gray-50 dark:bg-gray-800/50 rounded-lg p-4 border border-gray-100 dark:border-gray-800">
                  <ReactMarkdown
                    remarkPlugins={[remarkGfm]}
                    components={{
                      pre: ({ children }) => <>{children}</>,
                      code: ({ className, children, ...props }) => {
                        const match = /language-(\w+)/.exec(className || '')
                        const isBlock = match || (typeof children === 'string' && children.includes('\n'))
                        if (isBlock) {
                          return <CodeBlock language={match?.[1]}>{String(children).replace(/\n$/, '')}</CodeBlock>
                        }
                        return <InlineCode>{String(children)}</InlineCode>
                      },
                    }}
                  >
                    {content}
                  </ReactMarkdown>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="flex items-center justify-between mt-1">
            <EmojiPickerInline
              onSelect={(emoji) => setContent(prev => prev + emoji)}
            />
            {errors.content && <p className="text-xs text-red-500">{errors.content}</p>}
            <p className="text-xs text-gray-400 ml-auto">{content.length} chars</p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <Button
            variant="outline"
            onClick={() => navigate({ name: 'home' })}
            className="border-gray-200 dark:border-gray-700"
          >
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={submitting || !title.trim() || !categoryId || !content.trim()}
            className="bg-gray-900 hover:bg-gray-800 text-white min-w-24"
          >
            {submitting ? (
              <span className="flex items-center gap-1.5">
                <Loader2 className="size-4 animate-spin" />
                Publishing...
              </span>
            ) : (
              isEditing ? 'Save changes' : 'Publish post'
            )}
          </Button>
        </div>
      </div>
    </motion.div>
  )
}
