'use client'

import { useCallback, type RefObject } from 'react'
import { Bold, Italic, Heading1, Heading2, Heading3, List, ListOrdered, Quote, Code, Link, Image as ImageIcon, Minus } from 'lucide-react'
import { cn } from '@/components/forum/helpers'

interface ToolbarAction {
  icon: React.ReactNode
  label: string
  prefix: string
  suffix: string
  block?: boolean
}

const TOOLBAR_ACTIONS: ToolbarAction[] = [
  { icon: <Bold className="size-3.5" />, label: 'Bold', prefix: '**', suffix: '**' },
  { icon: <Italic className="size-3.5" />, label: 'Italic', prefix: '*', suffix: '*' },
  { icon: <Heading1 className="size-3.5" />, label: 'Heading 1', prefix: '# ', suffix: '', block: true },
  { icon: <Heading2 className="size-3.5" />, label: 'Heading 2', prefix: '## ', suffix: '', block: true },
  { icon: <Heading3 className="size-3.5" />, label: 'Heading 3', prefix: '### ', suffix: '', block: true },
  { icon: <List className="size-3.5" />, label: 'Bullet List', prefix: '- ', suffix: '', block: true },
  { icon: <ListOrdered className="size-3.5" />, label: 'Numbered List', prefix: '1. ', suffix: '', block: true },
  { icon: <Quote className="size-3.5" />, label: 'Quote', prefix: '> ', suffix: '', block: true },
  { icon: <Code className="size-3.5" />, label: 'Inline Code', prefix: '`', suffix: '`' },
  { icon: <Link className="size-3.5" />, label: 'Link', prefix: '[', suffix: '](url)' },
  { icon: <ImageIcon className="size-3.5" />, label: 'Image', prefix: '![alt](', suffix: ')' },
  { icon: <Minus className="size-3.5" />, label: 'Divider', prefix: '\n---\n', suffix: '', block: true },
]

interface FormatToolbarProps {
  textareaRef: RefObject<HTMLTextAreaElement | null>
  content: string
  onChange: (value: string) => void
}

export default function FormatToolbar({ textareaRef, content, onChange }: FormatToolbarProps) {
  const applyFormat = useCallback((action: ToolbarAction) => {
    const textarea = textareaRef.current
    if (!textarea) return

    const start = textarea.selectionStart
    const end = textarea.selectionEnd
    const selectedText = content.substring(start, end)
    const hasSelection = start !== end

    let newText: string
    let cursorPos: number

    if (action.block && !hasSelection) {
      // Block format: insert on its own line
      const beforeNewline = start > 0 && content[start - 1] !== '\n' ? '\n' : ''
      const insertion = beforeNewline + action.prefix + action.suffix
      newText = content.substring(0, start) + insertion + content.substring(end)
      cursorPos = start + beforeNewline.length + action.prefix.length
    } else if (hasSelection) {
      // Wrap selected text
      newText = content.substring(0, start) + action.prefix + selectedText + action.suffix + content.substring(end)
      cursorPos = start + action.prefix.length + selectedText.length + action.suffix.length
    } else {
      // No selection: insert placeholder
      newText = content.substring(0, start) + action.prefix + 'text' + action.suffix + content.substring(end)
      cursorPos = start + action.prefix.length
    }

    onChange(newText)

    // Restore cursor position after React re-renders
    requestAnimationFrame(() => {
      textarea.focus()
      if (hasSelection) {
        // Select the text between prefix and suffix
        textarea.setSelectionRange(
          start + action.prefix.length,
          start + action.prefix.length + selectedText.length
        )
      } else {
        textarea.setSelectionRange(cursorPos, cursorPos)
      }
    })
  }, [textareaRef, content, onChange])

  return (
    <div className="flex items-center gap-0.5 p-1 bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-700 border-b-0 rounded-t-lg overflow-x-auto no-scrollbar">
      {TOOLBAR_ACTIONS.map((action, i) => (
        <button
          key={i}
          type="button"
          onClick={() => applyFormat(action)}
          onMouseDown={(e) => e.preventDefault()} // Prevent textarea blur
          title={action.label}
          className="p-1.5 rounded-md text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700 hover:text-gray-900 dark:hover:text-gray-100 transition-colors shrink-0"
        >
          {action.icon}
        </button>
      ))}
      <div className="w-px h-5 bg-gray-200 dark:bg-gray-700 mx-1 shrink-0" />
      {/* Code block */}
      <button
        type="button"
        onClick={() => applyFormat({ icon: <Code className="size-3.5" />, label: 'Code Block', prefix: '```\n', suffix: '\n```', block: true })}
        onMouseDown={(e) => e.preventDefault()}
        title="Code Block"
        className="p-1.5 rounded-md text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700 hover:text-gray-900 dark:hover:text-gray-100 transition-colors shrink-0"
      >
        <span className="text-[10px] font-bold">{'</>'}</span>
      </button>
    </div>
  )
}
