// Level system for 明天后 Forum
// Levels: 冒泡(0) → 小白(1) → 老友(2) → 专家(3) → VIP(4) → SVIP(5)
// Special: 官方(official role) - e.g. "明天过后"

export interface LevelInfo {
  level: number
  name: string
  icon: string
  minPoints: number
  maxPoints: number
  color: string // text color class
  bgColor: string // bg color class
}

export const LEVELS: LevelInfo[] = [
  { level: 0, name: '冒泡', icon: '🫧', minPoints: 0, maxPoints: 49, color: 'text-gray-500', bgColor: 'bg-gray-100 dark:bg-gray-800' },
  { level: 1, name: '小白', icon: '🌱', minPoints: 50, maxPoints: 199, color: 'text-green-600 dark:text-green-400', bgColor: 'bg-green-50 dark:bg-green-900/30' },
  { level: 2, name: '老友', icon: '🤝', minPoints: 200, maxPoints: 499, color: 'text-blue-600 dark:text-blue-400', bgColor: 'bg-blue-50 dark:bg-blue-900/30' },
  { level: 3, name: '专家', icon: '⭐', minPoints: 500, maxPoints: 999, color: 'text-purple-600 dark:text-purple-400', bgColor: 'bg-purple-50 dark:bg-purple-900/30' },
  { level: 4, name: 'VIP', icon: '💎', minPoints: 1000, maxPoints: 2499, color: 'text-amber-600 dark:text-amber-400', bgColor: 'bg-amber-50 dark:bg-amber-900/30' },
  { level: 5, name: 'SVIP', icon: '👑', minPoints: 2500, maxPoints: Infinity, color: 'text-rose-600 dark:text-rose-400', bgColor: 'bg-rose-50 dark:bg-rose-900/30' },
]

export const OFFICIAL_LEVEL: LevelInfo = {
  level: 99,
  name: '官方',
  icon: '🏛️',
  minPoints: 0,
  maxPoints: Infinity,
  color: 'text-rose-600 dark:text-rose-400',
  bgColor: 'bg-gradient-to-r from-amber-50 to-rose-50 dark:from-amber-900/20 dark:to-rose-900/20',
}

// Points calculation weights
export const POINTS_WEIGHTS = {
  POST: 10,        // points per post created
  LIKE_RECEIVED: 2, // points per like received on posts
  COMMENT_RECEIVED: 3, // points per comment received on posts
  BOOKMARK_RECEIVED: 5, // points per bookmark received on posts
} as const

/**
 * Calculate points from user activity counts
 */
export function calculatePoints(stats: {
  postCount: number
  likeReceived: number
  commentReceived: number
  bookmarkReceived: number
}): number {
  return (
    stats.postCount * POINTS_WEIGHTS.POST +
    stats.likeReceived * POINTS_WEIGHTS.LIKE_RECEIVED +
    stats.commentReceived * POINTS_WEIGHTS.COMMENT_RECEIVED +
    stats.bookmarkReceived * POINTS_WEIGHTS.BOOKMARK_RECEIVED
  )
}

/**
 * Get level info from points
 */
export function getLevelFromPoints(points: number): LevelInfo {
  for (let i = LEVELS.length - 1; i >= 0; i--) {
    if (points >= LEVELS[i].minPoints) {
      return LEVELS[i]
    }
  }
  return LEVELS[0]
}

/**
 * Get level info for a user (handles official role)
 */
export function getUserLevel(role: string, points: number): LevelInfo {
  if (role === 'official') {
    return OFFICIAL_LEVEL
  }
  return getLevelFromPoints(points)
}

/**
 * Get progress to next level (0-100)
 */
export function getLevelProgress(points: number): number {
  const currentLevel = getLevelFromPoints(points)
  const nextLevelIdx = LEVELS.findIndex((l) => l.level === currentLevel.level) + 1
  if (nextLevelIdx >= LEVELS.length) return 100 // Max level

  const nextLevel = LEVELS[nextLevelIdx]
  const range = nextLevel.minPoints - currentLevel.minPoints
  const progress = points - currentLevel.minPoints
  return Math.min(100, Math.round((progress / range) * 100))
}

/**
 * Check if user can view/filter by a certain level threshold
 */
export function meetsLevelRequirement(userLevel: number, requiredLevel: number): boolean {
  return userLevel >= requiredLevel
}

// Preset avatar list for registration selection
export const PRESET_AVATARS = [
  { id: 'av-1', name: '猫咪', url: 'https://api.dicebear.com/9.x/notionists/svg?seed=cat&backgroundColor=c0aede', emoji: '🐱' },
  { id: 'av-2', name: '狗狗', url: 'https://api.dicebear.com/9.x/notionists/svg?seed=dog&backgroundColor=ffd5dc', emoji: '🐶' },
  { id: 'av-3', name: '熊猫', url: 'https://api.dicebear.com/9.x/notionists/svg?seed=panda&backgroundColor=d1d4f9', emoji: '🐼' },
  { id: 'av-4', name: '狐狸', url: 'https://api.dicebear.com/9.x/notionists/svg?seed=fox&backgroundColor=ffdfbf', emoji: '🦊' },
  { id: 'av-5', name: '兔子', url: 'https://api.dicebear.com/9.x/notionists/svg?seed=bunny&backgroundColor=c0aede', emoji: '🐰' },
  { id: 'av-6', name: '熊', url: 'https://api.dicebear.com/9.x/notionists/svg?seed=bear&backgroundColor=b6e3f4', emoji: '🐻' },
  { id: 'av-7', name: '企鹅', url: 'https://api.dicebear.com/9.x/notionists/svg?seed=penguin&backgroundColor=ffd5dc', emoji: '🐧' },
  { id: 'av-8', name: '猫头鹰', url: 'https://api.dicebear.com/9.x/notionists/svg?seed=owl&backgroundColor=d1d4f9', emoji: '🦉' },
  { id: 'av-9', name: '机器人', url: 'https://api.dicebear.com/9.x/notionists/svg?seed=robot&backgroundColor=ffdfbf', emoji: '🤖' },
  { id: 'av-10', name: '外星人', url: 'https://api.dicebear.com/9.x/notionists/svg?seed=alien&backgroundColor=c0aede', emoji: '👽' },
  { id: 'av-11', name: '忍者', url: 'https://api.dicebear.com/9.x/notionists/svg?seed=ninja&backgroundColor=b6e3f4', emoji: '🥷' },
  { id: 'av-12', name: '冒险家', url: 'https://api.dicebear.com/9.x/notionists/svg?seed=adventurer&backgroundColor=ffd5dc', emoji: '🧭' },
]

/**
 * Generate avatar URL using UI Avatars API
 * Uses last 2 characters of username + a custom color
 */
export function generateAvatarUrl(username: string, color?: string): string {
  const bgColor = color || generateRandomColor()
  return `https://ui-avatars.com/api/?name=${encodeURIComponent(username.slice(-2))}&background=${encodeURIComponent(bgColor)}&color=fff&size=128&bold=true&font-size=0.4`
}

/**
 * Generate a random pleasant hex color for avatar background
 */
export function generateRandomColor(): string {
  const hue = Math.floor(Math.random() * 360)
  const saturation = 55 + Math.floor(Math.random() * 25) // 55-80%
  const lightness = 40 + Math.floor(Math.random() * 15)   // 40-55%
  return hslToHex(hue, saturation, lightness)
}

function hslToHex(h: number, s: number, l: number): string {
  s /= 100
  l /= 100
  const a = s * Math.min(l, 1 - l)
  const f = (n: number) => {
    const k = (n + h / 30) % 12
    const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1)
    return Math.round(255 * color).toString(16).padStart(2, '0')
  }
  return `#${f(0)}${f(8)}${f(4)}`
}
