import { supabase } from '@/lib/supabase'
import { getLevelFromPoints } from '@/lib/levels'

/**
 * Recalculate user points from actual activity counts and update the User record.
 */
export async function recalculateUserPoints(userId: string): Promise<{ points: number; level: number }> {
  // Count posts by this user
  const { count: postCount } = await supabase
    .from('Post')
    .select('*', { count: 'exact', head: true })
    .eq('authorId', userId)

  // Get post IDs for this user
  const { data: userPosts } = await supabase
    .from('Post')
    .select('id')
    .eq('authorId', userId)

  const postIds = (userPosts || []).map((p) => p.id)

  let likeCount = 0
  let commentCount = 0
  let bookmarkCount = 0

  if (postIds.length > 0) {
    // Count likes received on user's posts
    const { count: lc } = await supabase
      .from('PostLike')
      .select('*', { count: 'exact', head: true })
      .in('postId', postIds)
    likeCount = lc || 0

    // Count comments on user's posts (from Comment table, not the user's own comments)
    const { count: cc } = await supabase
      .from('Comment')
      .select('*', { count: 'exact', head: true })
      .in('postId', postIds)
    commentCount = cc || 0

    // Count bookmarks on user's posts
    const { count: bc } = await supabase
      .from('PostBookmark')
      .select('*', { count: 'exact', head: true })
      .in('postId', postIds)
    bookmarkCount = bc || 0
  }

  const totalPosts = postCount || 0
  const newPoints = totalPosts * 10 + likeCount * 2 + commentCount * 3 + bookmarkCount * 5
  const { level } = getLevelFromPoints(newPoints)

  await supabase
    .from('User')
    .update({ points: newPoints, level })
    .eq('id', userId)

  return { points: newPoints, level }
}
