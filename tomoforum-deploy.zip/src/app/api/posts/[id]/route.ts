import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'
import { normalizeUser } from '@/lib/normalizeUser'

// Helper: enrich a single post with author, category, comments, tags, counts
async function enrichSinglePost(post: any) {
  if (!post) return null

  // Fetch author
  const { data: author } = await supabase
    .from('User')
    .select('id, username, avatar, bio, level, points, role, displayName')
    .eq('id', post.authorId)
    .single()

  // Fetch category
  const { data: category } = await supabase
    .from('Category')
    .select('id, name, icon, description')
    .eq('id', post.categoryId)
    .single()

  // Fetch root comments with author info
  const { data: rawComments } = await supabase
    .from('Comment')
    .select('*')
    .eq('postId', post.id)
    .is('parentId', null)
    .order('createdAt', { ascending: false })

  // Fetch tags
  const { data: postTags } = await supabase
    .from('PostTag')
    .select('tagId')
    .eq('postId', post.id)

  let tags: any[] = []
  if (postTags && postTags.length > 0) {
    const tagIds = postTags.map((pt) => pt.tagId)
    const { data: tagData } = await supabase.from('Tag').select('id, name').in('id', tagIds)
    tags = tagData || []
  }

  // Fetch like/bookmark counts
  const [likesRes, bookmarksRes] = await Promise.all([
    supabase.from('PostLike').select('id', { count: 'exact', head: true }).eq('postId', post.id),
    supabase.from('PostBookmark').select('id', { count: 'exact', head: true }).eq('postId', post.id),
  ])

  // Process comments: fetch replies and authors
  let comments: any[] = []
  if (rawComments && rawComments.length > 0) {
    const commentIds = rawComments.map((c: any) => c.id)

    // Fetch replies for all root comments
    const { data: replies } = await supabase
      .from('Comment')
      .select('*')
      .in('parentId', commentIds)
      .order('createdAt', { ascending: true })

    // Collect all author IDs (comments + replies)
    const allCommentAuthorIds = [
      ...rawComments.map((c: any) => c.authorId),
      ...(replies || []).map((r: any) => r.authorId),
    ]
    const uniqueAuthorIds = [...new Set(allCommentAuthorIds)]

    // Batch fetch authors
    const { data: commentAuthors } = await supabase
      .from('User')
      .select('id, username, avatar, level, points, role, displayName')
      .in('id', uniqueAuthorIds)
    const authorMap = new Map((commentAuthors || []).map((a: any) => [a.id, normalizeUser(a)]))

    // Build comments map for replies
    const repliesByParentId = new Map<string, any[]>()
    for (const reply of (replies || [])) {
      const existing = repliesByParentId.get(reply.parentId) || []
      existing.push({
        ...reply,
        author: authorMap.get(reply.authorId) || null,
      })
      repliesByParentId.set(reply.parentId, existing)
    }

    comments = rawComments.map((c: any) => ({
      ...c,
      author: authorMap.get(c.authorId) || null,
      replies: repliesByParentId.get(c.id) || [],
    }))
  }

  return {
    ...post,
    author: author ? normalizeUser(author) : null,
    category: category || null,
    comments,
    _count: {
      likes: likesRes.count || 0,
      bookmarks: bookmarksRes.count || 0,
    },
    tags,
  }
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    const { data: post } = await supabase
      .from('Post')
      .select('*')
      .eq('id', id)
      .single()

    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      )
    }

    const enriched = await enrichSinglePost(post)

    return NextResponse.json(enriched)
  } catch (error) {
    console.error('Error fetching post:', error)
    return NextResponse.json(
      { error: 'Failed to fetch post' },
      { status: 500 }
    )
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { title, content, categoryId, isPinned, isLocked } = body

    const { data: existingPost } = await supabase
      .from('Post')
      .select('*')
      .eq('id', id)
      .single()

    if (!existingPost) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      )
    }

    const updateData: Record<string, any> = {}
    if (title !== undefined) updateData.title = title
    if (content !== undefined) updateData.content = content
    if (isPinned !== undefined) updateData.isPinned = isPinned
    if (isLocked !== undefined) updateData.isLocked = isLocked

    if (categoryId !== undefined) {
      // If changing category, update postCounts
      if (categoryId !== existingPost.categoryId) {
        const [oldCat, newCat] = await Promise.all([
          supabase.from('Category').select('postCount').eq('id', existingPost.categoryId).single(),
          supabase.from('Category').select('postCount').eq('id', categoryId).single(),
        ])
        if (oldCat.data) {
          await supabase.from('Category').update({ postCount: Math.max(0, (oldCat.data.postCount || 1) - 1) }).eq('id', existingPost.categoryId)
        }
        if (newCat.data) {
          await supabase.from('Category').update({ postCount: (newCat.data.postCount || 0) + 1 }).eq('id', categoryId)
        }
      }
      updateData.categoryId = categoryId
    }

    const { data: updatedPost } = await supabase
      .from('Post')
      .update(updateData)
      .eq('id', id)
      .select()
      .single()

    // Fetch author + category for the response
    const { data: author } = await supabase.from('User').select('id, username, avatar, role, displayName').eq('id', updatedPost.authorId).single()
    const { data: category } = await supabase.from('Category').select('id, name, icon').eq('id', updatedPost.categoryId).single()
    const { data: postTags } = await supabase.from('PostTag').select('tagId').eq('postId', updatedPost.id)

    let tags: any[] = []
    if (postTags && postTags.length > 0) {
      const tagIds = postTags.map((pt) => pt.tagId)
      const { data: tagData } = await supabase.from('Tag').select('id, name').in('id', tagIds)
      tags = tagData || []
    }

    return NextResponse.json({
      ...updatedPost,
      author: author ? normalizeUser(author) : null,
      category: category || null,
      tags,
    })
  } catch (error) {
    console.error('Error updating post:', error)
    return NextResponse.json(
      { error: 'Failed to update post' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    const { data: existingPost } = await supabase
      .from('Post')
      .select('*')
      .eq('id', id)
      .single()

    if (!existingPost) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      )
    }

    // Delete the post (cascade should handle related records)
    await supabase.from('Post').delete().eq('id', id)

    // Decrement category postCount
    const { data: cat } = await supabase
      .from('Category')
      .select('postCount')
      .eq('id', existingPost.categoryId)
      .single()
    if (cat) {
      await supabase.from('Category').update({ postCount: Math.max(0, (cat.postCount || 1) - 1) }).eq('id', existingPost.categoryId)
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting post:', error)
    return NextResponse.json(
      { error: 'Failed to delete post' },
      { status: 500 }
    )
  }
}
