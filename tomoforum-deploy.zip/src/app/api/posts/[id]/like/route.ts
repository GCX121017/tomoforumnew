import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'
import { recalculateUserPoints } from '@/lib/recalcPoints'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: postId } = await params
    const body = await request.json()
    const { userId } = body

    if (!userId) {
      return NextResponse.json(
        { error: 'userId is required' },
        { status: 400 }
      )
    }

    // Verify post exists
    const { data: post } = await supabase
      .from('Post')
      .select('*')
      .eq('id', postId)
      .single()
    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      )
    }

    // Fetch author role
    const { data: author } = await supabase
      .from('User')
      .select('id, role')
      .eq('id', post.authorId)
      .single()

    // Check if like already exists
    const { data: existingLike } = await supabase
      .from('PostLike')
      .select('id')
      .eq('postId', postId)
      .eq('userId', userId)
      .maybeSingle()

    if (existingLike) {
      // Unlike: remove and decrement
      await supabase.from('PostLike').delete().eq('id', existingLike.id)

      const { data: updatedPost } = await supabase
        .from('Post')
        .select('likeCount')
        .eq('id', postId)
        .single()
      await supabase
        .from('Post')
        .update({ likeCount: Math.max(0, (updatedPost?.likeCount || 1) - 1) })
        .eq('id', postId)

      // Recalculate points for post author (if not self-like and not official)
      if (post.authorId !== userId && author?.role !== 'official') {
        await recalculateUserPoints(post.authorId)
      }

      return NextResponse.json({ liked: false })
    } else {
      // Like: create and increment
      await supabase.from('PostLike').insert({ postId, userId })

      const { data: updatedPost } = await supabase
        .from('Post')
        .select('likeCount')
        .eq('id', postId)
        .single()
      await supabase
        .from('Post')
        .update({ likeCount: (updatedPost?.likeCount || 0) + 1 })
        .eq('id', postId)

      // Recalculate points for post author
      if (post.authorId !== userId && author?.role !== 'official') {
        await recalculateUserPoints(post.authorId)
      }

      // Create notification for the post author (if not self-like)
      if (post.authorId !== userId) {
        try {
          await supabase.from('Notification').insert({
            type: 'like',
            userId: post.authorId,
            fromUserId: userId,
            postId: post.id,
            content: `赞了你的帖子「${post.title}」`,
          })
        } catch {
          // Notification creation failure should not affect the like
        }
      }

      return NextResponse.json({ liked: true })
    }
  } catch (error) {
    console.error('Error toggling like:', error)
    return NextResponse.json(
      { error: 'Failed to toggle like' },
      { status: 500 }
    )
  }
}
