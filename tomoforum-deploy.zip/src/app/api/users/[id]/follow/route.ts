import { supabase } from '@/lib/supabase'
import { NextResponse } from 'next/server'

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: followingId } = await params
    const body = await request.json()
    const { followerId } = body

    if (!followerId || !followingId) {
      return NextResponse.json(
        { error: '缺少必要参数' },
        { status: 400 }
      )
    }

    if (followerId === followingId) {
      return NextResponse.json(
        { error: '不能关注自己' },
        { status: 400 }
      )
    }

    // Check if target user exists
    const { data: targetUser } = await supabase
      .from('User')
      .select('id')
      .eq('id', followingId)
      .single()

    if (!targetUser) {
      return NextResponse.json(
        { error: '用户不存在' },
        { status: 404 }
      )
    }

    // Check if already following
    const { data: existingFollow } = await supabase
      .from('Follow')
      .select('id')
      .eq('followerId', followerId)
      .eq('followingId', followingId)
      .maybeSingle()

    let following: boolean

    if (existingFollow) {
      // Unfollow
      await supabase
        .from('Follow')
        .delete()
        .eq('id', existingFollow.id)
      following = false
    } else {
      // Follow
      await supabase
        .from('Follow')
        .insert({ followerId, followingId })
      following = true
    }

    // Get updated counts
    const [followerCountRes, followingCountRes] = await Promise.all([
      supabase.from('Follow').select('id', { count: 'exact', head: true }).eq('followingId', followingId),
      supabase.from('Follow').select('id', { count: 'exact', head: true }).eq('followerId', followerId),
    ])

    const followerCount = followerCountRes.count || 0
    const followingCount = followingCountRes.count || 0

    return NextResponse.json({
      following,
      followerCount,
      followingCount,
    })
  } catch (error) {
    console.error('Follow error:', error)
    return NextResponse.json(
      { error: '操作失败' },
      { status: 500 }
    )
  }
}
