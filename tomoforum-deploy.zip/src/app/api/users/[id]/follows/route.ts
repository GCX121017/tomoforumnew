import { supabase } from '@/lib/supabase'
import { NextResponse } from 'next/server'
import { normalizeUsers } from '@/lib/normalizeUser'

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: userId } = await params
    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type') || 'followers'
    const viewerId = searchParams.get('viewerId') || ''
    const page = parseInt(searchParams.get('page') || '1', 10)
    const limit = parseInt(searchParams.get('limit') || '20', 10)
    const from = (page - 1) * limit

    if (type !== 'followers' && type !== 'following') {
      return NextResponse.json(
        { error: 'type 参数必须是 followers 或 following' },
        { status: 400 }
      )
    }

    // Build query - get follows
    const query = type === 'followers'
      ? supabase.from('Follow').select('*').eq('followingId', userId)
      : supabase.from('Follow').select('*').eq('followerId', userId)

    // Get total count
    const { count: total } = await supabase
      .from('Follow')
      .select('id', { count: 'exact', head: true })
      .eq(type === 'followers' ? 'followingId' : 'followerId', userId)

    // Get paginated follows
    const { data: follows } = await query
      .order('createdAt', { ascending: false })
      .range(from, from + limit - 1)

    // Collect user IDs (the "other" user in the follow relationship)
    const userIds = (follows || []).map((f: any) =>
      type === 'followers' ? f.followerId : f.followingId
    )

    // Batch fetch users
    let usersWithFollowing: any[] = []
    if (userIds.length > 0) {
      const { data: rawUsers } = await supabase
        .from('User')
        .select('id, username, displayName, avatar, bio, level, points')
        .in('id', userIds)

      usersWithFollowing = normalizeUsers(rawUsers || [])

      // If viewerId is provided, check isFollowing for each user
      if (viewerId) {
        const { data: followingEntries } = await supabase
          .from('Follow')
          .select('followingId')
          .eq('followerId', viewerId)
          .in('followingId', userIds)

        const followingIdSet = new Set((followingEntries || []).map((f: any) => f.followingId))

        usersWithFollowing = usersWithFollowing.map((u: any) => ({
          ...u,
          isFollowing: followingIdSet.has(u.id),
        }))
      }

      // Maintain the order from follows query
      const userMap = new Map(usersWithFollowing.map((u: any) => [u.id, u]))
      usersWithFollowing = userIds.map((uid: string) => userMap.get(uid)).filter(Boolean)
    }

    return NextResponse.json({
      users: usersWithFollowing,
      total: total || 0,
      page,
      limit,
      totalPages: Math.ceil((total || 0) / limit),
    })
  } catch (error) {
    console.error('Get follows error:', error)
    return NextResponse.json(
      { error: '获取失败' },
      { status: 500 }
    )
  }
}
