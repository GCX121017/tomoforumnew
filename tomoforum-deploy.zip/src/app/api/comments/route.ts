import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'
import { normalizeUser } from '@/lib/normalizeUser'
import { recalculateUserPoints } from '@/lib/recalcPoints'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const postId = searchParams.get('postId')
    const userId = searchParams.get('userId')

    if (!postId) {
      return NextResponse.json(
        { error: 'postId is required' },
        { status: 400 }
      )
    }

    // Fetch root comments
    const { data: rawComments } = await supabase
      .from('Comment')
      .select('*')
      .eq('postId', postId)
      .is('parentId', null)
      .order('createdAt', { ascending: false })

    if (!rawComments || rawComments.length === 0) {
      return NextResponse.json([])
    }

    const commentIds = rawComments.map((c: any) => c.id)

    // Fetch replies
    const { data: replies } = await supabase
      .from('Comment')
      .select('*')
      .in('parentId', commentIds)
      .order('createdAt', { ascending: true })

    // Collect all unique author IDs
    const allAuthorIds = [
      ...rawComments.map((c: any) => c.authorId),
      ...(replies || []).map((r: any) => r.authorId),
    ]
    const uniqueAuthorIds = [...new Set(allAuthorIds)]

    // Batch fetch authors
    const { data: authors } = await supabase
      .from('User')
      .select('id, username, avatar, level, points, role, displayName')
      .in('id', uniqueAuthorIds)
    const authorMap = new Map((authors || []).map((a: any) => [a.id, normalizeUser(a)]))

    // Fetch like counts for all comments and replies
    const allCommentIds = [...commentIds, ...(replies || []).map((r: any) => r.id)]
    const { data: likeEntries } = await supabase
      .from('CommentLike')
      .select('commentId, userId')
      .in('commentId', allCommentIds)

    // Build like count map
    const likeCountMap = new Map<string, number>()
    for (const le of (likeEntries || [])) {
      likeCountMap.set(le.commentId, (likeCountMap.get(le.commentId) || 0) + 1)
    }

    // Build like status maps for current user
    const commentLikedMap: Record<string, boolean> = {}
    const replyLikedMap: Record<string, boolean> = {}
    if (userId) {
      const { data: userLikes } = await supabase
        .from('CommentLike')
        .select('commentId')
        .eq('userId', userId)
        .in('commentId', allCommentIds)

      for (const ul of (userLikes || [])) {
        // Check if it's a root comment or reply
        if (commentIds.includes(ul.commentId)) {
          commentLikedMap[ul.commentId] = true
        } else {
          replyLikedMap[ul.commentId] = true
        }
      }
    }

    // Build replies by parentId map
    const repliesByParentId = new Map<string, any[]>()
    for (const reply of (replies || [])) {
      const existing = repliesByParentId.get(reply.parentId) || []
      existing.push({
        ...reply,
        author: authorMap.get(reply.authorId) || null,
        likeCount: likeCountMap.get(reply.id) || 0,
        commentLiked: !!replyLikedMap[reply.id],
      })
      repliesByParentId.set(reply.parentId, existing)
    }

    const result = rawComments.map((c: any) => ({
      ...c,
      author: authorMap.get(c.authorId) || null,
      likeCount: likeCountMap.get(c.id) || 0,
      commentLiked: !!commentLikedMap[c.id],
      replies: repliesByParentId.get(c.id) || [],
    }))

    return NextResponse.json(result)
  } catch (error) {
    console.error('Error fetching comments:', error)
    return NextResponse.json(
      { error: 'Failed to fetch comments' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { content, postId, authorId, parentId } = body

    if (!content || !postId || !authorId) {
      return NextResponse.json(
        { error: 'content, postId, and authorId are required' },
        { status: 400 }
      )
    }

    // Verify post exists
    const { data: post } = await supabase
      .from('Post')
      .select('*')
      .eq('id', postId)
      .single()
    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      )
    }

    // Verify author exists
    const { data: author } = await supabase.from('User').select('id').eq('id', authorId).single()
    if (!author) {
      return NextResponse.json(
        { error: 'Author not found' },
        { status: 404 }
      )
    }

    // If parentId is provided, verify the parent comment exists
    let parentComment: { id: string; authorId: string } | null = null
    if (parentId) {
      const { data: found } = await supabase
        .from('Comment')
        .select('id, authorId')
        .eq('id', parentId)
        .single()
      if (!found) {
        return NextResponse.json(
          { error: 'Parent comment not found' },
          { status: 404 }
        )
      }
      parentComment = found
    }

    // Create comment
    const { data: comment } = await supabase
      .from('Comment')
      .insert({
        content,
        postId,
        authorId,
        parentId: parentId || null,
      })
      .select()
      .single()

    if (!comment) {
      return NextResponse.json({ error: 'Failed to create comment' }, { status: 500 })
    }

    // Increment post commentCount
    const { data: postData } = await supabase
      .from('Post')
      .select('commentCount')
      .eq('id', postId)
      .single()
    if (postData) {
      await supabase.from('Post').update({ commentCount: (postData.commentCount || 0) + 1 }).eq('id', postId)
    }

    // Recalculate points for the post author
    if (post.authorId !== authorId) {
      const { data: postAuthor } = await supabase.from('User').select('role').eq('id', post.authorId).single()
      if (postAuthor?.role !== 'official') {
        await recalculateUserPoints(post.authorId)
      }
    }

    // Create notifications after successful comment creation
    try {
      // Notification for the post author (if not self-comment)
      if (post.authorId !== authorId) {
        await supabase.from('Notification').insert({
          type: 'comment',
          userId: post.authorId,
          fromUserId: authorId,
          postId: post.id,
          commentId: comment.id,
          content: `评论了你的帖子「${post.title}」`,
        })
      }

      // If it's a reply, notify the parent comment author (if not self-reply)
      if (parentComment && parentComment.authorId !== authorId) {
        await supabase.from('Notification').insert({
          type: 'reply',
          userId: parentComment.authorId,
          fromUserId: authorId,
          postId: post.id,
          commentId: comment.id,
          content: `回复了你在「${post.title}」下的评论`,
        })
      }
    } catch {
      // Notification creation failure should not affect the comment
    }

    // Fetch author for the response
    const { data: commentAuthor } = await supabase
      .from('User')
      .select('id, username, avatar, level, points, role, displayName')
      .eq('id', authorId)
      .single()

    return NextResponse.json({
      ...comment,
      author: commentAuthor ? normalizeUser(commentAuthor) : null,
    }, { status: 201 })
  } catch (error) {
    console.error('Error creating comment:', error)
    return NextResponse.json(
      { error: 'Failed to create comment' },
      { status: 500 }
    )
  }
}
