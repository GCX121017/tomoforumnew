import { supabase } from '@/lib/supabase'
import { NextResponse } from 'next/server'
import { hashPassword } from '@/lib/password'
import { encodeUsername, generateVirtualEmail } from '@/lib/normalizeUser'

export async function GET() {
  try {
    // Only seed if User table is empty (safe guard)
    const { count: userCount } = await supabase
      .from('User')
      .select('*', { count: 'exact', head: true })

    if ((userCount || 0) > 0) {
      return NextResponse.json({
        message: 'Database already has data, skipping seed',
        stats: { users: userCount },
      })
    }

    // 1. Create categories
    const categories = [
      { name: '技术讨论', icon: '💻', description: '编程、开发、技术分享', sortOrder: 1, postCount: 0 },
      { name: '生活日常', icon: '🌤️', description: '分享生活点滴', sortOrder: 2, postCount: 0 },
      { name: '创意灵感', icon: '✨', description: '设计、创意、灵感', sortOrder: 3, postCount: 0 },
      { name: '读书笔记', icon: '📚', description: '阅读心得与书评', sortOrder: 4, postCount: 0 },
      { name: '问题求助', icon: '🆘', description: '提出问题，寻求帮助', sortOrder: 5, postCount: 0 },
      { name: '资源分享', icon: '🎁', description: '优质资源推荐', sortOrder: 6, postCount: 0 },
    ]

    const { data: insertedCats, error: catError } = await supabase
      .from('Category')
      .insert(categories)
      .select()

    if (catError) {
      console.error('Category insert error:', catError)
      return NextResponse.json({ error: 'Failed to create categories', detail: catError.message }, { status: 500 })
    }

    const techCat = (insertedCats || []).find(c => c.name === '技术讨论')

    // 2. Create official account "明天过后"
    const adminPassword = await hashPassword('GuanChengxu_zl199518@outlook.com_admin_passkey')
    const officialDisplayName = '明天过后'
    const officialDbUsername = encodeUsername(officialDisplayName)
    const officialEmail = generateVirtualEmail(officialDbUsername)
    const { data: officialUser, error: userError } = await supabase
      .from('User')
      .insert({
        username: officialDbUsername,
        displayName: officialDisplayName,
        email: officialEmail,
        avatar: 'https://api.dicebear.com/9.x/notionists/svg?seed=official-mth',
        bio: '明天后官方账号，社区管理与运营',
        role: 'official',
        level: 99,
        points: 9999,
        password: adminPassword,
      })
      .select()
      .single()

    if (userError) {
      console.error('User insert error:', userError)
      return NextResponse.json({ error: 'Failed to create official user', detail: userError.message }, { status: 500 })
    }

    // 3. Create official pinned post: 社区公约与行为规范
    const postContent = `为了让「明天后」社区成为一个友善、有价值的技术交流平台，请所有成员遵守以下公约。

**第一，尊重他人。** 无论对方的观点是否与你一致，请保持礼貌和尊重。人身攻击、歧视性言论将不被容忍。每个人都有不同的背景和经验，多元的声音让社区更加丰富。

**第二，注重内容质量。** 发帖前请搜索是否已有相关讨论，避免重复内容。技术问题请尽量提供足够的上下文信息，包括代码片段、错误信息和使用环境。好的问题往往比好的答案更有价值。

**第三，善用标签和分类。** 选择合适的分类和标签可以帮助他人更快地找到你的帖子，也能让你的内容获得更多关注。

**第四，禁止垃圾信息和广告。** 未经许可的商业推广、重复发帖、无意义内容将被删除。持续违规者将被禁言处理。让我们一起守护这个纯净的交流空间。

---

## 积分与等级说明

社区采用积分等级体系，你的活跃度越高，等级越高：

| 等级 | 所需积分 | 徽章 |
|------|---------|------|
| 冒泡 | 0-49 | 🫧 |
| 小白 | 50-199 | 🌱 |
| 老友 | 200-499 | 🤝 |
| 专家 | 500-999 | ⭐ |
| VIP | 1000-2499 | 💎 |
| SVIP | 2500+ | 👑 |

**积分获取方式：**
- 发表帖子：+10 分/篇
- 获得点赞：+2 分/个
- 获得评论：+3 分/条
- 获得收藏：+5 分/个

---

> 以黑白之名，书写明天。欢迎加入「明天后」！`

    const { data: rulesPost, error: postError } = await supabase
      .from('Post')
      .insert({
        title: '📋 社区公约与行为规范',
        content: postContent,
        categoryId: techCat?.id,
        authorId: officialUser.id,
        isPinned: true,
        viewCount: 100,
        likeCount: 0,
        commentCount: 0,
      })
      .select()
      .single()

    if (postError) {
      console.error('Post insert error:', postError)
      return NextResponse.json({ error: 'Failed to create rules post', detail: postError.message }, { status: 500 })
    }

    // Update category post count
    if (techCat?.id) {
      await supabase.from('Category').update({ postCount: 1 }).eq('id', techCat.id)
    }

    return NextResponse.json({
      message: 'Seed completed: official account and community rules created',
      stats: {
        users: 1,
        posts: 1,
        categories: (insertedCats || []).length,
      },
    })
  } catch (error) {
    console.error('Error seeding:', error)
    return NextResponse.json(
      { error: 'Failed to seed database' },
      { status: 500 }
    )
  }
}
