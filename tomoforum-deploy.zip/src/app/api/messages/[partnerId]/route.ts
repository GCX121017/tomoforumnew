import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'
import { normalizeUser } from '@/lib/normalizeUser'

// GET /api/messages/[partnerId]?userId=xxx
// 获取与指定用户的聊天记录，并标记未读消息为已读
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ partnerId: string }> }
) {
  try {
    const { partnerId } = await params
    const { searchParams } = request.nextUrl
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: '缺少用户ID' },
        { status: 400 }
      )
    }

    if (!partnerId) {
      return NextResponse.json(
        { error: '缺少聊天对象ID' },
        { status: 400 }
      )
    }

    // 获取聊天记录（按时间正序）
    const { data: messages } = await supabase
      .from('PrivateMessage')
      .select('*')
      .or(`and(senderId.eq.${userId},receiverId.eq.${partnerId}),and(senderId.eq.${partnerId},receiverId.eq.${userId})`)
      .order('createdAt', { ascending: true })

    if (!messages || messages.length === 0) {
      return NextResponse.json([])
    }

    // Batch fetch sender profiles
    const senderIds = [...new Set(messages.map((m: any) => m.senderId))]
    const { data: senders } = await supabase
      .from('User')
      .select('id, username, displayName, avatar')
      .in('id', senderIds)
    const senderMap = new Map((senders || []).map((u: any) => [u.id, normalizeUser(u)]))

    const result = messages.map((m: any) => ({
      ...m,
      sender: senderMap.get(m.senderId) || null,
    }))

    // 标记所有未读消息为已读（对方发给当前用户的未读消息）
    await supabase
      .from('PrivateMessage')
      .update({ isRead: true })
      .eq('senderId', partnerId)
      .eq('receiverId', userId)
      .eq('isRead', false)

    return NextResponse.json(result)
  } catch (error) {
    console.error('获取聊天记录失败:', error)
    return NextResponse.json(
      { error: '获取聊天记录失败' },
      { status: 500 }
    )
  }
}

// POST /api/messages/[partnerId]
// 发送私聊消息
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ partnerId: string }> }
) {
  try {
    const { partnerId } = await params
    const body = await request.json()
    const { userId, content } = body

    // 验证参数
    if (!userId) {
      return NextResponse.json(
        { error: '缺少发送者ID' },
        { status: 400 }
      )
    }

    if (!content || typeof content !== 'string') {
      return NextResponse.json(
        { error: '消息内容不能为空' },
        { status: 400 }
      )
    }

    if (content.trim().length === 0) {
      return NextResponse.json(
        { error: '消息内容不能为空白' },
        { status: 400 }
      )
    }

    if (content.length > 2000) {
      return NextResponse.json(
        { error: '消息内容不能超过2000个字符' },
        { status: 400 }
      )
    }

    // 不能给自己发消息
    if (userId === partnerId) {
      return NextResponse.json(
        { error: '不能给自己发消息' },
        { status: 400 }
      )
    }

    // 验证好友关系
    const { data: friendship } = await supabase
      .from('FriendRequest')
      .select('id')
      .eq('status', 'accepted')
      .or(`and(fromUserId.eq.${userId},toUserId.eq.${partnerId}),and(fromUserId.eq.${partnerId},toUserId.eq.${userId})`)
      .limit(1)

    if (!friendship || friendship.length === 0) {
      return NextResponse.json(
        { error: '只能给好友发送私聊消息' },
        { status: 403 }
      )
    }

    // 验证对方用户存在
    const { data: receiver } = await supabase
      .from('User')
      .select('id')
      .eq('id', partnerId)
      .single()

    if (!receiver) {
      return NextResponse.json(
        { error: '用户不存在' },
        { status: 404 }
      )
    }

    // 创建私聊消息
    const { data: message } = await supabase
      .from('PrivateMessage')
      .insert({
        senderId: userId,
        receiverId: partnerId,
        content: content.trim(),
      })
      .select()
      .single()

    if (!message) {
      return NextResponse.json({ error: 'Failed to send message' }, { status: 500 })
    }

    // Fetch sender for the response
    const { data: sender } = await supabase
      .from('User')
      .select('id, username, displayName, avatar')
      .eq('id', userId)
      .single()

    // 创建通知
    await supabase.from('Notification').insert({
      type: 'private_message',
      userId: partnerId,
      fromUserId: userId,
      content: '给你发了一条私聊消息',
    })

    return NextResponse.json({
      ...message,
      sender: sender ? normalizeUser(sender) : null,
    })
  } catch (error) {
    console.error('发送私聊消息失败:', error)
    return NextResponse.json(
      { error: '发送私聊消息失败' },
      { status: 500 }
    )
  }
}
