import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'

// Recall marker — recalled messages have this content
const RECALLED_MARKER = '[已撤回]'

// PUT /api/messages/edit/[messageId] — 编辑消息（2分钟内）
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ messageId: string }> }
) {
  try {
    const { messageId } = await params
    const body = await request.json()
    const { userId, content } = body

    if (!userId) {
      return NextResponse.json({ error: '缺少用户ID' }, { status: 400 })
    }

    if (!content || typeof content !== 'string' || content.trim().length === 0) {
      return NextResponse.json({ error: '消息内容不能为空' }, { status: 400 })
    }

    if (content.length > 2000) {
      return NextResponse.json({ error: '消息内容不能超过2000个字符' }, { status: 400 })
    }

    // 查询消息是否存在
    const { data: existing } = await supabase
      .from('PrivateMessage')
      .select('id, senderId, content, createdAt')
      .eq('id', messageId)
      .single()

    if (!existing) {
      return NextResponse.json({ error: '消息不存在' }, { status: 404 })
    }

    // 只能编辑自己的消息
    if (existing.senderId !== userId) {
      return NextResponse.json({ error: '只能编辑自己的消息' }, { status: 403 })
    }

    // 已撤回的消息不能编辑
    if (existing.content === RECALLED_MARKER) {
      return NextResponse.json({ error: '已撤回的消息不能编辑' }, { status: 400 })
    }

    // 编辑时间限制：2分钟内可编辑
    const createdTime = new Date(existing.createdAt).getTime()
    const now = Date.now()
    const diffMinutes = (now - createdTime) / (1000 * 60)
    if (diffMinutes > 2) {
      return NextResponse.json({ error: '消息发送超过2分钟，无法编辑' }, { status: 400 })
    }

    // 更新消息
    const { data: updated } = await supabase
      .from('PrivateMessage')
      .update({ content: content.trim() })
      .eq('id', messageId)
      .select()
      .single()

    if (!updated) {
      return NextResponse.json({ error: '编辑失败' }, { status: 500 })
    }

    return NextResponse.json(updated)
  } catch (error) {
    console.error('编辑消息失败:', error)
    return NextResponse.json({ error: '编辑消息失败' }, { status: 500 })
  }
}

// DELETE /api/messages/edit/[messageId]?userId=xxx — 撤回消息（2分钟内）
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ messageId: string }> }
) {
  try {
    const { messageId } = await params
    const { searchParams } = request.nextUrl
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json({ error: '缺少用户ID' }, { status: 400 })
    }

    // 查询消息是否存在
    const { data: existing } = await supabase
      .from('PrivateMessage')
      .select('id, senderId, content, createdAt')
      .eq('id', messageId)
      .single()

    if (!existing) {
      return NextResponse.json({ error: '消息不存在' }, { status: 404 })
    }

    // 只能撤回自己的消息
    if (existing.senderId !== userId) {
      return NextResponse.json({ error: '只能撤回自己的消息' }, { status: 403 })
    }

    // 已撤回的消息不能再次撤回
    if (existing.content === RECALLED_MARKER) {
      return NextResponse.json({ error: '消息已撤回' }, { status: 400 })
    }

    // 撤回时间限制：2分钟内可撤回
    const createdTime = new Date(existing.createdAt).getTime()
    const now = Date.now()
    const diffMinutes = (now - createdTime) / (1000 * 60)
    if (diffMinutes > 2) {
      return NextResponse.json({ error: '消息发送超过2分钟，无法撤回' }, { status: 400 })
    }

    // 软撤回：将内容替换为撤回标记
    const { data: recalled } = await supabase
      .from('PrivateMessage')
      .update({ content: RECALLED_MARKER })
      .eq('id', messageId)
      .select()
      .single()

    if (!recalled) {
      return NextResponse.json({ error: '撤回失败' }, { status: 500 })
    }

    return NextResponse.json(recalled)
  } catch (error) {
    console.error('撤回消息失败:', error)
    return NextResponse.json({ error: '撤回消息失败' }, { status: 500 })
  }
}
