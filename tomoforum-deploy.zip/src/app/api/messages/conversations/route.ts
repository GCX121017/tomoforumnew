import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'
import { normalizeUser } from '@/lib/normalizeUser'

// GET /api/messages/conversations?userId=xxx
// 获取用户的所有会话列表（含最后一条消息、未读数、对方用户信息）
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: '缺少用户ID' },
        { status: 400 }
      )
    }

    // 1. 查找该用户参与的所有私聊记录，获取所有对方用户ID
    const { data: messages } = await supabase
      .from('PrivateMessage')
      .select('senderId, receiverId')
      .or(`senderId.eq.${userId},receiverId.eq.${userId}`)
      .order('createdAt', { ascending: false })

    // 2. 提取所有不重复的对方用户ID
    const partnerIds = new Set<string>()
    for (const msg of (messages || [])) {
      if (msg.senderId !== userId) partnerIds.add(msg.senderId)
      if (msg.receiverId !== userId) partnerIds.add(msg.receiverId)
    }

    if (partnerIds.size === 0) {
      return NextResponse.json([])
    }

    // 3. 对每个会话伙伴，获取用户信息、最后一条消息、未读数
    const conversations = await Promise.all(
      Array.from(partnerIds).map(async (partnerId) => {
        // 获取对方用户信息
        const { data: partner } = await supabase
          .from('User')
          .select('id, username, displayName, avatar, level')
          .eq('id', partnerId)
          .single()

        if (!partner) return null

        // 获取最后一条消息
        const { data: lastMessages } = await supabase
          .from('PrivateMessage')
          .select('content, createdAt, isRead, senderId')
          .or(`and(senderId.eq.${userId},receiverId.eq.${partnerId}),and(senderId.eq.${partnerId},receiverId.eq.${userId})`)
          .order('createdAt', { ascending: false })
          .limit(1)

        const lastMessage = lastMessages?.[0] || null

        // 获取未读消息数
        const { count: unreadCount } = await supabase
          .from('PrivateMessage')
          .select('*', { count: 'exact', head: true })
          .eq('senderId', partnerId)
          .eq('receiverId', userId)
          .eq('isRead', false)

        return {
          partner: normalizeUser(partner),
          lastMessage: lastMessage
            ? {
                content: lastMessage.content,
                createdAt: lastMessage.createdAt,
                isRead: lastMessage.isRead,
                isMine: lastMessage.senderId === userId,
              }
            : null,
          unreadCount: unreadCount || 0,
        }
      })
    )

    // 4. 过滤空值并按最后消息时间排序（降序）
    const validConversations = conversations.filter(Boolean).sort((a, b) => {
      const aTime = a!.lastMessage?.createdAt ? new Date(a!.lastMessage.createdAt).getTime() : 0
      const bTime = b!.lastMessage?.createdAt ? new Date(b!.lastMessage.createdAt).getTime() : 0
      return bTime - aTime
    })

    return NextResponse.json(validConversations)
  } catch (error) {
    console.error('获取会话列表失败:', error)
    return NextResponse.json(
      { error: '获取会话列表失败' },
      { status: 500 }
    )
  }
}
