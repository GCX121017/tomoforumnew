import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'
import { normalizeUser } from '@/lib/normalizeUser'

// GET /api/friends/requests?userId=xxx — 获取待处理的好友申请
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: '缺少用户ID' },
        { status: 400 }
      )
    }

    const { data: requests } = await supabase
      .from('FriendRequest')
      .select('*')
      .eq('toUserId', userId)
      .eq('status', 'pending')
      .order('createdAt', { ascending: false })

    if (!requests || requests.length === 0) {
      return NextResponse.json({ requests: [] })
    }

    // Batch fetch fromUser profiles
    const fromUserIds = [...new Set(requests.map((r: any) => r.fromUserId))]
    const { data: fromUsers } = await supabase
      .from('User')
      .select('id, username, displayName, avatar, level, points, bio')
      .in('id', fromUserIds)
    const userMap = new Map((fromUsers || []).map((u: any) => [u.id, normalizeUser(u)]))

    const result = requests.map((r: any) => ({
      ...r,
      fromUser: userMap.get(r.fromUserId) || null,
    }))

    return NextResponse.json({ requests: result })
  } catch (error) {
    console.error('获取好友申请列表失败:', error)
    return NextResponse.json(
      { error: '获取好友申请列表失败' },
      { status: 500 }
    )
  }
}
