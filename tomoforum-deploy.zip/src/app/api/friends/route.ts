import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'
import { normalizeUser, encodeUsername } from '@/lib/normalizeUser'

// GET /api/friends?userId=xxx — 获取好友列表
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: '缺少用户ID' },
        { status: 400 }
      )
    }

    // Get accepted friend requests where user is either from or to
    const { data: fromRequests } = await supabase
      .from('FriendRequest')
      .select('*')
      .eq('fromUserId', userId)
      .eq('status', 'accepted')

    const { data: toRequests } = await supabase
      .from('FriendRequest')
      .select('*')
      .eq('toUserId', userId)
      .eq('status', 'accepted')

    const allRequests = [...(fromRequests || []), ...(toRequests || [])]

    // Collect all other user IDs
    const otherUserIds = [...new Set(
      allRequests.map((fr) => fr.fromUserId === userId ? fr.toUserId : fr.fromUserId)
    )]

    if (otherUserIds.length === 0) {
      return NextResponse.json({ friends: [] })
    }

    // Batch fetch user profiles
    const { data: rawUsers } = await supabase
      .from('User')
      .select('id, username, displayName, avatar, level, points')
      .in('id', otherUserIds)
    const userMap = new Map((rawUsers || []).map((u: any) => [u.id, normalizeUser(u)]))

    // Build friends list
    const friends = allRequests.map((fr) => {
      const isFromMe = fr.fromUserId === userId
      const otherUserId = isFromMe ? fr.toUserId : fr.fromUserId
      const otherUser = userMap.get(otherUserId)
      if (!otherUser) return null
      return {
        friendshipId: fr.id,
        id: otherUser.id,
        username: otherUser.username,
        displayName: otherUser.displayName,
        avatar: otherUser.avatar,
        level: otherUser.level,
        points: otherUser.points,
        online: true,
      }
    }).filter(Boolean)

    return NextResponse.json({ friends })
  } catch (error) {
    console.error('获取好友列表失败:', error)
    return NextResponse.json(
      { error: '获取好友列表失败' },
      { status: 500 }
    )
  }
}

// POST /api/friends — 发送好友申请
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, targetUsername, message } = body

    if (!userId || !targetUsername) {
      return NextResponse.json(
        { error: '缺少必要参数' },
        { status: 400 }
      )
    }

    // 查找目标用户（编码 username 用于 DB 查询）
    const dbTargetUsername = encodeUsername(targetUsername)
    const { data: targetUser } = await supabase
      .from('User')
      .select('id, username')
      .eq('username', dbTargetUsername)
      .single()

    if (!targetUser) {
      return NextResponse.json(
        { error: '用户不存在' },
        { status: 404 }
      )
    }

    // 不能添加自己
    if (userId === targetUser.id) {
      return NextResponse.json(
        { error: '不能添加自己为好友' },
        { status: 400 }
      )
    }

    // 检查是否已有记录（双向检查）
    const { data: existingFrom } = await supabase
      .from('FriendRequest')
      .select('*')
      .eq('fromUserId', userId)
      .eq('toUserId', targetUser.id)
      .in('status', ['pending', 'accepted'])
      .limit(1)

    const { data: existingTo } = await supabase
      .from('FriendRequest')
      .select('*')
      .eq('fromUserId', targetUser.id)
      .eq('toUserId', userId)
      .in('status', ['pending', 'accepted'])
      .limit(1)

    const existingRequest = existingFrom?.[0] || existingTo?.[0]

    if (existingRequest) {
      if (existingRequest.status === 'accepted') {
        return NextResponse.json(
          { error: '你们已经是好友了' },
          { status: 400 }
        )
      }
      if (existingRequest.status === 'pending') {
        if (existingRequest.fromUserId === userId) {
          return NextResponse.json(
            { error: '已发送过好友申请，请等待对方回复' },
            { status: 400 }
          )
        } else {
          return NextResponse.json(
            { error: '对方已向你发送好友申请，请先处理' },
            { status: 400 }
          )
        }
      }
    }

    // 创建好友申请
    const { data: friendRequest } = await supabase
      .from('FriendRequest')
      .insert({
        fromUserId: userId,
        toUserId: targetUser.id,
        message: message || '',
        status: 'pending',
      })
      .select()
      .single()

    // Fetch fromUser for the response
    const { data: fromUser } = await supabase
      .from('User')
      .select('id, username, displayName, avatar')
      .eq('id', userId)
      .single()

    // 创建通知
    const notificationContent = message
      ? `向你发送了好友申请：${message}`
      : '向你发送了好友申请'

    await supabase.from('Notification').insert({
      type: 'friend_request',
      userId: targetUser.id,
      fromUserId: userId,
      content: notificationContent,
    })

    return NextResponse.json({
      request: {
        ...friendRequest,
        fromUser: fromUser ? { ...fromUser, displayName: fromUser.displayName || fromUser.username } : null,
      },
      message: '好友申请已发送',
    })
  } catch (error) {
    console.error('发送好友申请失败:', error)
    return NextResponse.json(
      { error: '发送好友申请失败' },
      { status: 500 }
    )
  }
}
