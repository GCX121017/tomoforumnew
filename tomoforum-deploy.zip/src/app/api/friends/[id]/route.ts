import { supabase } from '@/lib/supabase'
import { NextRequest, NextResponse } from 'next/server'

// PUT /api/friends/[id] — 接受或拒绝好友申请
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { userId, action } = body

    if (!userId || !action) {
      return NextResponse.json(
        { error: '缺少必要参数' },
        { status: 400 }
      )
    }

    if (action !== 'accept' && action !== 'reject') {
      return NextResponse.json(
        { error: '无效操作，只能是 accept 或 reject' },
        { status: 400 }
      )
    }

    // 查找好友申请
    const { data: friendRequest } = await supabase
      .from('FriendRequest')
      .select('*')
      .eq('id', id)
      .single()

    if (!friendRequest) {
      return NextResponse.json(
        { error: '好友申请不存在' },
        { status: 404 }
      )
    }

    // 验证：只有接收者才能操作
    if (friendRequest.toUserId !== userId) {
      return NextResponse.json(
        { error: '无权操作此好友申请' },
        { status: 403 }
      )
    }

    // 验证：只能操作 pending 状态的申请
    if (friendRequest.status !== 'pending') {
      return NextResponse.json(
        { error: '该好友申请已处理' },
        { status: 400 }
      )
    }

    if (action === 'accept') {
      // 接受好友申请
      await supabase
        .from('FriendRequest')
        .update({ status: 'accepted' })
        .eq('id', id)

      // 通知申请者：对方接受了好友申请
      await supabase.from('Notification').insert({
        type: 'friend_accept',
        userId: friendRequest.fromUserId,
        fromUserId: userId,
        content: '接受了你的好友申请',
      })

      return NextResponse.json({
        message: '已接受好友申请',
        friendshipId: id,
      })
    } else {
      // 拒绝好友申请
      await supabase
        .from('FriendRequest')
        .update({ status: 'rejected' })
        .eq('id', id)

      return NextResponse.json({
        message: '已拒绝好友申请',
      })
    }
  } catch (error) {
    console.error('处理好友申请失败:', error)
    return NextResponse.json(
      { error: '处理好友申请失败' },
      { status: 500 }
    )
  }
}

// DELETE /api/friends/[id]?userId=xxx — 删除好友
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { searchParams } = request.nextUrl
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: '缺少用户ID' },
        { status: 400 }
      )
    }

    // 查找好友申请
    const { data: friendRequest } = await supabase
      .from('FriendRequest')
      .select('*')
      .eq('id', id)
      .single()

    if (!friendRequest) {
      return NextResponse.json(
        { error: '好友关系不存在' },
        { status: 404 }
      )
    }

    // 验证：userId 必须是双方之一
    if (friendRequest.fromUserId !== userId && friendRequest.toUserId !== userId) {
      return NextResponse.json(
        { error: '无权操作' },
        { status: 403 }
      )
    }

    // 验证：只能删除已接受的（好友）关系
    if (friendRequest.status !== 'accepted') {
      return NextResponse.json(
        { error: '只能删除已建立的好友关系' },
        { status: 400 }
      )
    }

    // 删除好友关系
    await supabase.from('FriendRequest').delete().eq('id', id)

    return NextResponse.json({
      message: '已删除好友',
    })
  } catch (error) {
    console.error('删除好友失败:', error)
    return NextResponse.json(
      { error: '删除好友失败' },
      { status: 500 }
    )
  }
}
