'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { useForumStore } from '@/store/forum'
import { cn } from '@/components/forum/helpers'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  ArrowLeft, Trash2, FileText, MessageSquare, Users, Plus,
  Shield, Loader2, Eye, Pin, EyeOff, BarChart3, UserPlus
} from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { toast } from 'sonner'
import type { Category } from '@/store/forum'
import FormatToolbar from './FormatToolbar'
import LevelBadge from './LevelBadge'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'

type AdminTab = 'overview' | 'posts' | 'comments' | 'users' | 'createPost'

interface AdminPost {
  id: string
  title: string
  content: string
  isPinned: boolean
  createdAt: string
  author: { id: string; username: string; avatar: string; role: string }
  category: { id: string; name: string }
  _count: { comments: number; likes: number; bookmarks: number }
}

interface AdminComment {
  id: string
  content: string
  createdAt: string
  author: { id: string; username: string; avatar: string; role: string }
  post: { id: string; title: string }
}

interface AdminUser {
  id: string
  username: string
  avatar: string
  bio: string
  level: number
  points: number
  role: string
  createdAt: string
  _count: { posts: number; comments: number; followers: number }
}

export default function AdminPanel() {
  const { currentUser, navigate, categories, setCategories } = useForumStore()
  const [activeTab, setActiveTab] = useState<AdminTab>('overview')
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState({ userCount: 0, postCount: 0, commentCount: 0, recentPosts: [] as AdminPost[], recentUsers: [] as AdminUser[] })
  const [posts, setPosts] = useState<AdminPost[]>([])
  const [comments, setComments] = useState<AdminComment[]>([])
  const [users, setUsers] = useState<AdminUser[]>([])

  // Delete confirmation
  const [deleteTarget, setDeleteTarget] = useState<{ type: string; id: string; name: string } | null>(null)
  const [deleting, setDeleting] = useState(false)

  // Create official post
  const [newTitle, setNewTitle] = useState('')
  const [newContent, setNewContent] = useState('')
  const [newCategory, setNewCategory] = useState('')
  const [newPinned, setNewPinned] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const adminTextareaRef = useRef<HTMLTextAreaElement>(null)

  const fetchSection = useCallback(async (section: string) => {
    try {
      const res = await fetch(`/api/admin?section=${section}`)
      if (res.status === 403) {
        toast.error('无权访问管理后台')
        navigate({ name: 'home' })
        return null
      }
      if (!res.ok) return null
      return res.json()
    } catch {
      return null
    }
  }, [navigate])

  const loadOverview = useCallback(async () => {
    setLoading(true)
    const data = await fetchSection('overview')
    if (data) {
      setStats({
        userCount: data.userCount,
        postCount: data.postCount,
        commentCount: data.commentCount,
        recentPosts: data.recentPosts || [],
        recentUsers: data.recentUsers || [],
      })
    }
    setLoading(false)
  }, [fetchSection])

  const loadPosts = useCallback(async () => {
    setLoading(true)
    const data = await fetchSection('posts')
    if (data) setPosts(data)
    setLoading(false)
  }, [fetchSection])

  const loadComments = useCallback(async () => {
    setLoading(true)
    const data = await fetchSection('comments')
    if (data) setComments(data)
    setLoading(false)
  }, [fetchSection])

  const loadUsers = useCallback(async () => {
    setLoading(true)
    const data = await fetchSection('users')
    if (data) setUsers(data)
    setLoading(false)
  }, [fetchSection])

  useEffect(() => {
    if (!currentUser || currentUser.role !== 'official') {
      toast.error('无权访问')
      navigate({ name: 'home' })
      return
    }
    if (categories.length === 0) {
      fetch('/api/categories').then(r => r.json()).then(data => {
        if (Array.isArray(data)) setCategories(data)
      }).catch(() => {})
    }
    // eslint-disable-next-line react-hooks/set-state-in-effect
    loadOverview()
  }, [currentUser, navigate, categories.length, setCategories])

  useEffect(() => {
    switch (activeTab) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      case 'overview': loadOverview(); break
      case 'posts': loadPosts(); break
      case 'comments': loadComments(); break
      case 'users': loadUsers(); break
    }
  }, [activeTab, loadOverview, loadPosts, loadComments, loadUsers])

  const handleDelete = async () => {
    if (!deleteTarget) return
    setDeleting(true)
    try {
      const res = await fetch(`/api/admin?type=${deleteTarget.type}&id=${deleteTarget.id}`, { method: 'DELETE' })
      if (res.ok) {
        toast.success(`已删除${deleteTarget.type === 'post' ? '帖子' : deleteTarget.type === 'comment' ? '评论' : '用户'}`)
        setDeleteTarget(null)
        // Refresh current section
        switch (activeTab) {
          case 'overview': loadOverview(); break
          case 'posts': loadPosts(); break
          case 'comments': loadComments(); break
          case 'users': loadUsers(); break
        }
      } else {
        const data = await res.json()
        toast.error(data.error || '删除失败')
      }
    } catch {
      toast.error('删除失败')
    }
    setDeleting(false)
  }

  const handleTogglePin = async (post: AdminPost) => {
    try {
      const res = await fetch(`/api/posts/${post.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isPinned: !post.isPinned }),
      })
      if (res.ok) {
        toast.success(post.isPinned ? '已取消置顶' : '已置顶')
        if (activeTab === 'posts') loadPosts()
        else loadOverview()
      }
    } catch {
      toast.error('操作失败')
    }
  }

  const handleCreatePost = async () => {
    if (!newTitle.trim() || !newCategory) {
      toast.error('请填写标题和选择分类')
      return
    }
    setSubmitting(true)
    try {
      const res = await fetch('/api/admin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'createOfficialPost',
          title: newTitle.trim(),
          content: newContent.trim(),
          categoryId: newCategory,
          isPinned: newPinned,
        }),
      })
      if (res.ok) {
        toast.success('官方帖子已发布')
        setNewTitle('')
        setNewContent('')
        setNewCategory('')
        setNewPinned(true)
        setActiveTab('posts')
      } else {
        const data = await res.json()
        toast.error(data.error || '发布失败')
      }
    } catch {
      toast.error('发布失败')
    }
    setSubmitting(false)
  }

  const formatDate = (d: string) => {
    const date = new Date(d)
    return `${date.getMonth() + 1}/${date.getDate()} ${date.getHours()}:${String(date.getMinutes()).padStart(2, '0')}`
  }

  const tabs: { key: AdminTab; label: string; icon: React.ReactNode }[] = [
    { key: 'overview', label: '概览', icon: <BarChart3 className="size-4" /> },
    { key: 'posts', label: '帖子', icon: <FileText className="size-4" /> },
    { key: 'comments', label: '评论', icon: <MessageSquare className="size-4" /> },
    { key: 'users', label: '用户', icon: <Users className="size-4" /> },
    { key: 'createPost', label: '发官方帖', icon: <Plus className="size-4" /> },
  ]

  if (!currentUser || currentUser.role !== 'official') return null

  return (
    <motion.div
      initial={{ opacity: 0, x: 10 }}
      animate={{ opacity: 1, x: 0 }}
      className="flex-1 max-w-5xl mx-auto w-full px-4 py-6"
    >
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <button
          onClick={() => navigate({ name: 'home' })}
          className="p-1.5 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
        >
          <ArrowLeft className="size-4 text-gray-500" />
        </button>
        <div className="flex items-center gap-2">
          <Shield className="size-5 text-rose-600 dark:text-rose-400" />
          <h1 className="text-xl font-bold text-gray-900 dark:text-gray-100">管理后台</h1>
        </div>
        <Badge className="bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400 border-0">
          官方
        </Badge>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-6 overflow-x-auto no-scrollbar pb-1">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={cn(
              'flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition-colors',
              activeTab === tab.key
                ? 'bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900'
                : 'text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 dark:text-gray-400'
            )}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="min-h-[400px]">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="size-6 text-gray-400 animate-spin" />
          </div>
        ) : (
          <AnimatePresence mode="wait">
            {activeTab === 'overview' && (
              <motion.div key="overview" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-6">
                {/* Stat cards */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  {[
                    { label: '用户总数', value: stats.userCount, icon: <Users className="size-5" />, color: 'text-green-600 dark:text-green-400' },
                    { label: '帖子总数', value: stats.postCount, icon: <FileText className="size-5" />, color: 'text-blue-600 dark:text-blue-400' },
                    { label: '评论总数', value: stats.commentCount, icon: <MessageSquare className="size-5" />, color: 'text-purple-600 dark:text-purple-400' },
                  ].map((stat) => (
                    <div key={stat.label} className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-4">
                      <div className={cn('mb-2', stat.color)}>{stat.icon}</div>
                      <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">{stat.value}</p>
                      <p className="text-xs text-gray-400 mt-0.5">{stat.label}</p>
                    </div>
                  ))}
                </div>

                {/* Recent Posts */}
                <div>
                  <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">最近帖子</h3>
                  <div className="space-y-2">
                    {stats.recentPosts.slice(0, 5).map((post) => (
                      <div key={post.id} className="flex items-center gap-3 p-3 bg-white dark:bg-gray-900 rounded-lg border border-gray-100 dark:border-gray-800">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">{post.title}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-xs text-gray-400">{post.author.username}</span>
                            <span className="text-xs text-gray-300 dark:text-gray-600">·</span>
                            <span className="text-xs text-gray-400">{formatDate(post.createdAt)}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-gray-400 shrink-0">
                          <span>{post._count.likes}赞</span>
                          <span>{post._count.comments}评</span>
                        </div>
                        <div className="flex gap-1 shrink-0">
                          <button onClick={() => navigate({ name: 'post', postId: post.id })} className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors" title="查看">
                            <Eye className="size-3.5 text-gray-400" />
                          </button>
                          <button onClick={() => setDeleteTarget({ type: 'post', id: post.id, name: post.title })} className="p-1 rounded hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors" title="删除">
                            <Trash2 className="size-3.5 text-red-400" />
                          </button>
                        </div>
                      </div>
                    ))}
                    {stats.recentPosts.length === 0 && <p className="text-sm text-gray-400 text-center py-8">暂无帖子</p>}
                  </div>
                </div>

                {/* Recent Users */}
                <div>
                  <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">最近用户</h3>
                  <div className="space-y-2">
                    {stats.recentUsers.slice(0, 5).map((user) => (
                      <div key={user.id} className="flex items-center gap-3 p-3 bg-white dark:bg-gray-900 rounded-lg border border-gray-100 dark:border-gray-800">
                        <Avatar className="size-8">
                          <AvatarImage src={user.avatar} alt={user.username} />
                          <AvatarFallback className="text-xs">{user.username.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">{user.username}</span>
                            <LevelBadge role={user.role} level={user.level} size="sm" />
                          </div>
                          <span className="text-xs text-gray-400">{formatDate(user.createdAt)}</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-gray-400 shrink-0">
                          <span>{user._count.posts}帖</span>
                          <span>{user._count.comments}评</span>
                        </div>
                        <button onClick={() => setDeleteTarget({ type: 'user', id: user.id, name: user.username })} className="p-1 rounded hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors shrink-0" title="删除用户">
                          <Trash2 className="size-3.5 text-red-400" />
                        </button>
                      </div>
                    ))}
                    {stats.recentUsers.length === 0 && <p className="text-sm text-gray-400 text-center py-8">暂无用户</p>}
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'posts' && (
              <motion.div key="posts" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-2">
                {posts.map((post) => (
                  <div key={post.id} className="flex items-center gap-3 p-3 bg-white dark:bg-gray-900 rounded-lg border border-gray-100 dark:border-gray-800">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        {post.isPinned && <Pin className="size-3 text-orange-500 shrink-0" />}
                        <p className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">{post.title}</p>
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs text-gray-400">{post.author.username}</span>
                        <Badge variant="secondary" className="text-[10px] px-1.5 py-0">{post.category.name}</Badge>
                        <span className="text-xs text-gray-400">{formatDate(post.createdAt)}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-gray-400 shrink-0">
                      <span>{post._count.likes}赞</span>
                      <span>{post._count.comments}评</span>
                      <span>{post._count.bookmarks}藏</span>
                    </div>
                    <div className="flex gap-1 shrink-0">
                      <button onClick={() => navigate({ name: 'post', postId: post.id })} className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors" title="查看">
                        <Eye className="size-3.5 text-gray-400" />
                      </button>
                      <button onClick={() => handleTogglePin(post)} className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors" title={post.isPinned ? '取消置顶' : '置顶'}>
                        {post.isPinned ? <EyeOff className="size-3.5 text-gray-400" /> : <Pin className="size-3.5 text-gray-400" />}
                      </button>
                      <button onClick={() => setDeleteTarget({ type: 'post', id: post.id, name: post.title })} className="p-1 rounded hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors" title="删除">
                        <Trash2 className="size-3.5 text-red-400" />
                      </button>
                    </div>
                  </div>
                ))}
                {posts.length === 0 && <p className="text-sm text-gray-400 text-center py-8">暂无帖子</p>}
              </motion.div>
            )}

            {activeTab === 'comments' && (
              <motion.div key="comments" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-2">
                {comments.map((comment) => (
                  <div key={comment.id} className="p-3 bg-white dark:bg-gray-900 rounded-lg border border-gray-100 dark:border-gray-800">
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="text-sm font-medium text-gray-900 dark:text-gray-100">{comment.author.username}</span>
                      <span className="text-xs text-gray-400">{formatDate(comment.createdAt)}</span>
                      <button onClick={() => setDeleteTarget({ type: 'comment', id: comment.id, name: '该评论' })} className="ml-auto p-1 rounded hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors" title="删除">
                        <Trash2 className="size-3.5 text-red-400" />
                      </button>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-300 line-clamp-2">{comment.content}</p>
                    <p className="text-xs text-gray-400 mt-1.5 truncate">原文: {comment.post.title}</p>
                  </div>
                ))}
                {comments.length === 0 && <p className="text-sm text-gray-400 text-center py-8">暂无评论</p>}
              </motion.div>
            )}

            {activeTab === 'users' && (
              <motion.div key="users" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-2">
                {users.map((user) => (
                  <div key={user.id} className="flex items-center gap-3 p-3 bg-white dark:bg-gray-900 rounded-lg border border-gray-100 dark:border-gray-800">
                    <Avatar className="size-8">
                      <AvatarImage src={user.avatar} alt={user.username} />
                      <AvatarFallback className="text-xs">{user.username.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-sm font-medium text-gray-900 dark:text-gray-100">{user.username}</span>
                        <LevelBadge role={user.role} level={user.level} size="sm" />
                      </div>
                      <div className="flex items-center gap-2 mt-0.5 text-xs text-gray-400">
                        <span>{user.points}积分</span>
                        <span>·</span>
                        <span>{user._count.posts}帖</span>
                        <span>·</span>
                        <span>{user._count.comments}评</span>
                        <span>·</span>
                        <span>{user._count.followers}粉丝</span>
                        <span>·</span>
                        <span>{formatDate(user.createdAt)}</span>
                      </div>
                    </div>
                    <button onClick={() => setDeleteTarget({ type: 'user', id: user.id, name: user.username })} className="p-1.5 rounded hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors shrink-0" title="删除用户">
                      <Trash2 className="size-3.5 text-red-400" />
                    </button>
                  </div>
                ))}
                {users.length === 0 && <p className="text-sm text-gray-400 text-center py-8">暂无用户</p>}
              </motion.div>
            )}

            {activeTab === 'createPost' && (
              <motion.div key="createPost" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-5">
                <div>
                  <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">标题</h3>
                  <Input value={newTitle} onChange={(e) => setNewTitle(e.target.value)} placeholder="官方公告标题" maxLength={100} />
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">分类</h3>
                  <Select value={newCategory} onValueChange={setNewCategory}>
                    <SelectTrigger><SelectValue placeholder="选择分类" /></SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat.id} value={cat.id}>{cat.icon} {cat.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">内容（支持 Markdown）</h3>
                  <div className="relative">
                    <FormatToolbar textareaRef={adminTextareaRef} content={newContent} onChange={setNewContent} />
                    <Textarea ref={adminTextareaRef} value={newContent} onChange={(e) => setNewContent(e.target.value)} placeholder="公告内容..." className="min-h-48 rounded-t-none" />
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant={newPinned ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setNewPinned(!newPinned)}
                    className={newPinned ? 'bg-orange-500 hover:bg-orange-600 text-white border-orange-500' : 'border-gray-200 dark:border-gray-700'}
                  >
                    <Pin className="size-3.5" />
                    {newPinned ? '置顶' : '不置顶'}
                  </Button>
                </div>
                <div className="flex justify-end gap-3">
                  <Button variant="outline" onClick={() => navigate({ name: 'home' })} className="border-gray-200 dark:border-gray-700">取消</Button>
                  <Button
                    onClick={handleCreatePost}
                    disabled={submitting || !newTitle.trim() || !newCategory}
                    className="bg-gray-900 hover:bg-gray-800 text-white min-w-24"
                  >
                    {submitting ? <Loader2 className="size-4 animate-spin" /> : <><Shield className="size-3.5" /> 发布</>}
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        )}
      </div>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteTarget?.type === 'user'
                ? `确定要删除用户「${deleteTarget?.name}」吗？该用户的所有帖子、评论、点赞等数据将一并删除，此操作不可恢复。`
                : `确定要删除${deleteTarget?.type === 'post' ? '帖子' : '评论'}「${deleteTarget?.name}」吗？此操作不可恢复。`
              }
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>取消</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} disabled={deleting} className="bg-red-600 hover:bg-red-700 text-white">
              {deleting ? <Loader2 className="size-4 animate-spin" /> : '确认删除'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </motion.div>
  )
}
