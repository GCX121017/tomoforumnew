'use client'

import { useEffect, useRef, useReducer, useCallback, useState } from 'react'
import { useForumStore, type Post } from '@/store/forum'
import PostCard from './PostCard'
import { Skeleton } from '@/components/ui/skeleton'
import { Inbox, X, Users, LogIn, User, Filter, Search, Shield, Award, ChevronDown } from 'lucide-react'
import { cn } from '@/components/forum/helpers'
import { motion, AnimatePresence } from 'framer-motion'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'

const POSTS_PER_PAGE = 15
const BANNER_DISMISSED_KEY = 'forum_welcome_banner_dismissed'

interface ListState {
  allPosts: Post[]
  totalPosts: number
  page: number
  initialLoading: boolean
  loadingMore: boolean
  hasMore: boolean
}

type ListAction =
  | { type: 'RESET' }
  | { type: 'SET_LOADING' }
  | { type: 'SET_LOADING_DONE' }
  | { type: 'SET_LOADING_MORE' }
  | { type: 'SET_LOADING_MORE_DONE' }
  | { type: 'APPEND_POSTS'; posts: Post[]; total: number }
  | { type: 'SET_POSTS'; posts: Post[]; total: number }

function listReducer(state: ListState, action: ListAction): ListState {
  switch (action.type) {
    case 'RESET':
      return {
        allPosts: [],
        totalPosts: 0,
        page: 1,
        initialLoading: true,
        loadingMore: false,
        hasMore: true,
      }
    case 'SET_LOADING':
      return { ...state, initialLoading: true }
    case 'SET_LOADING_DONE':
      return { ...state, initialLoading: false }
    case 'SET_LOADING_MORE':
      return { ...state, loadingMore: true }
    case 'SET_LOADING_MORE_DONE':
      return { ...state, loadingMore: false }
    case 'APPEND_POSTS':
      return {
        ...state,
        allPosts: [...state.allPosts, ...action.posts],
        totalPosts: action.total,
        hasMore: state.allPosts.length + action.posts.length < action.total,
        page: state.page + 1,
      }
    case 'SET_POSTS':
      return {
        ...state,
        allPosts: action.posts,
        totalPosts: action.total,
        hasMore: action.posts.length < action.total,
      }
    default:
      return state
  }
}

interface UserFilterState {
  id: string
  username: string
  avatar: string
}

interface FilterType {
  kind: 'user' | 'highLevel' | 'official'
  user?: UserFilterState
}

export default function PostList() {
  const {
    currentPage,
    setPosts,
    setTotalPosts,
    activeFeed,
    setActiveFeed,
    currentUser,
    setShowLoginDialog,
  } = useForumStore()

  const [state, dispatch] = useReducer(listReducer, {
    allPosts: [],
    totalPosts: 0,
    page: 1,
    initialLoading: true,
    loadingMore: false,
    hasMore: true,
  })

  const [sort, setSort] = useReducer((_prev: string, next: string) => next, 'random')
  const sentinelRef = useRef<HTMLDivElement>(null)

  // Follow status state
  const [followedAuthors, setFollowedAuthors] = useState<Record<string, boolean>>({})
  const followStatusRef = useRef<Record<string, boolean>>({})

  // User filter state
  const [activeFilter, setActiveFilter] = useState<FilterType | null>(null)
  const [filterPanelOpen, setFilterPanelOpen] = useState(false)
  const [userSearchQuery, setUserSearchQuery] = useState('')
  const [userSearchResults, setUserSearchResults] = useState<UserFilterState[]>([])
  const [userSearchLoading, setUserSearchLoading] = useState(false)
  const searchInputRef = useRef<HTMLInputElement>(null)
  const searchDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const filterPanelRef = useRef<HTMLDivElement>(null)

  const categoryId = currentPage.name === 'home' ? currentPage.categoryId : undefined
  const tag = currentPage.name === 'home' ? currentPage.tag : undefined
  const isHomePage = currentPage.name === 'home' && !categoryId && !tag
  const showFeedToggle = isHomePage

  const [bannerDismissed, setBannerDismissed] = useState(() => {
    if (typeof window === 'undefined') return false
    try {
      return localStorage.getItem(BANNER_DISMISSED_KEY) === 'true'
    } catch { return false }
  })

  // Build the filter key string for reset tracking
  const filterKey = activeFilter
    ? activeFilter.kind === 'user'
      ? `user-${activeFilter.user?.id || ''}`
      : activeFilter.kind
    : 'none'

  // Reset when filters change
  const [prevFilters, setPrevFilters] = useReducer(
    (_prev: string, next: string) => next,
    `${sort}-${categoryId || ''}-${tag || ''}-${activeFeed}-${filterKey}`
  )
  const currentFilters = `${sort}-${categoryId || ''}-${tag || ''}-${activeFeed}-${filterKey}`

  if (prevFilters !== currentFilters) {
    setPrevFilters(currentFilters)
    dispatch({ type: 'RESET' })
  }

  // Fetch posts
  const doFetch = useCallback(async (pageNum: number, append: boolean) => {
    try {
      const params = new URLSearchParams({
        page: String(pageNum),
        limit: String(POSTS_PER_PAGE),
        sort,
      })
      if (categoryId) params.set('categoryId', categoryId)
      if (tag) params.set('search', tag)
      if (activeFeed === 'following' && currentUser) {
        params.set('following', 'true')
        params.set('userId', currentUser.id)
      }

      // Apply user filter
      if (activeFilter) {
        if (activeFilter.kind === 'user' && activeFilter.user) {
          params.set('authorId', activeFilter.user.id)
        } else if (activeFilter.kind === 'highLevel') {
          params.set('filterType', 'highLevel')
        } else if (activeFilter.kind === 'official') {
          params.set('filterType', 'official')
        }
      }

      const res = await fetch(`/api/posts?${params}`)
      if (res.ok) {
        const data = await res.json()
        const newPosts: Post[] = data.posts || []
        const total: number = data.total || 0

        if (append) {
          dispatch({ type: 'APPEND_POSTS', posts: newPosts, total })
        } else {
          dispatch({ type: 'SET_POSTS', posts: newPosts, total })
          setPosts(newPosts)
          setTotalPosts(total)
        }
      }
    } catch { /* ignore */ }
    if (append) {
      dispatch({ type: 'SET_LOADING_MORE_DONE' })
    } else {
      dispatch({ type: 'SET_LOADING_DONE' })
    }
  }, [sort, categoryId, tag, activeFeed, currentUser, setPosts, setTotalPosts, activeFilter])

  // Initial fetch on filter change
  useEffect(() => {
    dispatch({ type: 'SET_LOADING' })
    doFetch(1, false)
  }, [currentFilters, doFetch])

  // IntersectionObserver for infinite scroll
  useEffect(() => {
    const sentinel = sentinelRef.current
    if (!sentinel) return
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && state.hasMore && !state.loadingMore && !state.initialLoading) {
          dispatch({ type: 'SET_LOADING_MORE' })
          doFetch(state.page + 1, true)
        }
      },
      { rootMargin: '200px' }
    )
    observer.observe(sentinel)
    return () => observer.disconnect()
  }, [state.hasMore, state.loadingMore, state.initialLoading, state.page, doFetch])

  // Fetch follow status for all visible authors
  const fetchFollowStatus = useCallback((posts: Post[]) => {
    if (!currentUser) return
    const authorIds = [...new Set(posts.map((p) => p.authorId).filter((id) => id !== currentUser.id))]
    if (authorIds.length === 0) return

    fetch(`/api/follows/status?viewerId=${currentUser.id}&targetIds=${authorIds.join(',')}`)
      .then((res) => res.ok ? res.json() : null)
      .then((data) => {
        if (data?.statuses) {
          followStatusRef.current = { ...followStatusRef.current, ...data.statuses }
          setFollowedAuthors({ ...followStatusRef.current })
        }
      })
      .catch(() => { /* ignore */ })
  }, [currentUser])

  // Fetch follow status when posts change
  useEffect(() => {
    if (state.allPosts.length > 0 && currentUser) {
      fetchFollowStatus(state.allPosts)
    } else if (!currentUser && Object.keys(followStatusRef.current).length > 0) {
      followStatusRef.current = {}
      // Clear stale follow data when no user is logged in (deferred to avoid cascade)
      requestAnimationFrame(() => setFollowedAuthors({}))
    }
  }, [state.allPosts.length, currentUser, fetchFollowStatus])

  // User search with debounce
  const handleUserSearch = useCallback((query: string) => {
    setUserSearchQuery(query)
    if (searchDebounceRef.current) {
      clearTimeout(searchDebounceRef.current)
    }
    if (!query.trim()) {
      setUserSearchResults([])
      return
    }
    searchDebounceRef.current = setTimeout(async () => {
      setUserSearchLoading(true)
      try {
        const res = await fetch(`/api/users?search=${encodeURIComponent(query.trim())}`)
        if (res.ok) {
          const data = await res.json()
          setUserSearchResults(
            (Array.isArray(data) ? data : []).slice(0, 5).map((u: { id: string; username: string; avatar: string }) => ({
              id: u.id,
              username: u.username,
              avatar: u.avatar,
            }))
          )
        }
      } catch {
        setUserSearchResults([])
      }
      setUserSearchLoading(false)
    }, 300)
  }, [])

  // Close filter panel on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (filterPanelRef.current && !filterPanelRef.current.contains(e.target as Node)) {
        setFilterPanelOpen(false)
      }
    }
    if (filterPanelOpen) {
      document.addEventListener('mousedown', handleClickOutside)
      return () => document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [filterPanelOpen])

  // Focus search input when panel opens
  useEffect(() => {
    if (filterPanelOpen && searchInputRef.current) {
      setTimeout(() => searchInputRef.current?.focus(), 100)
    }
  }, [filterPanelOpen])

  const handleSortChange = (newSort: string) => {
    setSort(newSort)
  }

  const handleSelectUser = (user: UserFilterState) => {
    setActiveFilter({ kind: 'user', user })
    setFilterPanelOpen(false)
    setUserSearchQuery('')
    setUserSearchResults([])
  }

  const handleSelectSpecialFilter = (kind: 'highLevel' | 'official') => {
    setActiveFilter({ kind })
    setFilterPanelOpen(false)
    setUserSearchQuery('')
    setUserSearchResults([])
  }

  const handleClearFilter = () => {
    setActiveFilter(null)
  }

  // Handle follow from PostCard
  const handleFollowAuthor = useCallback(async (authorId: string) => {
    if (!currentUser || !authorId) return
    // Optimistic update
    const wasFollowing = followStatusRef.current[authorId] ?? false
    followStatusRef.current[authorId] = !wasFollowing
    setFollowedAuthors({ ...followStatusRef.current })
    try {
      const res = await fetch(`/api/users/${authorId}/follow`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ followerId: currentUser.id }),
      })
      if (res.ok) {
        const data = await res.json()
        followStatusRef.current[authorId] = data.following
        setFollowedAuthors({ ...followStatusRef.current })
      } else {
        // Revert on failure
        followStatusRef.current[authorId] = wasFollowing
        setFollowedAuthors({ ...followStatusRef.current })
      }
    } catch {
      followStatusRef.current[authorId] = wasFollowing
      setFollowedAuthors({ ...followStatusRef.current })
    }
  }, [currentUser])

  const handleDismissBanner = () => {
    setBannerDismissed(true)
    try {
      localStorage.setItem(BANNER_DISMISSED_KEY, 'true')
    } catch { /* ignore */ }
  }

  const sortOptions = [
    { value: 'random', label: '随机推荐' },
    { value: 'latest', label: '最新' },
    { value: 'oldest', label: '最早' },
    { value: 'hot', label: '最热' },
    { value: 'commented', label: '最多评论' },
    { value: 'viewed', label: '最多浏览' },
  ]

  const isFollowingFeed = activeFeed === 'following'
  const isFollowingWithoutUser = isFollowingFeed && !currentUser

  // Label for active filter
  const activeFilterLabel = activeFilter
    ? activeFilter.kind === 'user'
      ? activeFilter.user?.username
      : activeFilter.kind === 'highLevel'
        ? '高级用户'
        : '官方'
    : null

  return (
    <div className="flex-1 min-w-0">
      {/* Welcome Banner - Home page only, dismissible */}
      <AnimatePresence>
        {isHomePage && !bannerDismissed && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10, height: 0, marginBottom: 0 }}
            transition={{ duration: 0.3 }}
            className="mb-4 rounded-xl bg-gradient-to-br from-gray-900 to-gray-800 dark:from-gray-800 dark:to-gray-900 p-5 text-white relative overflow-hidden"
          >
            <button
              onClick={handleDismissBanner}
              className="absolute top-2 right-2 p-2 rounded-md hover:bg-white/10 transition-colors"
              aria-label="关闭横幅"
            >
              <X className="size-5 text-white/60 hover:text-white" />
            </button>
            <h2 className="text-lg font-bold mb-1">欢迎来到「明天后」</h2>
            <p className="text-sm text-gray-300">以黑白之名，书写明天。在这里分享你的想法、交流知识、结交朋友。</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Sort tabs + filter bar */}
      <div className="sticky top-14 z-10 bg-white/90 backdrop-blur-md border-b border-gray-100 dark:bg-gray-900/90 dark:border-gray-800">
        <div className="px-4 py-2.5 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar flex-shrink min-w-0">
            {/* Feed toggle - pill style */}
            {showFeedToggle && (
              <div className="flex items-center bg-gray-100 dark:bg-gray-800 rounded-full p-0.5 mr-1 flex-shrink-0">
                <button
                  onClick={() => setActiveFeed('all')}
                  className={cn(
                    'px-3 py-1 rounded-full text-[13px] font-medium transition-all duration-200',
                    activeFeed === 'all'
                      ? 'bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900 shadow-sm'
                      : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
                  )}
                >
                  全部
                </button>
                <button
                  onClick={() => {
                    if (!currentUser) {
                      setShowLoginDialog(true)
                      return
                    }
                    setActiveFeed('following')
                  }}
                  className={cn(
                    'px-3 py-1 rounded-full text-[13px] font-medium transition-all duration-200',
                    activeFeed === 'following'
                      ? 'bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900 shadow-sm'
                      : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
                  )}
                >
                  关注动态
                </button>
              </div>
            )}
            {/* Sort options */}
            {sortOptions.map((option) => (
              <button
                key={option.value}
                onClick={() => handleSortChange(option.value)}
                className={cn(
                  'px-3 py-1.5 rounded-md text-[13px] font-medium transition-colors relative whitespace-nowrap flex-shrink-0',
                  sort === option.value
                    ? 'bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900'
                    : 'text-gray-500 hover:text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:text-gray-300 dark:hover:bg-gray-800'
                )}
              >
                {option.label}
                {sort === option.value && (
                  <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-4 h-0.5 bg-gray-900 dark:bg-gray-100 rounded-full" />
                )}
              </button>
            ))}
          </div>
          <span className="text-xs text-gray-400 dark:text-gray-500 whitespace-nowrap flex-shrink-0">
            共 {state.totalPosts} 篇帖子
          </span>
        </div>

        {/* User filter row */}
        <div className="px-4 pb-2.5">
          <div className="flex items-center gap-2 flex-wrap">
            {/* Active filter chip */}
            {activeFilter && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.2 }}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900 text-xs font-medium"
              >
                {activeFilter.kind === 'user' && activeFilter.user && (
                  <>
                    <Avatar className="size-4 rounded-full">
                      <AvatarImage src={activeFilter.user.avatar} alt={activeFilter.user.username} />
                      <AvatarFallback className="text-[8px] bg-gray-200 dark:bg-gray-800">
                        {activeFilter.user.username.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <span>{activeFilter.user.username}</span>
                  </>
                )}
                {activeFilter.kind === 'highLevel' && (
                  <>
                    <Award className="size-3" />
                    <span>高级用户</span>
                  </>
                )}
                {activeFilter.kind === 'official' && (
                  <>
                    <Shield className="size-3" />
                    <span>官方</span>
                  </>
                )}
                <button
                  onClick={handleClearFilter}
                  className="ml-0.5 hover:bg-white/20 dark:hover:bg-black/20 rounded-full p-0.5 transition-colors"
                  aria-label="清除筛选"
                >
                  <X className="size-3" />
                </button>
              </motion.div>
            )}

            {/* Filter toggle button */}
            <button
              onClick={() => setFilterPanelOpen((prev) => !prev)}
              className={cn(
                'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium transition-colors border',
                filterPanelOpen
                  ? 'border-gray-900 dark:border-gray-100 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-gray-100'
                  : 'border-gray-200 dark:border-gray-700 text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300 dark:hover:border-gray-600'
              )}
            >
              <Filter className="size-3" />
              <span>筛选用户</span>
              <ChevronDown
                className={cn(
                  'size-3 transition-transform duration-200',
                  filterPanelOpen && 'rotate-180'
                )}
              />
            </button>
          </div>

          {/* Filter dropdown panel */}
          <AnimatePresence>
            {filterPanelOpen && (
              <motion.div
                ref={filterPanelRef}
                initial={{ opacity: 0, y: -4, height: 0 }}
                animate={{ opacity: 1, y: 0, height: 'auto' }}
                exit={{ opacity: 0, y: -4, height: 0 }}
                transition={{ duration: 0.2, ease: 'easeInOut' }}
                className="overflow-hidden mt-2"
              >
                <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl shadow-lg p-3 space-y-3">
                  {/* User search */}
                  <div className="relative">
                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 size-3.5 text-gray-400" />
                    <input
                      ref={searchInputRef}
                      type="text"
                      placeholder="搜索用户名..."
                      value={userSearchQuery}
                      onChange={(e) => handleUserSearch(e.target.value)}
                      className="w-full pl-8 pr-3 py-2 text-xs bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900/10 dark:focus:ring-gray-100/10 focus:border-gray-300 dark:focus:border-gray-600 placeholder:text-gray-400 dark:placeholder:text-gray-500 text-gray-900 dark:text-gray-100 transition-colors"
                    />
                    {userSearchLoading && (
                      <div className="absolute right-2.5 top-1/2 -translate-y-1/2">
                        <div className="size-3.5 border-2 border-gray-300 dark:border-gray-600 border-t-gray-900 dark:border-t-gray-100 rounded-full animate-spin" />
                      </div>
                    )}
                  </div>

                  {/* Search results */}
                  {userSearchQuery.trim() && userSearchResults.length > 0 && (
                    <div className="space-y-0.5">
                      {userSearchResults.map((user) => (
                        <button
                          key={user.id}
                          onClick={() => handleSelectUser(user)}
                          className="w-full flex items-center gap-2.5 px-2 py-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors group"
                        >
                          <Avatar className="size-6 rounded-full">
                            <AvatarImage src={user.avatar} alt={user.username} />
                            <AvatarFallback className="text-[10px] bg-gray-100 dark:bg-gray-800">
                              {user.username.charAt(0)}
                            </AvatarFallback>
                          </Avatar>
                          <span className="text-xs font-medium text-gray-700 dark:text-gray-300 group-hover:text-gray-900 dark:group-hover:text-gray-100 transition-colors">
                            {user.username}
                          </span>
                          <User className="size-3 text-gray-400 ml-auto" />
                        </button>
                      ))}
                    </div>
                  )}

                  {userSearchQuery.trim() && !userSearchLoading && userSearchResults.length === 0 && (
                    <p className="text-xs text-gray-400 dark:text-gray-500 text-center py-2">
                      未找到匹配用户
                    </p>
                  )}

                  {/* Divider */}
                  <div className="border-t border-gray-100 dark:border-gray-800" />

                  {/* Special filters */}
                  <div className="space-y-1">
                    <button
                      onClick={() => handleSelectSpecialFilter('highLevel')}
                      className={cn(
                        'w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg transition-colors',
                        activeFilter?.kind === 'highLevel'
                          ? 'bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900'
                          : 'hover:bg-gray-50 dark:hover:bg-gray-800 text-gray-600 dark:text-gray-400'
                      )}
                    >
                      <Award className="size-3.5" />
                      <div className="text-left">
                        <span className="text-xs font-medium">高级用户</span>
                        <p className="text-[10px] text-gray-400 dark:text-gray-500 mt-0.5">
                          等级 ≥ 2 的用户帖子
                        </p>
                      </div>
                    </button>
                    <button
                      onClick={() => handleSelectSpecialFilter('official')}
                      className={cn(
                        'w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg transition-colors',
                        activeFilter?.kind === 'official'
                          ? 'bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900'
                          : 'hover:bg-gray-50 dark:hover:bg-gray-800 text-gray-600 dark:text-gray-400'
                      )}
                    >
                      <Shield className="size-3.5" />
                      <div className="text-left">
                        <span className="text-xs font-medium">官方</span>
                        <p className="text-[10px] text-gray-400 dark:text-gray-500 mt-0.5">
                          官方账号发布的帖子
                        </p>
                      </div>
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Login prompt for following feed */}
      {isFollowingWithoutUser && !state.initialLoading && (
        <div className="mt-3 bg-white border border-gray-100 dark:bg-gray-900 dark:border-gray-800 rounded-lg p-12 flex flex-col items-center justify-center text-center">
          <div className="size-16 rounded-2xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center mb-4">
            <LogIn className="size-8 text-gray-400 dark:text-gray-500" />
          </div>
          <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">登录后查看关注动态</p>
          <p className="text-xs text-gray-400 dark:text-gray-500 mb-4">关注你感兴趣的用户，第一时间看到他们的新帖子</p>
          <button
            onClick={() => setShowLoginDialog(true)}
            className="px-5 py-2 bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900 rounded-full text-sm font-medium hover:bg-gray-800 dark:hover:bg-gray-200 transition-colors"
          >
            去登录
          </button>
        </div>
      )}

      {/* Post list */}
      {!isFollowingWithoutUser && (
        <div className="bg-white border border-gray-100 dark:bg-gray-900 dark:border-gray-800 rounded-lg mt-3 overflow-hidden">
          {state.initialLoading ? (
            <div className="divide-y divide-gray-50 dark:divide-gray-800/50">
              <div className="px-4 py-3 bg-gray-50/80 dark:bg-gray-800/30 border-b border-gray-100 dark:border-gray-800">
                <p className="text-xs text-gray-400 dark:text-gray-500 animate-pulse">
                  正在加载 {POSTS_PER_PAGE} 篇帖子...
                </p>
              </div>
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="px-4 py-4 flex gap-3" style={{ animationDelay: `${i * 100}ms` }}>
                  <div className="skeleton-shimmer size-10 rounded-full shrink-0" />
                  <div className="flex-1 space-y-2">
                    <div className="skeleton-shimmer h-3 w-20 rounded" />
                    <div className="skeleton-shimmer h-4 w-3/4 rounded" />
                    <div className="skeleton-shimmer h-3 w-full rounded" />
                    <div className="skeleton-shimmer h-3 w-1/2 rounded" />
                  </div>
                </div>
              ))}
            </div>
          ) : state.allPosts.length === 0 ? (
            <div className="py-24 flex flex-col items-center justify-center text-gray-400 dark:text-gray-500 bg-gray-50/50 dark:bg-gray-800/30">
              {isFollowingFeed ? (
                <>
                  <div className="size-20 rounded-2xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center mb-5">
                    <Users className="size-10 text-gray-300 dark:text-gray-600" />
                  </div>
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1.5">还没有关注任何人</p>
                  <p className="text-xs text-gray-400 dark:text-gray-500">去发现感兴趣的用户吧</p>
                </>
              ) : (
                <>
                  <div className="size-20 rounded-2xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center mb-5">
                    <Inbox className="size-10 text-gray-300 dark:text-gray-600" />
                  </div>
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1.5">
                    {activeFilter ? `暂无${activeFilterLabel}的帖子` : '暂无帖子'}
                  </p>
                  <p className="text-xs text-gray-400 dark:text-gray-500">
                    {activeFilter ? '尝试更换筛选条件' : '成为第一个发帖的人吧'}
                  </p>
                </>
              )}
            </div>
          ) : (
            <div className="divide-y divide-gray-50 dark:divide-gray-800/50">
              {state.allPosts.map((post, index) => (
                <PostCard key={post.id} post={post} index={index} followedAuthors={followedAuthors} onFollowAuthor={handleFollowAuthor} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Infinite scroll sentinel + loading/end indicator */}
      <div ref={sentinelRef} className="flex flex-col items-center py-6">
        {state.loadingMore && (
          <div className="w-full max-w-md space-y-3 px-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="flex gap-3">
                <div className="skeleton-shimmer size-10 rounded-full shrink-0" />
                <div className="flex-1 space-y-2">
                  <div className="skeleton-shimmer h-3 w-20 rounded" />
                  <div className="skeleton-shimmer h-4 w-3/4 rounded" />
                  <div className="skeleton-shimmer h-3 w-full rounded" />
                </div>
              </div>
            ))}
            <p className="text-xs text-gray-400 text-center pt-2">加载更多...</p>
          </div>
        )}
        {!state.initialLoading && !state.loadingMore && !state.hasMore && state.allPosts.length > 0 && (
          <p className="text-xs text-gray-400 dark:text-gray-500">没有更多了</p>
        )}
      </div>
    </div>
  )
}
