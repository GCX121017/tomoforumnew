'use client'

import { useState, useEffect } from 'react'
import { useForumStore } from '@/store/forum'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog'
import { toast } from 'sonner'
import { Loader2 } from 'lucide-react'

interface EditProfileProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export default function EditProfile({ open, onOpenChange }: EditProfileProps) {
  const { currentUser, setCurrentUser } = useForumStore()
  const [bio, setBio] = useState('')
  const [avatarSeed, setAvatarSeed] = useState('')
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (open && currentUser) {
      setBio(currentUser.bio || '')
      setAvatarSeed(currentUser.username || '')
    }
  }, [open, currentUser])

  const avatarUrl = avatarSeed
    ? `https://api.dicebear.com/9.x/notionists/svg?seed=${encodeURIComponent(avatarSeed)}`
    : currentUser?.avatar || ''

  const handleSave = async () => {
    if (!currentUser) return
    setSaving(true)
    try {
      const avatar = avatarSeed
        ? `https://api.dicebear.com/9.x/notionists/svg?seed=${encodeURIComponent(avatarSeed)}`
        : currentUser.avatar

      const res = await fetch(`/api/users/${currentUser.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bio, avatar }),
      })

      if (res.ok) {
        const updatedUser = {
          ...currentUser,
          bio,
          avatar,
        }
        setCurrentUser(updatedUser)
        localStorage.setItem('forum_user', JSON.stringify(updatedUser))
        toast.success('资料已更新')
        onOpenChange(false)
      } else {
        toast.error('更新失败，请重试')
      }
    } catch {
      toast.error('网络错误，请重试')
    } finally {
      setSaving(false)
    }
  }

  if (!currentUser) return null

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center text-lg">编辑资料</DialogTitle>
          <DialogDescription className="text-center text-gray-500 dark:text-gray-400">
            修改你的个人信息
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-5 pt-2">
          {/* Avatar Preview */}
          <div className="flex flex-col items-center gap-3">
            <Avatar className="size-20">
              <AvatarImage src={avatarUrl} alt="Avatar preview" />
              <AvatarFallback className="text-2xl bg-gray-100 dark:bg-gray-800">
                {currentUser.username.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <div className="w-full space-y-1.5">
              <label className="text-xs font-medium text-gray-500 dark:text-gray-400">头像种子</label>
              <Input
                placeholder="输入任意文字生成头像"
                value={avatarSeed}
                onChange={(e) => setAvatarSeed(e.target.value)}
                className="text-sm"
              />
              <p className="text-[11px] text-gray-400 dark:text-gray-500">修改此值会自动生成不同的头像风格</p>
            </div>
          </div>

          {/* Username (read-only) */}
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-gray-500 dark:text-gray-400">用户名</label>
            <Input
              value={currentUser.username}
              disabled
              className="text-sm bg-gray-50 text-gray-500 dark:bg-gray-800 dark:text-gray-400"
            />
            <p className="text-[11px] text-gray-400 dark:text-gray-500">用户名暂不支持修改</p>
          </div>

          {/* Bio */}
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-gray-500 dark:text-gray-400">个人简介</label>
            <Textarea
              placeholder="介绍一下自己吧..."
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              className="text-sm resize-none"
              rows={3}
              maxLength={200}
            />
            <p className="text-[11px] text-gray-400 dark:text-gray-500 text-right">{bio.length}/200</p>
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-2">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1 text-sm"
              disabled={saving}
            >
              取消
            </Button>
            <Button
              onClick={handleSave}
              className="flex-1 bg-gray-900 hover:bg-gray-800 text-sm"
              disabled={saving}
            >
              {saving && <Loader2 className="size-3.5 animate-spin mr-1.5" />}
              保存
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
