'use client'

import { useEffect, useState } from 'react'
import { useForumStore, type Category, type Tag } from '@/store/forum'
import { cn, formatTimeAgo } from '@/components/forum/helpers'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet'
import { ScrollArea } from '@/components/ui/scroll-area'
import { ScrollBar } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { Flame, Hash, Users, Trophy, MessageSquare } from 'lucide-react'
import { motion } from 'framer-motion'
import ForumStats from './ForumStats'

interface ForumUser {
  id: string
  username: string
  avatar: string
  bio: string
  postCount?: number
  commentCount?: number
}

interface HotPost {
  id: string
  title: string
  likeCount: number
  commentCount: number
}

export default function ForumSidebar() {
  const {
    currentPage,
    categories,
    setCategories,
    sidebarOpen,
    setSidebarOpen,
    sidebarCollapsed,
    setSidebarCollapsed,
    navigate,
  } = useForumStore()

  const [tags, setTags] = useState<Tag[]>([])
  const [activeUsers, setActiveUsers] = useState<ForumUser[]>([])
  const [hotPosts, setHotPosts] = useState<HotPost[]>([])
  const [sidebarScrolled, setSidebarScrolled] = useState(false)

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const res = await fetch('/api/categories')
        if (res.ok) {
          const data = await res.json()
          setCategories(data)
        }
      } catch { /* ignore */ }
    }
    const fetchTags = async () => {
      try {
        // Tags come from posts - extract unique ones
        const res = await fetch('/api/posts?limit=50&sort=latest')
        if (res.ok) {
          const data = await res.json()
          const tagMap = new Map<string, Tag>()
          data.posts?.forEach((post: { tags?: Tag[] }) => {
            post.tags?.forEach((tag) => {
              if (!tagMap.has(tag.id)) {
                tagMap.set(tag.id, tag)
              }
            })
          })
          setTags(Array.from(tagMap.values()).slice(0, 12))
        }
      } catch { /* ignore */ }
    }
    const fetchUsers = async () => {
      try {
        const res = await fetch('/api/posts?limit=5&sort=hot')
        if (res.ok) {
          const data = await res.json()
          const userMap = new Map<string, ForumUser>()
          data.posts?.forEach((post: { author: ForumUser }) => {
            if (post.author && !userMap.has(post.author.id)) {
              userMap.set(post.author.id, post.author)
            }
          })
          setActiveUsers(Array.from(userMap.values()).slice(0, 5))
        }
      } catch { /* ignore */ }
    }
    const fetchHotPosts = async () => {
      try {
        const res = await fetch('/api/posts?sort=hot&limit=3')
        if (res.ok) {
          const data = await res.json()
          setHotPosts((data.posts || []).slice(0, 3))
        }
      } catch { /* ignore */ }
    }

    fetchCategories()
    fetchTags()
    fetchUsers()
    fetchHotPosts()
  }, [setCategories])

  // Track sidebar scroll for shadow effect
  useEffect(() => {
    const scrollArea = document.querySelector('[data-sidebar-scroll]')
    if (!scrollArea) return
    const handleScroll = () => {
      setSidebarScrolled(scrollArea.scrollTop > 8)
    }
    scrollArea.addEventListener('scroll', handleScroll, { passive: true })
    return () => scrollArea.removeEventListener('scroll', handleScroll)
  }, [sidebarOpen])

  const activeCategoryId = currentPage.name === 'home' ? currentPage.categoryId : undefined

  const sidebarContent = (
    <div className={cn('flex flex-col h-full', sidebarScrolled && 'shadow-[inset_0_1px_0_rgba(0,0,0,0.05)] dark:shadow-[inset_0_1px_0_rgba(255,255,255,0.05)]')}>
      {/* Subtle gradient top background */}
      <div className="absolute top-0 left-0 right-0 h-24 bg-gradient-to-b from-gray-100/60 to-transparent dark:from-gray-800/40 dark:to-transparent pointer-events-none rounded-t-lg z-0" />
      <ScrollArea className="h-full" data-sidebar-scroll>
        <div className="p-4 space-y-6 relative">
          {/* Categories */}
          <div>
            <h3 className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <Flame className="size-3.5" />
              分类板块
            </h3>
            <div className="space-y-0.5">
              <button
                onClick={() => {
                  navigate({ name: 'home' })
                  setSidebarOpen(false)
                }}
                className={cn(
                  'w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all duration-200',
                  !activeCategoryId && currentPage.name === 'home'
                    ? 'bg-gray-900 text-white font-medium dark:bg-gray-100 dark:text-gray-900'
                    : 'text-gray-600 hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-800 hover:text-gray-900'
                )}
              >
                <span className="text-base">🏠</span>
                <span className="flex-1 text-left">全部</span>
                <span className="text-xs text-gray-400 dark:text-gray-500">
                  {categories.reduce((sum, c) => sum + (c.postCount || 0), 0)}
                </span>
              </button>
              {categories.map((cat, idx) => (
                <motion.button
                  key={cat.id}
                  whileTap={{ scale: 0.98 }}
                  whileHover={{ x: 2 }}
                  transition={{ type: 'spring', stiffness: 400, damping: 25 }}
                  onClick={() => {
                    navigate({ name: 'home', categoryId: cat.id })
                    setSidebarOpen(false)
                  }}
                  className={cn(
                    'w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all duration-200',
                    activeCategoryId === cat.id
                      ? 'bg-gray-900 text-white font-medium dark:bg-gray-100 dark:text-gray-900'
                      : 'text-gray-600 hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-800 hover:text-gray-900'
                  )}
                >
                  <span className="text-base">{cat.icon}</span>
                  <span className="flex-1 text-left">{cat.name}</span>
                  <div className="flex items-center gap-1.5">
                    {idx === 0 && categories.length > 1 && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-gray-100 text-gray-400 dark:bg-gray-800 dark:text-gray-500 font-medium">
                        新鲜
                      </span>
                    )}
                    <span className={cn(
                      'text-[10px] min-w-[20px] text-center px-1.5 py-0.5 rounded-full font-medium',
                      activeCategoryId === cat.id
                        ? 'bg-white/20 dark:bg-gray-900/20 text-white dark:text-gray-900'
                        : 'bg-gray-100 text-gray-400 dark:bg-gray-800 dark:text-gray-500'
                    )}>{cat.postCount || 0}</span>
                  </div>
                </motion.button>
              ))}
            </div>
          </div>

          <Separator />

          {/* Hot Tags */}
          {tags.length > 0 && (
            <div>
              <h3 className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                <Hash className="size-3.5" />
                热门标签
              </h3>
              <div className="flex flex-wrap gap-2">
                {tags.map((tag) => (
                  <Badge
                    key={tag.id}
                    variant="outline"
                    className="cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-700 transition-all duration-200 text-xs font-medium px-2.5 py-1 rounded-full border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200"
                    onClick={() => {
                      navigate({ name: 'home', tag: tag.name })
                      setSidebarOpen(false)
                    }}
                  >
                    #{tag.name}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          <Separator />

          {/* Daily Picks - 每日精选 */}
          {hotPosts.length > 0 && (
            <div>
              <h3 className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                <Trophy className="size-3.5" />
                每日精选
              </h3>
              <div className="space-y-1.5">
                {hotPosts.map((post, idx) => (
                  <button
                    key={post.id}
                    onClick={() => {
                      navigate({ name: 'post', postId: post.id })
                      setSidebarOpen(false)
                    }}
                    className="w-full flex items-start gap-2.5 px-2.5 py-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-all duration-200 text-left group"
                  >
                    <span className={cn(
                      'flex-shrink-0 size-5 rounded-md flex items-center justify-center text-[10px] font-bold mt-0.5',
                      idx === 0 && 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-400',
                      idx === 1 && 'bg-gray-100 text-gray-500 dark:bg-gray-700 dark:text-gray-300',
                      idx === 2 && 'bg-orange-50 text-orange-600 dark:bg-orange-900/30 dark:text-orange-400'
                    )}>
                      {idx + 1}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-gray-700 dark:text-gray-300 line-clamp-2 group-hover:text-gray-900 dark:group-hover:text-gray-100 transition-colors leading-relaxed">
                        {post.title}
                      </p>
                      <div className="flex items-center gap-2 mt-1 text-[10px] text-gray-400 dark:text-gray-500">
                        <span className="flex items-center gap-0.5">
                          <MessageSquare className="size-2.5" />
                          {post.commentCount}
                        </span>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          <Separator />

          {/* Active Users */}
          {activeUsers.length > 0 && (
            <div>
              <h3 className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                <Users className="size-3.5" />
                活跃用户
              </h3>
              <div className="space-y-2">
                {activeUsers.map((user) => (
                  <button
                    key={user.id}
                    onClick={() => {
                      navigate({ name: 'user', userId: user.id })
                      setSidebarOpen(false)
                    }}
                    className="flex items-center gap-2.5 w-full px-2 py-1.5 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-all duration-200 group"
                  >
                    <div className="relative">
                      <Avatar className="size-7">
                        <AvatarImage src={user.avatar} alt={user.username} />
                        <AvatarFallback className="text-xs bg-gray-100 dark:bg-gray-800">
                          {user.username.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <span className="absolute -bottom-0.5 -right-0.5 size-2.5 rounded-full bg-emerald-400 border-2 border-white dark:border-gray-950" title="在线" />
                    </div>
                    <span className="text-sm text-gray-700 dark:text-gray-300 truncate group-hover:text-gray-900 dark:group-hover:text-gray-100 transition-colors">{user.username}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          <Separator />

          <ForumStats />
        </div>
        {/* Custom thin scrollbar - visible on hover */}
        <style jsx>{`
          [data-sidebar-scroll] > div > div::-webkit-scrollbar {
            width: 4px;
          }
          [data-sidebar-scroll] > div > div::-webkit-scrollbar-track {
            background: transparent;
          }
          [data-sidebar-scroll] > div > div::-webkit-scrollbar-thumb {
            background-color: rgba(156, 163, 175, 0);
            border-radius: 9999px;
            transition: background-color 0.2s ease;
          }
          [data-sidebar-scroll]:hover > div > div::-webkit-scrollbar-thumb {
            background-color: rgba(156, 163, 175, 0.4);
          }
          .dark [data-sidebar-scroll]:hover > div > div::-webkit-scrollbar-thumb {
            background-color: rgba(75, 85, 99, 0.5);
          }
          [data-sidebar-scroll] > div > div {
            scrollbar-width: thin;
            scrollbar-color: transparent transparent;
            transition: scrollbar-color 0.2s ease;
          }
          [data-sidebar-scroll]:hover > div > div {
            scrollbar-color: rgba(156, 163, 175, 0.4) transparent;
          }
          .dark [data-sidebar-scroll]:hover > div > div {
            scrollbar-color: rgba(75, 85, 99, 0.5) transparent;
          }
        `}</style>
      </ScrollArea>
    </div>
  )

  return (
    <>
      {/* Desktop Sidebar - collapsible */}
      <aside
        className={cn(
          'hidden md:block shrink-0 sticky top-14 h-[calc(100vh-3.5rem)] overflow-hidden transition-all duration-300 ease-in-out',
          sidebarCollapsed
            ? 'w-0 opacity-0 pointer-events-none'
            : 'w-56 opacity-100'
        )}
      >
        <div className={cn(
          'h-full py-4 transition-opacity duration-200',
          sidebarCollapsed ? 'opacity-0' : 'opacity-100'
        )}>
          {sidebarContent}
        </div>
      </aside>

      {/* Mobile Sheet */}
      <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <SheetContent side="left" className="w-72 p-0">
          <SheetHeader className="p-4 pb-0">
            <SheetTitle className="flex items-center gap-2">
              <span className="size-7 rounded-lg bg-gray-900 dark:bg-gray-100 flex items-center justify-center">
                <Flame className="size-3.5 text-white dark:text-gray-900" />
              </span>
              明天后
            </SheetTitle>
            <SheetDescription className="sr-only">导航菜单</SheetDescription>
          </SheetHeader>
          <div className="h-[calc(100vh-5rem)] overflow-hidden">
            {sidebarContent}
          </div>
        </SheetContent>
      </Sheet>
    </>
  )
}
