'use client'

import { useForumStore } from '@/store/forum'
import { motion } from 'framer-motion'
import {
  ArrowLeft,
  Heart,
  Users,
  Shield,
  Mail,
  MessageCircle,
  Clock,
  Globe,
  Sparkles,
  BookOpen,
  AlertTriangle,
  Scale,
  FileText,
  ChevronRight,
} from 'lucide-react'

export default function LegalPages() {
  const { currentPage, navigate } = useForumStore()
  const section = currentPage.name === 'legal' ? currentPage.section : 'about'

  return (
    <motion.div
      initial={{ opacity: 0, x: 10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.3 }}
      className="flex-1 max-w-3xl mx-auto w-full"
    >
      {/* Back button */}
      <div className="px-4 py-3">
        <button
          onClick={() => navigate({ name: 'home' })}
          className="flex items-center gap-1.5 text-sm text-gray-400 hover:text-gray-700 dark:text-gray-500 dark:hover:text-gray-300 transition-colors"
        >
          <ArrowLeft className="size-4" />
          返回列表
        </button>
      </div>

      {/* Tab navigation */}
      <div className="px-4 border-b border-gray-100 dark:border-gray-800 mb-6">
        <div className="flex gap-1">
          {([
            { key: 'about', label: '关于我们', icon: Heart },
            { key: 'terms', label: '使用条款', icon: BookOpen },
            { key: 'contact', label: '联系方式', icon: Mail },
          ] as const).map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => navigate({ name: 'legal', section: key })}
              className={`flex items-center gap-1.5 px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                section === key
                  ? 'border-gray-900 text-gray-900 dark:border-gray-100 dark:text-gray-100'
                  : 'border-transparent text-gray-400 hover:text-gray-600 dark:hover:text-gray-300'
              }`}
            >
              <Icon className="size-4" />
              {label}
            </button>
          ))}
        </div>
      </div>

      <div className="px-4 pb-8">
        {section === 'about' && <AboutSection />}
        {section === 'terms' && <TermsSection />}
        {section === 'contact' && <ContactSection />}
      </div>
    </motion.div>
  )
}

/* ========== 关于我们 ========== */
function AboutSection() {
  return (
    <div className="space-y-8">
      {/* Hero */}
      <div className="text-center py-8">
        <div className="inline-flex items-center justify-center size-20 rounded-2xl bg-gradient-to-br from-gray-900 to-gray-700 dark:from-gray-100 dark:to-gray-300 mb-5">
          <Sparkles className="size-10 text-white dark:text-gray-900" />
        </div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-2">明天后</h1>
        <p className="text-gray-500 dark:text-gray-400 text-sm">以黑白之名，书写明天</p>
      </div>

      {/* Introduction */}
      <SectionBlock title="我们的故事">
        <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed">
          「明天后」诞生于一个简单的想法——在这个喧嚣的互联网世界里，我们需要一个安静、纯粹的角落来分享思想、交流知识和结交朋友。
        </p>
        <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed mt-3">
          我们选择黑白作为社区的底色，不是因为我们缺乏色彩，而是因为我们相信：真正有价值的内容，不需要华丽的包装。在简洁的黑白之间，每一个文字都能被认真对待，每一个声音都值得被倾听。
        </p>
        <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed mt-3">
          社区的名字「明天后」寓意着我们对未来的思考——不沉溺于过去，不焦虑于当下，而是以一种从容的姿态，去探索明天之后的世界。
        </p>
      </SectionBlock>

      {/* Mission */}
      <SectionBlock title="我们的使命">
        <div className="grid sm:grid-cols-3 gap-4 mt-2">
          <MissionCard
            icon={<MessageCircle className="size-5" />}
            title="真实表达"
            desc="鼓励用户真实、坦诚地分享自己的观点和经历，营造一个安全、包容的交流环境。"
          />
          <MissionCard
            icon={<Users className="size-5" />}
            title="社区共建"
            desc="社区由每一位成员共同建设，我们尊重每一位用户的贡献，让每个人都感受到归属感。"
          />
          <MissionCard
            icon={<Globe className="size-5" />}
            title="开放共享"
            desc="促进知识的传播和经验的分享，让有价值的信息能够惠及更多需要帮助的人。"
          />
        </div>
      </SectionBlock>

      {/* Values */}
      <SectionBlock title="社区价值观">
        <ul className="space-y-3 mt-2">
          <ValueItem title="尊重" desc="尊重每一位社区成员，不论其身份、背景或观点。" />
          <ValueItem title="友善" desc="以友善的态度进行交流，避免攻击性语言和人身攻击。" />
          <ValueItem title="真实" desc="分享真实的内容和观点，不传播虚假信息或进行误导。" />
          <ValueItem title="质量" desc="注重内容质量，鼓励深入思考和有价值的讨论。" />
          <ValueItem title="协作" desc="社区成员之间互相帮助，共同营造积极向上的氛围。" />
        </ul>
      </SectionBlock>

      {/* Tech */}
      <SectionBlock title="技术架构">
        <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed mt-1">
          「明天后」基于以下现代 Web 技术构建：
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
          {['Next.js 16', 'TypeScript', 'Tailwind CSS', 'Prisma ORM'].map((tech) => (
            <div
              key={tech}
              className="px-3 py-2 rounded-lg bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700 text-center"
            >
              <span className="text-xs font-medium text-gray-700 dark:text-gray-300">{tech}</span>
            </div>
          ))}
        </div>
      </SectionBlock>

      {/* Thanks */}
      <div className="text-center py-6">
        <p className="text-sm text-gray-400 dark:text-gray-500">
          感谢每一位「明天后」的社区成员 💫
        </p>
        <p className="text-xs text-gray-300 dark:text-gray-600 mt-1">
          正是因为有你们，这个社区才变得更好
        </p>
      </div>
    </div>
  )
}

/* ========== 使用条款 ========== */
function TermsSection() {
  return (
    <div className="space-y-6">
      <div className="text-center py-6">
        <div className="inline-flex items-center justify-center size-16 rounded-2xl bg-gray-100 dark:bg-gray-800 mb-4">
          <Scale className="size-8 text-gray-600 dark:text-gray-400" />
        </div>
        <h1 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-1">使用条款</h1>
        <p className="text-xs text-gray-400 dark:text-gray-500">最后更新：2025 年 1 月</p>
      </div>

      {/* Section 1 */}
      <TermsBlock
        number="1"
        title="服务条款的接受"
        content={
          <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed">
            注册和使用「明天后」社区即表示您同意遵守本使用条款。如果您不同意本条款的任何内容，请停止使用本服务。我们保留随时修改本条款的权利，修改后的条款将在社区内公告后生效。继续使用本服务即视为接受修改后的条款。
          </p>
        }
      />

      {/* Section 2 */}
      <TermsBlock
        number="2"
        title="用户账户"
        content={
          <ul className="space-y-2">
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              用户需使用合法的用户名注册账户，用户名不得包含违法、淫秽、歧视性内容。
            </li>
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              每位用户仅可注册一个账户，禁止注册多个账户或冒充他人身份。
            </li>
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              用户有责任妥善保管自己的账户信息安全，对账户下的所有行为负责。
            </li>
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              如发现账户被他人冒用或存在安全隐患，请立即联系管理员。
            </li>
          </ul>
        }
      />

      {/* Section 3 */}
      <TermsBlock
        number="3"
        title="内容规范"
        content={
          <div className="space-y-3">
            <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed">
              用户在社区内发布的内容（包括但不限于帖子、评论、图片）须遵守以下规范：
            </p>
            <div className="grid sm:grid-cols-2 gap-3">
              <RuleCard type="prohibit" items={[
                '发布违法、色情、暴力内容',
                '人身攻击或骚扰他人',
                '传播虚假信息或谣言',
                '发布广告或垃圾信息',
                '泄露他人隐私信息',
                '侵犯他人知识产权',
              ]} />
              <RuleCard type="encourage" items={[
                '分享有价值的知识和经验',
                '友善地进行讨论和交流',
                '尊重不同的观点和意见',
                '帮助和解答其他用户的问题',
                '积极维护社区氛围',
                '提供真实原创的内容',
              ]} />
            </div>
          </div>
        }
      />

      {/* Section 4 */}
      <TermsBlock
        number="4"
        title="积分与等级制度"
        content={
          <ul className="space-y-2">
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              社区实行积分制度，通过发帖、获赞、获评、获收藏获取积分。
            </li>
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              积分用于提升用户等级，等级越高代表用户对社区的贡献越大。
            </li>
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              禁止通过刷分、互赞等违规方式获取积分，违者将被扣除积分或封禁账户。
            </li>
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              官方账号（「明天过后」）不参与积分排名，仅供社区管理和发布官方公告使用。
            </li>
          </ul>
        }
      />

      {/* Section 5 */}
      <TermsBlock
        number="5"
        title="知识产权"
        content={
          <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed">
            用户在社区内发布的原创内容，其知识产权归原作者所有。用户授权「明天后」社区在合理范围内使用、展示和传播这些内容。转载他人内容时，请注明出处并尊重原作者的权利。社区不对用户发布的内容承担版权侵权责任，如有侵权争议，请联系管理员处理。
          </p>
        }
      />

      {/* Section 6 */}
      <TermsBlock
        number="6"
        title="社区管理"
        content={
          <ul className="space-y-2">
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              管理团队有权对违反社区规则的内容进行编辑、删除或隐藏。
            </li>
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              对严重违规的用户，管理团队有权给予警告、禁言或封禁账户的处罚。
            </li>
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              管理团队将公正、透明地执行社区规则，用户可通过联系方式对管理决策提出申诉。
            </li>
          </ul>
        }
      />

      {/* Section 7 */}
      <TermsBlock
        number="7"
        title="免责声明"
        content={
          <ul className="space-y-2">
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              社区内用户发布的内容仅代表作者个人观点，不代表平台立场。
            </li>
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              「明天后」不对用户因使用本服务而遭受的任何损失承担法律责任。
            </li>
            <li className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed flex gap-2">
              <ChevronRight className="size-3.5 mt-1 shrink-0 text-gray-400" />
              因不可抗力导致的服务中断或数据丢失，「明天后」不承担赔偿责任。
            </li>
          </ul>
        }
      />

      {/* Section 8 */}
      <TermsBlock
        number="8"
        title="隐私保护"
        content={
          <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed">
            「明天后」重视用户隐私保护。我们仅收集提供服务所必需的最少信息，不会将用户个人信息出售或分享给第三方。用户头像、用户名等公开信息将在社区内展示。如需了解更多详情，请联系我们的管理团队。
          </p>
        }
      />

      <div className="text-center py-4">
        <p className="text-xs text-gray-400 dark:text-gray-500">
          如果您对本使用条款有任何疑问，请通过 <a href="mailto:zl199518@outlook.com" className="text-gray-500 dark:text-gray-400 underline underline-offset-2">zl199518@outlook.com</a> 联系我们
        </p>
      </div>
    </div>
  )
}

/* ========== 联系方式 ========== */
function ContactSection() {
  return (
    <div className="space-y-6">
      <div className="text-center py-6">
        <div className="inline-flex items-center justify-center size-16 rounded-2xl bg-gray-100 dark:bg-gray-800 mb-4">
          <Mail className="size-8 text-gray-600 dark:text-gray-400" />
        </div>
        <h1 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-1">联系我们</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400">我们随时欢迎您的反馈和建议</p>
      </div>

      {/* Contact Cards */}
      <div className="grid sm:grid-cols-2 gap-4">
        <ContactCard
          icon={<Mail className="size-5" />}
          title="电子邮箱（推荐）"
          value="zl199518@outlook.com"
          link="mailto:zl199518@outlook.com"
          desc="首选联系方式，通常在 24 小时内回复"
        />
        <ContactCard
          icon={<Mail className="size-5" />}
          title="备用邮箱"
          value="guanqpcx@outlook.com"
          link="mailto:guanqpcx@outlook.com"
          desc="备选联系方式，响应可能较慢"
        />
        <ContactCard
          icon={<MessageCircle className="size-5" />}
          title="社区反馈"
          value="发帖 @明天过后"
          desc="在社区内发帖并 @ 官方账号，我们会及时关注"
        />
        <ContactCard
          icon={<Clock className="size-5" />}
          title="响应时间"
          value="1-2 个工作日"
          desc="工作日优先处理，紧急问题我们会尽快响应"
        />
        <ContactCard
          icon={<Shield className="size-5" />}
          title="举报与投诉"
          value="邮箱或社区内反馈"
          desc="涉及违规内容请第一时间联系我们处理"
        />
      </div>

      {/* FAQ */}
      <SectionBlock title="常见问题">
        <div className="space-y-4 mt-2">
          <FaqItem
            question="如何举报违规内容？"
            answer="您可以通过邮箱 zl199518@outlook.com 向我们举报，或在社区内直接 @ 官方账号「明天过后」。请在举报时提供相关帖子的链接和具体的违规说明，我们将尽快核实处理。"
          />
          <FaqItem
            question="如何申请成为管理员？"
            answer="目前社区暂未开放管理员申请通道。我们会根据用户的活跃度、贡献度和社区影响力，不定期邀请优秀用户参与社区管理。持续为社区做出贡献是最重要的前提。"
          />
          <FaqItem
            question="忘记了如何登录怎么办？"
            answer="「明天后」采用用户名 + 头像的轻量登录方式，没有密码。您只需输入之前注册的用户名即可自动登录。如果遇到问题，请联系管理员协助处理。"
          />
          <FaqItem
            question="可以迁移或导出我的数据吗？"
            answer="目前暂不支持自主导出数据。如您有个人数据迁移需求，请通过邮箱联系我们，我们会在合理范围内协助您处理。"
          />
          <FaqItem
            question="如何删除我的账户？"
            answer="如果您希望注销账户，请通过邮箱 zl199518@outlook.com（推荐）或 guanqpcx@outlook.com 向我们提出申请，并在邮件中说明您的用户名。我们会在核实身份后为您办理账户注销手续。"
          />
        </div>
      </SectionBlock>

      {/* Message hint */}
      <div className="rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700 p-5 text-center">
        <p className="text-sm text-gray-600 dark:text-gray-300 font-medium mb-1">还没有找到答案？</p>
        <p className="text-xs text-gray-400 dark:text-gray-500 mb-4">
          欢迎通过邮件联系我们，我们很乐意为您提供帮助
        </p>
        <a
          href="mailto:zl199518@outlook.com"
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900 rounded-full text-sm font-medium hover:bg-gray-800 dark:hover:bg-gray-200 transition-colors"
        >
          <Mail className="size-4" />
          发送邮件
        </a>
      </div>
    </div>
  )
}

/* ========== Shared Components ========== */

function SectionBlock({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h2 className="text-base font-semibold text-gray-900 dark:text-gray-100 mb-3 flex items-center gap-2">
        <span className="size-1 rounded-full bg-gray-900 dark:bg-gray-100" />
        {title}
      </h2>
      {children}
    </div>
  )
}

function MissionCard({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className="p-4 rounded-xl bg-gray-50 dark:bg-gray-800/80 border border-gray-100 dark:border-gray-700 text-center">
      <div className="inline-flex items-center justify-center size-10 rounded-xl bg-white dark:bg-gray-700 border border-gray-100 dark:border-gray-600 mb-3 text-gray-600 dark:text-gray-300">
        {icon}
      </div>
      <h3 className="text-sm font-semibold text-gray-800 dark:text-gray-200 mb-1">{title}</h3>
      <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">{desc}</p>
    </div>
  )
}

function ValueItem({ title, desc }: { title: string; desc: string }) {
  return (
    <li className="flex items-start gap-2.5">
      <span className="mt-1 size-1.5 rounded-full bg-gray-900 dark:bg-gray-100 shrink-0" />
      <div>
        <span className="text-sm font-medium text-gray-800 dark:text-gray-200">{title} — </span>
        <span className="text-sm text-gray-500 dark:text-gray-400">{desc}</span>
      </div>
    </li>
  )
}

function TermsBlock({ number, title, content }: { number: string; title: string; content: React.ReactNode }) {
  return (
    <div className="rounded-xl bg-white dark:bg-gray-800/50 border border-gray-100 dark:border-gray-800 p-5">
      <div className="flex items-center gap-2 mb-3">
        <span className="inline-flex items-center justify-center size-6 rounded-md bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900 text-xs font-bold">
          {number}
        </span>
        <h2 className="text-sm font-semibold text-gray-900 dark:text-gray-100">{title}</h2>
      </div>
      {content}
    </div>
  )
}

function RuleCard({ type, items }: { type: 'prohibit' | 'encourage'; items: string[] }) {
  const isProhibit = type === 'prohibit'
  return (
    <div className={`rounded-lg border p-3 ${isProhibit ? 'border-red-100 dark:border-red-900/30 bg-red-50/50 dark:bg-red-950/20' : 'border-green-100 dark:border-green-900/30 bg-green-50/50 dark:bg-green-950/20'}`}>
      <div className={`flex items-center gap-1.5 mb-2 text-xs font-semibold ${isProhibit ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>
        <AlertTriangle className="size-3" />
        {isProhibit ? '禁止行为' : '鼓励行为'}
      </div>
      <ul className="space-y-1.5">
        {items.map((item, i) => (
          <li key={i} className={`text-xs flex items-start gap-1.5 ${isProhibit ? 'text-red-700/80 dark:text-red-300/80' : 'text-green-700/80 dark:text-green-300/80'}`}>
            <span className="mt-1 size-1 rounded-full bg-current opacity-50 shrink-0" />
            {item}
          </li>
        ))}
      </ul>
    </div>
  )
}

function ContactCard({ icon, title, value, link, desc }: { icon: React.ReactNode; title: string; value: string; link?: string; desc: string }) {
  const content = (
    <div className="p-4 rounded-xl bg-gray-50 dark:bg-gray-800/80 border border-gray-100 dark:border-gray-700 hover:border-gray-200 dark:hover:border-gray-600 transition-colors">
      <div className="flex items-start gap-3">
        <div className="shrink-0 size-10 rounded-xl bg-white dark:bg-gray-700 border border-gray-100 dark:border-gray-600 flex items-center justify-center text-gray-500 dark:text-gray-400">
          {icon}
        </div>
        <div className="min-w-0">
          <p className="text-xs text-gray-400 dark:text-gray-500 mb-0.5">{title}</p>
          <p className="text-sm font-medium text-gray-900 dark:text-gray-100 break-all">{value}</p>
          <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">{desc}</p>
        </div>
      </div>
    </div>
  )

  if (link) {
    return <a href={link} className="block">{content}</a>
  }
  return content
}

function FaqItem({ question, answer }: { question: string; answer: string }) {
  return (
    <div className="rounded-lg bg-gray-50 dark:bg-gray-800/50 border border-gray-100 dark:border-gray-800 p-4">
      <h3 className="text-sm font-medium text-gray-800 dark:text-gray-200 mb-2 flex items-start gap-2">
        <FileText className="size-4 shrink-0 mt-0.5 text-gray-400" />
        {question}
      </h3>
      <p className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed pl-6">{answer}</p>
    </div>
  )
}
