'use client'

import { useReducer, useEffect, useState, useCallback } from 'react'
import { useForumStore, type Post, type Category } from '@/store/forum'
import PostCard from './PostCard'
import { Skeleton } from '@/components/ui/skeleton'
import { Search, Inbox, X, ArrowUpDown } from 'lucide-react'
import { motion } from 'framer-motion'

interface SearchState {
  posts: Post[]
  loading: boolean
  total: number
  page: number
  hasMore: boolean
}

type SearchAction =
  | { type: 'SET_LOADING' }
  | { type: 'SET_RESULTS'; posts: Post[]; total: number; hasMore: boolean }
  | { type: 'SET_PAGE'; page: number }

function searchReducer(state: SearchState, action: SearchAction): SearchState {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, loading: true }
    case 'SET_RESULTS':
      return { ...state, posts: action.posts, total: action.total, hasMore: action.hasMore, loading: false }
    case 'SET_PAGE':
      return { ...state, page: action.page }
    default:
      return state
  }
}

export default function SearchResults() {
  const { currentPage } = useForumStore()
  const [state, dispatch] = useReducer(searchReducer, {
    posts: [],
    loading: true,
    total: 0,
    page: 1,
    hasMore: false,
  })

  const [categories, setCategories] = useState<Category[]>([])
  const [sort, setSort] = useState<'latest' | 'hot'>('latest')
  const [activeCategoryId, setActiveCategoryId] = useState<string | undefined>(undefined)
  const [activeAuthorId, setActiveAuthorId] = useState<string | undefined>(undefined)

  const query = currentPage.name === 'search' ? currentPage.query : ''
  const storeCategoryId = currentPage.name === 'search' ? currentPage.categoryId : undefined
  const storeAuthorId = currentPage.name === 'search' ? currentPage.authorId : undefined

  // Sync local filter state from store on new navigation
  const [prevStoreKey, setPrevStoreKey] = useReducer(
    (_prev: string, next: string) => next,
    `${query}-${storeCategoryId}-${storeAuthorId}`
  )
  const storeFilterKey = `${query}-${storeCategoryId}-${storeAuthorId}`
  if (prevStoreKey !== storeFilterKey) {
    setPrevStoreKey(storeFilterKey)
    setActiveCategoryId(storeCategoryId)
    setActiveAuthorId(storeAuthorId)
    setSort('latest')
    dispatch({ type: 'SET_PAGE', page: 1 })
  }

  // Fetch categories on mount
  useEffect(() => {
    ;(async () => {
      try {
        const res = await fetch('/api/categories')
        if (res.ok) {
          const data = await res.json()
          setCategories(data)
        }
      } catch {
        // ignore
      }
    })()
  }, [])

  // Track query/filter changes to reset page
  const [prevQuery, setPrevQuery] = useReducer(
    (_prev: string, next: string) => next,
    query
  )
  if (prevQuery !== query) {
    setPrevQuery(query)
    dispatch({ type: 'SET_PAGE', page: 1 })
  }

  const [prevFilters, setPrevFilters] = useReducer(
    (_prev: string, next: string) => next,
    ''
  )
  const filterKey = `${activeCategoryId}-${activeAuthorId}-${sort}`
  if (prevFilters !== filterKey) {
    setPrevFilters(filterKey)
    dispatch({ type: 'SET_PAGE', page: 1 })
  }

  useEffect(() => {
    if (!query) return
    let cancelled = false
    dispatch({ type: 'SET_LOADING' })
    ;(async () => {
      try {
        const params = new URLSearchParams({
          q: query,
          page: String(state.page),
          limit: '20',
          sort,
        })
        if (activeCategoryId) params.set('categoryId', activeCategoryId)
        if (activeAuthorId) params.set('authorId', activeAuthorId)
        const res = await fetch(`/api/search?${params.toString()}`)
        if (!cancelled && res.ok) {
          const data = await res.json()
          dispatch({
            type: 'SET_RESULTS',
            posts: data.posts || [],
            total: data.total || 0,
            hasMore: data.page < data.totalPages,
          })
        }
      } catch {
        // ignore
      }
      if (cancelled) dispatch({ type: 'SET_RESULTS', posts: [], total: 0, hasMore: false })
    })()
    return () => {
      cancelled = true
    }
  }, [query, state.page, activeCategoryId, activeAuthorId, sort])

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [query])

  const handleCategoryClick = useCallback((catId: string) => {
    setActiveCategoryId((prev) => (prev === catId ? undefined : catId))
  }, [])

  const handleClearFilters = useCallback(() => {
    setActiveCategoryId(undefined)
    setActiveAuthorId(undefined)
    setSort('latest')
  }, [])

  const hasFilters = activeCategoryId || activeAuthorId || sort !== 'latest'

  return (
    <motion.div
      initial={{ opacity: 0, x: 10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.3 }}
      className="flex-1 max-w-3xl mx-auto w-full"
    >
      {/* Header */}
      <div className="px-4 py-5 border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center gap-2 text-gray-400 mb-1">
          <Search className="size-4" />
          <span className="text-sm">搜索结果</span>
        </div>
        <h1 className="text-lg font-bold text-gray-900 dark:text-gray-100">
          &ldquo;{query}&rdquo;
        </h1>
        {!state.loading && (
          <p className="text-sm text-gray-400 mt-1">
            找到 {state.total} 个相关帖子
          </p>
        )}
      </div>

      {/* Filter Bar */}
      <div className="px-4 py-3 border-b border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-900/50">
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-none">
          {/* Category pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none flex-1 min-w-0">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => handleCategoryClick(cat.id)}
                className={`shrink-0 rounded-full px-3 py-1 text-xs font-medium transition-colors cursor-pointer ${
                  activeCategoryId === cat.id
                    ? 'bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900'
                    : 'bg-gray-100 text-gray-500 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700'
                }`}
              >
                {cat.name}
              </button>
            ))}

            {/* Author chip */}
            {activeAuthorId && (
              <button
                onClick={() => setActiveAuthorId(undefined)}
                className="shrink-0 rounded-full px-3 py-1 text-xs font-medium bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900 flex items-center gap-1 transition-colors cursor-pointer"
              >
                仅看该作者
                <X className="size-3" />
              </button>
            )}

            {/* Clear filters */}
            {hasFilters && (
              <button
                onClick={handleClearFilters}
                className="shrink-0 rounded-full px-3 py-1 text-xs font-medium text-gray-400 hover:text-gray-600 hover:bg-gray-200/60 dark:hover:text-gray-300 dark:hover:bg-gray-700/60 flex items-center gap-1 transition-colors cursor-pointer"
              >
                <X className="size-3" />
                清除筛选
              </button>
            )}
          </div>

          {/* Sort tabs */}
          <div className="flex items-center gap-0.5 shrink-0 border-l border-gray-200 dark:border-gray-700 pl-2 ml-1">
            <button
              onClick={() => setSort('latest')}
              className={`shrink-0 rounded-md px-2.5 py-1 text-xs font-medium transition-colors cursor-pointer ${
                sort === 'latest'
                  ? 'bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900'
                  : 'text-gray-500 hover:bg-gray-200/60 dark:text-gray-400 dark:hover:bg-gray-700/60'
              }`}
            >
              最新
            </button>
            <button
              onClick={() => setSort('hot')}
              className={`shrink-0 rounded-md px-2.5 py-1 text-xs font-medium transition-colors flex items-center gap-1 cursor-pointer ${
                sort === 'hot'
                  ? 'bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900'
                  : 'text-gray-500 hover:bg-gray-200/60 dark:text-gray-400 dark:hover:bg-gray-700/60'
              }`}
            >
              <ArrowUpDown className="size-3" />
              最热
            </button>
          </div>
        </div>
      </div>

      {/* Results */}
      <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-lg mt-3 overflow-hidden">
        {state.loading ? (
          <div className="divide-y divide-gray-50 dark:divide-gray-800">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="px-4 py-4 flex gap-3">
                <Skeleton className="size-10 rounded-full shrink-0" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-3 w-full" />
                  <Skeleton className="h-3 w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : state.posts.length === 0 ? (
          <div className="py-16 flex flex-col items-center justify-center text-gray-400">
            <Inbox className="size-12 mb-3 text-gray-300 dark:text-gray-600" />
            <p className="text-sm font-medium text-gray-500 dark:text-gray-400">没有找到相关帖子</p>
            <p className="text-xs mt-1">试试其他关键词或筛选条件吧</p>
          </div>
        ) : (
          <>
            {state.posts.map((post, index) => (
              <PostCard key={post.id} post={post} index={index} />
            ))}
            {state.hasMore && (
              <div className="px-4 py-4 text-center">
                <button
                  onClick={() => dispatch({ type: 'SET_PAGE', page: state.page + 1 })}
                  className="text-sm text-gray-500 hover:text-gray-700 transition-colors px-4 py-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 dark:hover:text-gray-300 cursor-pointer"
                >
                  加载更多
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </motion.div>
  )
}
