'use client'

import { useState, useCallback, useRef, useEffect } from 'react'
import { Smile, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'

// Common emoji sets
const EMOJI_CATEGORIES = [
  {
    name: '常用',
    emojis: ['👍', '👎', '❤️', '😂', '😮', '😢', '🔥', '⭐', '🎉', '💯', '✅', '❌', '🙏', '💪', '👀', '🤔', '😅', '🥰', '😭', '🤝', '👏', '🫡', '💎', '🚀'],
  },
  {
    name: '表情',
    emojis: ['😀', '😃', '😄', '😁', '😆', '😅', '🤣', '😂', '🙂', '🙃', '😉', '😊', '😇', '🥰', '😍', '🤩', '😘', '😋', '😛', '😜', '🤪', '😝', '🤑', '🤗'],
  },
  {
    name: '手势',
    emojis: ['👋', '🤚', '✋', '🖖', '👌', '🤌', '🤏', '✌️', '🤞', '🫰', '🤟', '🤘', '🤙', '👈', '👉', '👆', '🖕', '👇', '☝️', '🫵', '👍', '👎', '✊', '👊'],
  },
  {
    name: '动物',
    emojis: ['🐱', '🐶', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼', '🐨', '🐯', '🦁', '🐮', '🐷', '🐸', '🐵', '🐔', '🐧', '🐦', '🦅', '🦆', '🦉', '🦇', '🐺', '🐗'],
  },
  {
    name: '自然',
    emojis: ['🌸', '🌺', '🌻', '🌹', '🌷', '🌼', '🍀', '🌿', '☘️', '🍁', '🍂', '🍃', '🌍', '🌙', '⭐', '🌟', '✨', '⚡', '🔥', '💧', '🌈', '☀️', '🌤️', '❄️'],
  },
]

interface EmojiPickerProps {
  onSelect: (emoji: string) => void
  children?: React.ReactNode
}

export function EmojiPicker({ onSelect }: EmojiPickerProps) {
  const [open, setOpen] = useState(false)
  const [search, setSearch] = useState('')
  const inputRef = useRef<HTMLInputElement>(null)
  const [activeCategory, setActiveCategory] = useState(0)

  const allEmojis = EMOJI_CATEGORIES.flatMap(c => c.emojis)
  const filteredEmojis = search
    ? allEmojis.filter(e => e.includes(search))
    : []

  useEffect(() => {
    if (open && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 100)
    }
  }, [open])

  const handleSelect = useCallback((emoji: string) => {
    onSelect(emoji)
    setOpen(false)
    setSearch('')
  }, [onSelect])

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        {<Button variant="ghost" size="icon" className="size-8 text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300" title="表情">
          <Smile className="size-4" />
        </Button>}
      </PopoverTrigger>
      <PopoverContent className="w-72 p-0" align="start">
        <div className="border-b border-gray-100 dark:border-gray-800 p-2">
          <input
            ref={inputRef}
            type="text"
            placeholder="搜索表情..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full text-sm bg-transparent border-0 outline-none placeholder-gray-400 dark:placeholder-gray-500 text-gray-900 dark:text-gray-100"
          />
        </div>

        {/* Category tabs */}
        {!search && (
          <div className="flex gap-1 px-2 pt-2 pb-1 border-b border-gray-50 dark:border-gray-800/50">
            {EMOJI_CATEGORIES.map((cat, i) => (
              <button
                key={cat.name}
                onClick={() => setActiveCategory(i)}
                className={`text-xs px-2 py-1 rounded-full transition-colors ${
                  activeCategory === i
                    ? 'bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900'
                    : 'text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-800'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>
        )}

        {/* Emoji grid */}
        <div className="max-h-48 overflow-y-auto p-2">
          {search ? (
            <div className="grid grid-cols-8 gap-0.5">
              {filteredEmojis.map((emoji, i) => (
                <button
                  key={`${emoji}-${i}`}
                  onClick={() => handleSelect(emoji)}
                  className="size-8 flex items-center justify-center rounded hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors text-lg"
                >
                  {emoji}
                </button>
              ))}
              {filteredEmojis.length === 0 && (
                <div className="col-span-8 text-center text-xs text-gray-400 dark:text-gray-500 py-4">
                  未找到匹配的表情
                </div>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-8 gap-0.5">
              {EMOJI_CATEGORIES[activeCategory].emojis.map((emoji, i) => (
                <button
                  key={`${emoji}-${i}`}
                  onClick={() => handleSelect(emoji)}
                  className="size-8 flex items-center justify-center rounded hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors text-lg"
                >
                  {emoji}
                </button>
              ))}
            </div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  )
}

// Compact inline emoji picker button for comment input
interface EmojiPickerInlineProps {
  onSelect: (emoji: string) => void
}

export function EmojiPickerInline({ onSelect }: EmojiPickerInlineProps) {
  const [open, setOpen] = useState(false)
  const [search, setSearch] = useState('')
  const [activeCategory, setActiveCategory] = useState(0)

  const allEmojis = EMOJI_CATEGORIES.flatMap(c => c.emojis)
  const filteredEmojis = search
    ? allEmojis.filter(e => e.includes(search))
    : []

  const handleSelect = useCallback((emoji: string) => {
    onSelect(emoji)
    setOpen(false)
    setSearch('')
  }, [onSelect])

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          type="button"
          className="flex items-center justify-center size-7 rounded-full text-gray-400 hover:text-gray-600 hover:bg-gray-100 dark:text-gray-500 dark:hover:text-gray-300 dark:hover:bg-gray-800 transition-colors"
          title="表情"
        >
          <Smile className="size-4" />
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-64 p-0" align="start" side="top">
        <div className="border-b border-gray-100 dark:border-gray-800 p-2">
          <input
            type="text"
            placeholder="搜索..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full text-sm bg-transparent border-0 outline-none placeholder-gray-400 dark:placeholder-gray-500 text-gray-900 dark:text-gray-100"
          />
        </div>
        {!search && (
          <div className="flex gap-1 px-2 pt-2 pb-1">
            {EMOJI_CATEGORIES.map((cat, i) => (
              <button
                key={cat.name}
                onClick={() => setActiveCategory(i)}
                className={`text-[10px] px-1.5 py-0.5 rounded-full transition-colors ${
                  activeCategory === i
                    ? 'bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900'
                    : 'text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-800'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>
        )}
        <div className="max-h-40 overflow-y-auto p-1.5">
          {search ? (
            <div className="grid grid-cols-8 gap-0.5">
              {filteredEmojis.map((emoji, i) => (
                <button
                  key={`${emoji}-${i}`}
                  onClick={() => handleSelect(emoji)}
                  className="size-7 flex items-center justify-center rounded hover:bg-gray-100 dark:hover:bg-gray-800 text-base transition-colors"
                >
                  {emoji}
                </button>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-8 gap-0.5">
              {EMOJI_CATEGORIES[activeCategory].emojis.map((emoji, i) => (
                <button
                  key={`${emoji}-${i}`}
                  onClick={() => handleSelect(emoji)}
                  className="size-7 flex items-center justify-center rounded hover:bg-gray-100 dark:hover:bg-gray-800 text-base transition-colors"
                >
                  {emoji}
                </button>
              ))}
            </div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  )
}
