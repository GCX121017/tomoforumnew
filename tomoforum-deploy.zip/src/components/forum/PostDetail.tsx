'use client'

import { useReducer, useEffect, useState, useCallback, useRef } from 'react'
import { useForumStore } from '@/store/forum'
import { cn, formatTimeAgo, formatFullDate, getLevelInfo } from '@/components/forum/helpers'
import LevelBadge from './LevelBadge'
import PointsDisplay from './PointsDisplay'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { Separator } from '@/components/ui/separator'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import {
  Dialog,
  DialogContent,
} from '@/components/ui/dialog'
import CommentSection from './CommentSection'
import {
  ArrowLeft,
  ArrowUp,
  Heart,
  Bookmark,
  Share2,
  Eye,
  MessageSquare,
  Pin,
  PinOff,
  Lock,
  Edit3,
  Trash2,
  UserPlus,
  UserCheck,
} from 'lucide-react'
import { motion } from 'framer-motion'
import { toast } from 'sonner'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import { CodeBlock, InlineCode } from './CodeBlock'

interface DetailState {
  loading: boolean
  liked: boolean
  bookmarked: boolean
  likeCount: number
  viewCount: number
  copied: boolean
  likeAnimating: boolean
  isFollowing: boolean
  followerCount: number
  followLoading: boolean
}

type DetailAction =
  | { type: 'SET_LOADING' }
  | { type: 'SET_POST'; likeCount: number; viewCount: number }
  | { type: 'TOGGLE_LIKE'; liked: boolean }
  | { type: 'TOGGLE_BOOKMARK'; bookmarked: boolean }
  | { type: 'SET_COPIED' }
  | { type: 'SET_LIKE_ANIMATING'; value: boolean }
  | { type: 'SET_FOLLOWING'; value: boolean }
  | { type: 'SET_FOLLOWER_COUNT'; value: number }
  | { type: 'SET_FOLLOW_LOADING'; value: boolean }

function detailReducer(state: DetailState, action: DetailAction): DetailState {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, loading: true }
    case 'SET_POST':
      return { ...state, likeCount: action.likeCount, viewCount: action.viewCount, loading: false, liked: false, bookmarked: false }
    case 'TOGGLE_LIKE':
      return { ...state, liked: action.liked, likeCount: state.likeCount + (action.liked ? 1 : -1) }
    case 'TOGGLE_BOOKMARK':
      return { ...state, bookmarked: action.bookmarked }
    case 'SET_COPIED':
      return { ...state, copied: true }
    case 'SET_LIKE_ANIMATING':
      return { ...state, likeAnimating: action.value }
    case 'SET_FOLLOWING':
      return { ...state, isFollowing: action.value }
    case 'SET_FOLLOWER_COUNT':
      return { ...state, followerCount: action.value }
    case 'SET_FOLLOW_LOADING':
      return { ...state, followLoading: action.value }
    default:
      return state
  }
}

export default function PostDetail() {
  const {
    currentPage,
    currentPost,
    setCurrentPost,
    currentUser,
    navigate,
    setShowLoginDialog,
  } = useForumStore()

  const [state, dispatch] = useReducer(detailReducer, {
    loading: true,
    liked: false,
    bookmarked: false,
    likeCount: 0,
    viewCount: 0,
    copied: false,
    likeAnimating: false,
    isFollowing: false,
    followerCount: 0,
    followLoading: false,
  })

  const [readProgress, setReadProgress] = useState(0)
  const articleRef = useRef<HTMLDivElement>(null)
  const [lightboxSrc, setLightboxSrc] = useState<string | null>(null)
  const [lightboxAlt, setLightboxAlt] = useState('')

  const postId = currentPage.name === 'post' ? currentPage.postId : ''

  // Session-based view deduplication
  const getViewedPosts = useCallback((): string[] => {
    try {
      const raw = sessionStorage.getItem('forum_viewed_posts')
      return raw ? JSON.parse(raw) : []
    } catch { return [] }
  }, [])

  const addViewedPost = useCallback((id: string) => {
    try {
      const viewed = getViewedPosts()
      if (!viewed.includes(id)) {
        viewed.push(id)
        sessionStorage.setItem('forum_viewed_posts', JSON.stringify(viewed))
      }
    } catch { /* ignore */ }
  }, [getViewedPosts])

  useEffect(() => {
    if (!postId) return
    let cancelled = false
    dispatch({ type: 'SET_LOADING' })
    ;(async () => {
      try {
        const res = await fetch(`/api/posts/${postId}`)
        if (!cancelled && res.ok) {
          const data = await res.json()
          setCurrentPost(data)
          dispatch({ type: 'SET_POST', likeCount: data.likeCount || 0, viewCount: data.viewCount || 0 })

          // Increment view count (deduplicated per session)
          const viewedPosts = getViewedPosts()
          if (!viewedPosts.includes(postId)) {
            addViewedPost(postId)
            fetch(`/api/posts/${postId}/view`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
            }).catch(() => { /* ignore */ })
          }

          // Fetch follow status for the post author
          if (currentUser && data.authorId && currentUser.id !== data.authorId) {
            const followStatusRes = await fetch(`/api/follows/status?viewerId=${currentUser.id}&targetIds=${data.authorId}`)
            if (!cancelled && followStatusRes.ok) {
              const followData = await followStatusRes.json()
              dispatch({ type: 'SET_FOLLOWING', value: followData.statuses?.[data.authorId] || false })
            }
            // Fetch follower count
            const followsRes = await fetch(`/api/users/${data.authorId}/follows?type=followers&limit=1`)
            if (!cancelled && followsRes.ok) {
              const followsData = await followsRes.json()
              dispatch({ type: 'SET_FOLLOWER_COUNT', value: followsData.total || 0 })
            }
          }
        } else if (!cancelled) {
          navigate({ name: 'home' })
        }
      } catch {
        if (!cancelled) navigate({ name: 'home' })
      }
    })()
    return () => { cancelled = true }
  }, [postId, setCurrentPost, navigate, getViewedPosts, addViewedPost, currentUser])

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [postId])

  // Reading progress bar
  const handleScroll = useCallback(() => {
    if (!articleRef.current) return
    const article = articleRef.current
    const rect = article.getBoundingClientRect()
    const articleHeight = article.scrollHeight
    const viewportHeight = window.innerHeight
    const scrolledPast = Math.max(0, -rect.top)
    const totalScrollable = articleHeight - viewportHeight
    const progress = totalScrollable > 0 ? Math.min(100, (scrolledPast / totalScrollable) * 100) : 0
    setReadProgress(progress)
  }, [])

  useEffect(() => {
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [handleScroll])

  const handleLike = async () => {
    if (!currentUser) {
      setShowLoginDialog(true)
      return
    }
    // Trigger heart animation
    dispatch({ type: 'SET_LIKE_ANIMATING', value: true })
    setTimeout(() => dispatch({ type: 'SET_LIKE_ANIMATING', value: false }), 400)

    try {
      const res = await fetch(`/api/posts/${postId}/like`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id }),
      })
      if (res.ok) {
        const data = await res.json()
        dispatch({ type: 'TOGGLE_LIKE', liked: data.liked })
        toast.success(data.liked ? '已点赞' : '已取消点赞')
      }
    } catch { /* ignore */ }
  }

  const handleBookmark = async () => {
    if (!currentUser) {
      setShowLoginDialog(true)
      return
    }
    try {
      const res = await fetch(`/api/posts/${postId}/bookmark`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id }),
      })
      if (res.ok) {
        const data = await res.json()
        dispatch({ type: 'TOGGLE_BOOKMARK', bookmarked: data.bookmarked })
        toast.success(data.bookmarked ? '已收藏' : '已取消收藏')
      }
    } catch { /* ignore */ }
  }

  const handleToggleFollow = async () => {
    if (!currentUser || !currentPost) {
      setShowLoginDialog(true)
      return
    }
    if (currentUser.id === currentPost.authorId) return
    dispatch({ type: 'SET_FOLLOW_LOADING', value: true })
    try {
      const res = await fetch(`/api/users/${currentPost.authorId}/follow`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ followerId: currentUser.id }),
      })
      if (res.ok) {
        const data = await res.json()
        dispatch({ type: 'SET_FOLLOWING', value: data.following })
        dispatch({ type: 'SET_FOLLOWER_COUNT', value: data.followerCount })
        toast.success(data.following ? '已关注' : '已取消关注')
      }
    } catch { /* ignore */ }
    dispatch({ type: 'SET_FOLLOW_LOADING', value: false })
  }

  const handleShare = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href)
      dispatch({ type: 'SET_COPIED' })
      toast.success('链接已复制到剪贴板')
      setTimeout(() => { /* copied state will be reset on re-render */ }, 2000)
    } catch { /* ignore */ }
  }

  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)

  const isAuthor = currentUser && currentPost && currentUser.id === currentPost.authorId

  const handleDeletePost = async () => {
    if (!isAuthor) return
    setIsDeleting(true)
    try {
      const res = await fetch(`/api/posts/${postId}`, { method: 'DELETE' })
      if (res.ok) {
        toast.success('帖子已删除')
        setDeleteDialogOpen(false)
        navigate({ name: 'home' })
      } else {
        toast.error('删除失败')
      }
    } catch {
      toast.error('删除失败')
    }
    setIsDeleting(false)
  }

  const handleTogglePin = async () => {
    if (!currentUser || currentUser.role !== 'official' || !currentPost) return
    try {
      const res = await fetch(`/api/posts/${postId}/pin`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id }),
      })
      if (res.ok) {
        const data = await res.json()
        setCurrentPost({ ...currentPost, isPinned: data.pinned })
        toast.success(data.message)
      }
    } catch { /* ignore */ }
  }

  // Check if post was edited
  const isEdited = currentPost && currentPost.updatedAt && currentPost.createdAt
    ? new Date(currentPost.updatedAt).getTime() - new Date(currentPost.createdAt).getTime() > 5000
    : false

  // Extract headings for table of contents
  const headings = currentPost
    ? currentPost.content
        .split('\n')
        .filter(line => line.startsWith('## '))
        .map(line => ({
          level: (line.match(/^#+/) || [''])[0].length,
          text: line.replace(/^#+\s+/, ''),
          id: line.replace(/^#+\s+/, '').toLowerCase().replace(/\s+/g, '-')
        }))
    : []

  // Reading time estimate
  const readingTime = currentPost ? Math.max(1, Math.ceil(currentPost.content.length / 500)) : 1

  if (state.loading) {
    return (
      <div className="flex-1 max-w-3xl mx-auto w-full px-4 py-6">
        <Skeleton className="h-6 w-20 mb-4" />
        <Skeleton className="h-8 w-3/4 mb-3" />
        <div className="flex items-center gap-3 mb-6">
          <Skeleton className="size-10 rounded-full" />
          <Skeleton className="h-4 w-32" />
        </div>
        <div className="space-y-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-4 w-full" />
          ))}
        </div>
      </div>
    )
  }

  if (!currentPost) return null

  return (
    <motion.div
      initial={{ opacity: 0, x: 10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.3 }}
      className="flex-1 max-w-3xl mx-auto w-full relative"
    >
      {/* Reading progress bar */}
      {readProgress > 0 && (
        <div className="fixed top-14 left-0 right-0 z-30 h-[2px] bg-transparent">
          <div
            className="h-full bg-gray-900 dark:bg-gray-100 transition-[width] duration-100 ease-out"
            style={{ width: `${readProgress}%` }}
          />
        </div>
      )}

      {/* Back button */}
      <div className="px-4 py-3">
        <button
          onClick={() => navigate({ name: 'home' })}
          className="flex items-center gap-1.5 text-sm text-gray-400 hover:text-gray-700 dark:text-gray-500 dark:hover:text-gray-300 transition-colors"
        >
          <ArrowLeft className="size-4" />
          返回列表
        </button>
      </div>

      {/* Post Content */}
      <article className="px-4 pb-4" ref={articleRef}>
        {/* Title area */}
        <div className="mb-4">
          <div className="flex items-center gap-2 mb-2 flex-wrap">
            {currentPost.isPinned && (
              <Badge variant="secondary" className="bg-gray-100 text-gray-500 border-0 gap-1 dark:bg-gray-800 dark:text-gray-400">
                <Pin className="size-3" />
                置顶
              </Badge>
            )}
            {currentPost.isLocked && (
              <Badge variant="secondary" className="bg-gray-100 text-gray-500 border-0 gap-1 dark:bg-gray-800 dark:text-gray-400">
                <Lock className="size-3" />
                已锁定
              </Badge>
            )}
            {currentPost.category && (
              <Badge variant="outline" className="border-gray-200 text-gray-500 text-xs dark:border-gray-700 dark:text-gray-400">
                {currentPost.category.icon} {currentPost.category.name}
              </Badge>
            )}
          </div>

          <h1 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-gray-100 leading-snug mb-3">
            {currentPost.title}
          </h1>

          {/* Author info card */}
          <div className="flex items-center justify-between flex-wrap gap-2">
            <button
              onClick={() => navigate({ name: 'user', userId: currentPost.authorId })}
              className="flex items-center gap-2.5 group rounded-lg px-2.5 py-1.5 -mx-2.5 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors"
            >
              <div className="relative">
                <Avatar className="size-9">
                  <AvatarImage src={currentPost.author?.avatar} alt={currentPost.author?.username} />
                  <AvatarFallback className="text-sm bg-gray-100 dark:bg-gray-800">
                    {currentPost.author?.username?.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                {(() => {
                  const level = getLevelInfo(currentPost.author?.points ?? 0)
                  return (
                    <span className="absolute -bottom-0.5 -right-0.5 size-4 rounded-full bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-[10px] flex items-center justify-center shadow-sm leading-none">
                      {level.icon}
                    </span>
                  )
                })()}
              </div>
              <div className="text-left">
                <div className="flex items-center gap-1.5">
                  <p className="text-sm font-medium text-gray-900 dark:text-gray-100 group-hover:text-gray-600 dark:group-hover:text-gray-300 transition-colors">
                    {currentPost.author?.username}
                  </p>
                  <LevelBadge
                    level={currentPost.author?.level ?? 0}
                    points={currentPost.author?.points ?? 0}
                    role={currentPost.author?.role}
                    size="sm"
                  />
                </div>
                <PointsDisplay
                  points={currentPost.author?.points ?? 0}
                  compact
                />
                <p className="text-xs text-gray-400 mt-0.5">
                  约 {readingTime} 分钟阅读
                  {isEdited && currentPost.updatedAt && (
                    <span title={`最后编辑于 ${formatFullDate(currentPost.updatedAt)}`}>
                      {' · '}已编辑
                    </span>
                  )}
                </p>
              </div>
            </button>

            {/* Follow button for non-author, action buttons for author */}
            {!isAuthor && currentUser && (
              <Button
                size="sm"
                disabled={state.followLoading}
                onClick={handleToggleFollow}
                className={cn(
                  'h-8 px-4 text-xs font-medium transition-all shrink-0',
                  state.isFollowing
                    ? 'bg-gray-900 hover:bg-gray-800 text-white dark:bg-gray-100 dark:hover:bg-gray-200 dark:text-gray-900'
                    : 'bg-transparent border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                )}
              >
                {state.followLoading ? (
                  <span className="size-3.5 border-2 border-current border-t-transparent rounded-full animate-spin" />
                ) : state.isFollowing ? (
                  <><UserCheck className="size-3.5 mr-1.5" />已关注 {state.followerCount > 0 && <span className="opacity-70 ml-0.5">{state.followerCount}</span>}</>
                ) : (
                  <><UserPlus className="size-3.5 mr-1.5" />关注 {state.followerCount > 0 && <span className="opacity-70 ml-0.5">{state.followerCount}</span>}</>
                )}
              </Button>
            )}
            {!isAuthor && !currentUser && (
              <Button
                size="sm"
                onClick={() => setShowLoginDialog(true)}
                className="h-8 px-4 text-xs font-medium bg-transparent border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 shrink-0"
              >
                <UserPlus className="size-3.5 mr-1.5" />关注
              </Button>
            )}
            {/* Admin: Pin/Unpin */}
            {currentUser?.role === 'official' && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleTogglePin}
                className={cn(
                  'text-xs h-8 border-gray-200 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-800',
                  currentPost.isPinned && 'bg-gray-900 text-white border-gray-900 dark:bg-gray-100 dark:text-gray-900 dark:border-gray-100'
                )}
              >
                {currentPost.isPinned ? (
                  <><PinOff className="size-3" />取消置顶</>
                ) : (
                  <><Pin className="size-3" />置顶</>
                )}
              </Button>
            )}
            {/* Author: Edit + Delete */}
            {isAuthor && (
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => navigate({ name: 'edit', postId: currentPost.id })}
                  className="text-xs h-8 border-gray-200 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-800"
                >
                  <Edit3 className="size-3" />
                  编辑
                </Button>
                <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
                  <AlertDialogTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-xs h-8 border-red-200 text-red-500 hover:bg-red-50 hover:text-red-600 hover:border-red-300 dark:bg-gray-800 dark:hover:bg-red-950"
                    >
                      <Trash2 className="size-3" />
                      删除
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>确认删除</AlertDialogTitle>
                      <AlertDialogDescription>
                        确定要删除这篇帖子吗？此操作不可撤销。
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>取消</AlertDialogCancel>
                      <AlertDialogAction
                        onClick={handleDeletePost}
                        disabled={isDeleting}
                        className="bg-red-600 text-white hover:bg-red-700 focus:ring-red-600"
                      >
                        {isDeleting ? '删除中...' : '确认删除'}
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            )}
          </div>
        </div>

        {/* Tags */}
        {currentPost.tags && currentPost.tags.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mb-4">
            {currentPost.tags.map((tag) => (
              <Badge
                key={tag.id}
                variant="secondary"
                className="text-xs font-normal px-2 py-0.5 bg-gray-100 text-gray-500 border-0 cursor-pointer hover:bg-gray-200 transition-colors dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700"
                onClick={() => navigate({ name: 'home', tag: tag.name })}
              >
                {tag.name}
              </Badge>
            ))}
          </div>
        )}

        <Separator className="mb-5" />

        {/* Table of Contents */}
        {headings.length >= 2 && (
          <nav className="mb-6 p-4 rounded-lg bg-gray-50 border border-gray-100 dark:bg-gray-800 dark:border-gray-700">
            <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">目录</h4>
            <div className="space-y-1.5">
              {headings.map((h, i) => (
                <a
                  key={i}
                  href={`#${h.id}`}
                  className={cn(
                    'block text-sm text-gray-500 hover:text-gray-800 transition-colors dark:text-gray-400 dark:hover:text-gray-200',
                    h.level > 2 && 'pl-4'
                  )}
                  onClick={(e) => {
                    e.preventDefault()
                    document.getElementById(h.id)?.scrollIntoView({ behavior: 'smooth' })
                  }}
                >
                  {h.text}
                </a>
              ))}
            </div>
          </nav>
        )}

        {/* Markdown Content */}
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.15, ease: 'easeOut' }}
          className="prose prose-gray dark:prose-invert prose-sm max-w-none mb-6 prose-headings:text-gray-900 dark:prose-headings:text-gray-100 prose-p:text-gray-700 dark:prose-p:text-gray-300 prose-p:leading-relaxed prose-strong:text-gray-900 dark:prose-strong:text-gray-100 prose-a:text-gray-600 dark:prose-a:text-gray-400 prose-blockquote:border-gray-200 dark:prose-blockquote:border-gray-700 prose-li:text-gray-700 dark:prose-li:text-gray-300 prose-li:leading-relaxed"
        >
          <ReactMarkdown
            remarkPlugins={[remarkGfm]}
            components={{
              pre: ({ children }) => <>{children}</>,
              code: ({ className, children, ...props }) => {
                const match = /language-(\w+)/.exec(className || '')
                const isBlock = match || (typeof children === 'string' && children.includes('\n'))
                if (isBlock) {
                  return <CodeBlock language={match?.[1]}>{String(children).replace(/\n$/, '')}</CodeBlock>
                }
                return <InlineCode>{String(children)}</InlineCode>
              },
              img: ({ src, alt, ...props }) => (
                <img
                  src={typeof src === 'string' ? src : ''}
                  alt={alt || ''}
                  onClick={() => {
                    if (typeof src === 'string') {
                      setLightboxSrc(src)
                      setLightboxAlt(alt || '')
                    }
                  }}
                  className="max-w-full h-auto rounded-lg my-4 shadow-sm border border-gray-100 dark:border-gray-800 cursor-pointer hover:opacity-90 transition-opacity"
                  {...props}
                />
              ),
            }}
          >
            {currentPost.content}
          </ReactMarkdown>

          {/* Back to top link for long posts */}
          {currentPost.content.length > 1500 && (
            <div className="mt-8 pt-4 border-t border-gray-100 dark:border-gray-800">
              <button
                onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                className="flex items-center gap-1.5 text-sm text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300 transition-colors"
              >
                <ArrowUp className="size-3.5" />
                回到顶部
              </button>
            </div>
          )}
        </motion.div>

        {/* Edited timestamp */}
        {isEdited && currentPost.updatedAt && (
          <p className="text-xs text-gray-400 dark:text-gray-500 mb-4">
            最后编辑于 {formatFullDate(currentPost.updatedAt)}
          </p>
        )}

        <Separator className="mb-4" />

        {/* Action bar */}
        <div className="flex items-center gap-4 py-2">
          <motion.button
            onClick={handleLike}
            animate={state.likeAnimating ? { scale: [1, 1.3, 1] } : {}}
            transition={{ duration: 0.3, ease: 'easeOut' }}
            className={cn(
              'flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm transition-all',
              state.liked
                ? 'bg-gray-900 text-white'
                : 'text-gray-500 hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-800',
              !currentUser && 'opacity-60'
            )}
            title={!currentUser ? '点击登录后点赞' : '点赞'}
          >
            <Heart className={cn('size-4', state.liked && 'fill-current')} />
            <span>{state.likeCount}</span>
          </motion.button>

          <button
            onClick={handleBookmark}
            className={cn(
              'flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm transition-all',
              state.bookmarked
                ? 'bg-gray-900 text-white'
                : 'text-gray-500 hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-800',
              !currentUser && 'opacity-60'
            )}
            title={!currentUser ? '点击登录后收藏' : '收藏'}
          >
            <Bookmark className={cn('size-4', state.bookmarked && 'fill-current')} />
            <span>{state.bookmarked ? '已收藏' : '收藏'}</span>
          </button>

          <button
            onClick={handleShare}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm text-gray-500 hover:bg-gray-100 hover:text-gray-700 transition-all dark:hover:bg-gray-800 dark:hover:text-gray-300"
          >
            <Share2 className="size-4" />
            <span>{state.copied ? '已复制' : '分享'}</span>
          </button>

          <div className="ml-auto flex items-center gap-3 text-xs text-gray-400">
            <span className="flex items-center gap-1">
              <Eye className="size-3.5" />
              {state.viewCount}
            </span>
            <span className="flex items-center gap-1">
              <MessageSquare className="size-3.5" />
              {currentPost.commentCount}
            </span>
          </div>
        </div>
      </article>

      {/* Image Lightbox */}
      <Dialog open={!!lightboxSrc} onOpenChange={(open) => { if (!open) setLightboxSrc(null) }}>
        <DialogContent className="max-w-[95vw] max-h-[95vh] p-2 bg-black/95 border-none sm:max-w-[95vw]">
          {lightboxSrc && (
            <div className="flex items-center justify-center w-full h-full">
              <img
                src={lightboxSrc}
                alt={lightboxAlt}
                className="max-w-full max-h-[90vh] object-contain rounded-lg"
              />
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Comments */}
      <CommentSection postId={postId} isLocked={currentPost.isLocked} />
    </motion.div>
  )
}
