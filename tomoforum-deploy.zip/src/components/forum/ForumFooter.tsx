'use client'

import { useForumStore } from '@/store/forum'
import { ArrowUp } from 'lucide-react'

export default function ForumFooter() {
  const { navigate } = useForumStore()

  return (
    <footer className="mt-auto">
      {/* Gradient top border */}
      <div className="gradient-border-top" />

      <div className="bg-gray-50 dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 py-8 pb-[env(safe-area-inset-bottom,theme(spacing.8))]">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-xs text-gray-400 dark:text-gray-500">
              明天后 &copy; {new Date().getFullYear()} &middot; 以黑白之名，书写明天
            </p>

            {/* Back to top button - center */}
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="flex items-center gap-1.5 text-xs text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300 transition-colors group"
            >
              <span>返回顶部</span>
              <ArrowUp className="size-3 group-hover:-translate-y-0.5 transition-transform" />
            </button>

            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate({ name: 'legal', section: 'about' })}
                className="text-xs text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300 transition-all duration-200 hover:underline underline-offset-2"
              >
                关于我们
              </button>
              <button
                onClick={() => navigate({ name: 'legal', section: 'terms' })}
                className="text-xs text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300 transition-all duration-200 hover:underline underline-offset-2"
              >
                使用条款
              </button>
              <button
                onClick={() => navigate({ name: 'legal', section: 'contact' })}
                className="text-xs text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300 transition-all duration-200 hover:underline underline-offset-2"
              >
                联系方式
              </button>
            </div>
          </div>

          <p className="text-center text-[11px] text-gray-300 dark:text-gray-600 mt-4">
            Made with ❤️ by 明天后社区
          </p>
        </div>
      </div>
    </footer>
  )
}
