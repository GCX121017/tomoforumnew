import { cn } from '@/lib/utils'
import { formatDistanceToNow, format } from 'date-fns'
import { zhCN } from 'date-fns/locale'

export { cn }

export interface LevelInfo {
  level: number
  name: string
  minPoints: number
  icon: string
}

const LEVELS: LevelInfo[] = [
  { level: 1, name: '新手', minPoints: 0, icon: '🌱' },
  { level: 2, name: '入门', minPoints: 10, icon: '🌿' },
  { level: 3, name: '活跃', minPoints: 50, icon: '🌳' },
  { level: 4, name: '资深', minPoints: 150, icon: '⭐' },
  { level: 5, name: '专家', minPoints: 500, icon: '💎' },
  { level: 6, name: '大师', minPoints: 1000, icon: '🏆' },
]

export function getLevelInfo(points: number): LevelInfo {
  for (let i = LEVELS.length - 1; i >= 0; i--) {
    if (points >= LEVELS[i].minPoints) return LEVELS[i]
  }
  return LEVELS[0]
}

export function getNextLevelInfo(points: number): LevelInfo | null {
  const current = getLevelInfo(points)
  const idx = LEVELS.findIndex((l) => l.level === current.level)
  return idx < LEVELS.length - 1 ? LEVELS[idx + 1] : null
}

export function getLevelProgress(points: number): number {
  const current = getLevelInfo(points)
  const next = getNextLevelInfo(points)
  if (!next) return 100
  return Math.min(100, Math.round(((points - current.minPoints) / (next.minPoints - current.minPoints)) * 100))
}

export function formatTimeAgo(dateStr: string): string {
  try {
    const date = new Date(dateStr)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffSeconds = Math.floor(diffMs / 1000)

    if (diffSeconds < 60) return '刚刚'
    if (diffSeconds < 3600) return `${Math.floor(diffSeconds / 60)} 分钟前`
    if (diffSeconds < 86400) return `${Math.floor(diffSeconds / 3600)} 小时前`
    if (diffSeconds < 2592000) return `${Math.floor(diffSeconds / 86400)} 天前`
    if (diffSeconds < 31536000) return `${Math.floor(diffSeconds / 2592000)} 个月前`

    return formatDistanceToNow(date, { addSuffix: true, locale: zhCN })
  } catch {
    return ''
  }
}

export function formatDate(dateStr: string): string {
  try {
    const date = new Date(dateStr)
    return format(date, 'yyyy-MM-dd')
  } catch {
    return ''
  }
}

export function formatFullDate(dateStr: string): string {
  try {
    const date = new Date(dateStr)
    return format(date, 'yyyy年MM月dd日 HH:mm', { locale: zhCN })
  } catch {
    return ''
  }
}

export function truncateText(text: string, maxLen: number): string {
  if (!text || text.length <= maxLen) return text
  return text.slice(0, maxLen) + '...'
}

export function getLevelBadgeText(level: number, role?: string): string {
  if (role === 'official') return '🏛️ 官方'
  const levels = ['🫧 冒泡', '🌱 小白', '🤝 老友', '⭐ 专家', '💎 VIP', '👑 SVIP']
  return levels[Math.min(level, levels.length - 1)] || '🫧 冒泡'
}

export function getReadingTime(text: string): number {
  if (!text) return 1
  // Chinese characters count as 1, English words count as 1
  const chineseChars = (text.match(/[\u4e00-\u9fff]/g) || []).length
  const englishWords = (text.match(/[a-zA-Z]+/g) || []).length
  return Math.max(1, Math.ceil((chineseChars + englishWords * 5) / 500))
}
