'use client'

import { useCallback } from 'react'
import { Home, Users, Flame, PlusCircle, User } from 'lucide-react'
import { useForumStore } from '@/store/forum'
import { cn } from '@/components/forum/helpers'

export default function MobileBottomNav() {
  const { currentPage, navigate, currentUser, activeFeed, setActiveFeed, setShowLoginDialog } = useForumStore()

  // Derive active states
  const isAllActive = currentPage.name === 'home' && activeFeed === 'all'
  const isFollowingActive = currentPage.name === 'home' && activeFeed === 'following'
  const isProfileActive = currentPage.name === 'user'

  const handleAll = useCallback(() => {
    setActiveFeed('all')
    navigate({ name: 'home' })
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }, [navigate, setActiveFeed])

  const handleFollowing = useCallback(() => {
    if (!currentUser) {
      setShowLoginDialog(true)
      return
    }
    setActiveFeed('following')
    navigate({ name: 'home' })
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }, [currentUser, navigate, setActiveFeed, setShowLoginDialog])

  const handleHot = useCallback(() => {
    setActiveFeed('all')
    navigate({ name: 'home' })
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }, [navigate, setActiveFeed])

  const handleCreate = useCallback(() => {
    if (!currentUser) {
      setShowLoginDialog(true)
      return
    }
    navigate({ name: 'create' })
  }, [currentUser, navigate, setShowLoginDialog])

  const handleProfile = useCallback(() => {
    if (!currentUser) {
      setShowLoginDialog(true)
      return
    }
    navigate({ name: 'user', userId: currentUser.id })
  }, [currentUser, navigate, setShowLoginDialog])

  return (
    <nav
      className={cn(
        'fixed bottom-0 left-0 right-0 z-40 md:hidden',
        'bg-white dark:bg-gray-950',
        'border-t border-gray-200 dark:border-gray-800',
        'shadow-[0_-1px_10px_rgba(0,0,0,0.05)]',
        'pb-[env(safe-area-inset-bottom)]'
      )}
      aria-label="底部导航"
    >
      <div className="grid grid-cols-5 h-14">
        {/* 全部 Tab */}
        <button
          onClick={handleAll}
          className={cn(
            'flex flex-col items-center justify-center gap-0.5 transition-colors relative',
            isAllActive
              ? 'text-gray-900 dark:text-gray-100'
              : 'text-gray-400 dark:text-gray-500'
          )}
          aria-label="全部"
          aria-current={isAllActive ? 'page' : undefined}
        >
          {isAllActive && (
            <span className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 rounded-full bg-gray-900 dark:bg-gray-100" />
          )}
          <Home className={cn('size-5', isAllActive && 'bg-gray-100 dark:bg-gray-800 rounded-md p-0.5')} />
          <span className="text-[10px] font-medium">全部</span>
        </button>

        {/* 关注 Tab */}
        <button
          onClick={handleFollowing}
          className={cn(
            'flex flex-col items-center justify-center gap-0.5 transition-colors relative',
            isFollowingActive
              ? 'text-gray-900 dark:text-gray-100'
              : 'text-gray-400 dark:text-gray-500'
          )}
          aria-label="关注"
          aria-current={isFollowingActive ? 'page' : undefined}
        >
          {isFollowingActive && (
            <span className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 rounded-full bg-gray-900 dark:bg-gray-100" />
          )}
          <Users className={cn('size-5', isFollowingActive && 'bg-gray-100 dark:bg-gray-800 rounded-md p-0.5')} />
          <span className="text-[10px] font-medium">关注</span>
        </button>

        {/* Create Tab (Center - Elevated) */}
        <button
          onClick={handleCreate}
          className="flex flex-col items-center justify-center gap-0.5 relative"
          aria-label={currentUser ? '发布帖子' : '登录后发布'}
        >
          <div className="size-10 -mt-5 rounded-full bg-gray-900 dark:bg-gray-100 flex items-center justify-center shadow-lg shadow-gray-900/20 dark:shadow-gray-100/10 active:scale-95 transition-transform">
            <PlusCircle className="size-5 text-white dark:text-gray-900" />
          </div>
          <span className="text-[10px] font-medium text-gray-400 dark:text-gray-500 mt-0.5">
            发布
          </span>
        </button>

        {/* 热门 Tab */}
        <button
          onClick={handleHot}
          className={cn(
            'flex flex-col items-center justify-center gap-0.5 transition-colors relative',
            'text-gray-400 dark:text-gray-500'
          )}
          aria-label="热门"
        >
          <Flame className="size-5" />
          <span className="text-[10px] font-medium">热门</span>
        </button>

        {/* 我的 Tab */}
        <button
          onClick={handleProfile}
          className={cn(
            'flex flex-col items-center justify-center gap-0.5 transition-colors relative',
            isProfileActive
              ? 'text-gray-900 dark:text-gray-100'
              : 'text-gray-400 dark:text-gray-500'
          )}
          aria-label={currentUser ? '我的主页' : '登录'}
          aria-current={isProfileActive ? 'page' : undefined}
        >
          {isProfileActive && (
            <span className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 rounded-full bg-gray-900 dark:bg-gray-100" />
          )}
          <User className={cn('size-5', isProfileActive && 'bg-gray-100 dark:bg-gray-800 rounded-md p-0.5')} />
          <span className="text-[10px] font-medium">我的</span>
        </button>
      </div>
    </nav>
  )
}
