'use client'

import { useEffect, useRef, useState, useCallback } from 'react'
import { Check, Copy } from 'lucide-react'
import hljs from 'highlight.js'
import 'highlight.js/styles/github.css'

interface CodeBlockProps {
  language?: string
  children: string
  className?: string
}

export function CodeBlock({ language, children, className }: CodeBlockProps) {
  const codeRef = useRef<HTMLElement>(null)
  const [copied, setCopied] = useState(false)
  const [detectedLang, setDetectedLang] = useState(language || 'text')
  const code = children.replace(/\n$/, '')

  useEffect(() => {
    if (codeRef.current && !codeRef.current.dataset.highlighted) {
      hljs.highlightElement(codeRef.current)
      if (!language) {
        // highlight.js may expose `result` on the element; use type assertion
        const el = codeRef.current as HTMLElement & { result?: { language?: string } }
        if (el.result?.language) {
          setDetectedLang(el.result.language)
        }
      }
    }
  }, [code, language])

  const handleCopy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(code)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      const textarea = document.createElement('textarea')
      textarea.value = code
      document.body.appendChild(textarea)
      textarea.select()
      document.execCommand('copy')
      document.body.removeChild(textarea)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }, [code])

  return (
    <div className={`group relative rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden my-4 ${className || ''}`}>
      {/* Header bar */}
      <div className="flex items-center justify-between px-4 py-2 bg-gray-50 dark:bg-gray-800/80 border-b border-gray-200 dark:border-gray-700">
        <span className="text-xs font-medium text-gray-400 dark:text-gray-500 uppercase tracking-wider">
          {detectedLang}
        </span>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1 text-xs text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300 transition-colors opacity-0 group-hover:opacity-100"
          title="复制代码"
        >
          {copied ? (
            <>
              <Check className="size-3" />
              <span>已复制</span>
            </>
          ) : (
            <>
              <Copy className="size-3" />
              <span>复制</span>
            </>
          )}
        </button>
      </div>
      {/* Code */}
      <div className="overflow-x-auto">
        <pre className="!m-0 !p-4 !bg-transparent !border-0 !rounded-none">
          <code
            ref={codeRef}
            className={`!text-sm !font-mono ${detectedLang !== 'text' ? `language-${detectedLang}` : ''}`}
          >
            {code}
          </code>
        </pre>
      </div>
    </div>
  )
}

interface InlineCodeProps {
  children: string
}

export function InlineCode({ children }: InlineCodeProps) {
  return (
    <code className="bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 px-1.5 py-0.5 rounded text-sm font-mono border border-gray-200 dark:border-gray-700">
      {children}
    </code>
  )
}
