'use client'

import { useState, useEffect, useCallback } from 'react'
import { useTheme } from 'next-themes'
import { useForumStore } from '@/store/forum'
import { Search, PenSquare, LogIn, LogOut, Menu, User, Settings, Sun, Moon, Check, Shuffle, ArrowLeft, Sparkles, Shield, Eye, EyeOff, KeyRound, Lock, PanelLeftClose, PanelLeftOpen, Users, MessageCircle } from 'lucide-react'
import { PRESET_AVATARS, generateAvatarUrl, generateRandomColor } from '@/lib/levels'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from '@/components/ui/sheet'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { motion, AnimatePresence } from 'framer-motion'
import { cn } from '@/components/forum/helpers'
import EditProfile from './EditProfile'
import NotificationBell from './NotificationBell'

// Preset color options for custom avatar generation
const PRESET_COLORS = [
  { name: '灰色', value: '#6b7280' },
  { name: '蓝色', value: '#3b82f6' },
  { name: '绿色', value: '#22c55e' },
  { name: '橙色', value: '#f97316' },
  { name: '红色', value: '#ef4444' },
  { name: '紫色', value: '#a855f7' },
  { name: '青色', value: '#14b8a6' },
  { name: '粉色', value: '#ec4899' },
]

// Username validation regex: Chinese chars, letters, numbers, underscore
const USERNAME_REGEX = /^[\u4e00-\u9fa5a-zA-Z0-9_]+$/

type DialogMode = 'register' | 'login'

export default function ForumHeader() {
  const { navigate, currentUser, setCurrentUser, setSidebarOpen, sidebarOpen, sidebarCollapsed, setSidebarCollapsed, showLoginDialog, setShowLoginDialog, setShowFriendsPanel } = useForumStore()
  const { theme, setTheme } = useTheme()
  const [editProfileOpen, setEditProfileOpen] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [mobileSearchQuery, setMobileSearchQuery] = useState('')

  // Registration / Login dialog state
  const [dialogMode, setDialogMode] = useState<DialogMode>('register')
  const [username, setUsername] = useState('')
  const [logging, setLogging] = useState(false)
  const [error, setError] = useState('')
  const [regStep, setRegStep] = useState<1 | 2 | 3>(1)
  const [selectedAvatarId, setSelectedAvatarId] = useState(PRESET_AVATARS[0].id)
  const [selectedAvatarUrl, setSelectedAvatarUrl] = useState(PRESET_AVATARS[0].url)
  const [avatarType, setAvatarType] = useState<'preset' | 'generated'>('preset')
  const [selectedColor, setSelectedColor] = useState('#6b7280')
  const [usernameChecking, setUsernameChecking] = useState(false)
  const [usernameError, setUsernameError] = useState('')

  // Password state
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [passwordError, setPasswordError] = useState('')

  // Existing state
  const [searchQuery, setSearchQuery] = useState('')
  const [scrolled, setScrolled] = useState(false)
  const [mounted, setMounted] = useState(false)
  const [searchFocused, setSearchFocused] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    // Restore user from cookie
    ;(async () => {
      try {
        const res = await fetch('/api/auth')
        if (res.ok) {
          const data = await res.json()
          if (data.user) setCurrentUser(data.user)
        }
      } catch { /* ignore */ }
    })()
  }, [setCurrentUser])

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 10)
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const resetDialog = useCallback(() => {
    setShowLoginDialog(false)
    setMobileMenuOpen(false)
    setUsername('')
    setRegStep(1)
    setSelectedAvatarId(PRESET_AVATARS[0].id)
    setSelectedAvatarUrl(PRESET_AVATARS[0].url)
    setAvatarType('preset')
    setSelectedColor('#6b7280')
    setUsernameError('')
    setError('')
    setLogging(false)
    setUsernameChecking(false)
    setDialogMode('register')
    setPassword('')
    setConfirmPassword('')
    setShowPassword(false)
    setShowConfirmPassword(false)
    setPasswordError('')
  }, [setShowLoginDialog, setMobileMenuOpen])

  // Step 1: Validate username and check if user exists
  const handleCheckUsername = async () => {
    const trimmed = username.trim()

    if (!trimmed) {
      setUsernameError('请输入用户名')
      return
    }
    if (trimmed.length < 2 || trimmed.length > 20) {
      setUsernameError('用户名需要2-20个字符')
      return
    }
    if (!USERNAME_REGEX.test(trimmed)) {
      setUsernameError('用户名只能包含中文、字母、数字和下划线')
      return
    }

    setUsernameChecking(true)
    setUsernameError('')

    try {
      const res = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'checkUser', username: trimmed }),
      })
      const data = await res.json()
      if (res.ok && data.exists) {
        // User exists — switch to login mode (show password field)
        setDialogMode('login')
        setRegStep(1)
        setPassword('')
        setPasswordError('')
        setShowPassword(false)
      } else {
        // New user — proceed to avatar selection (also covers 404 and exists: false)
        setDialogMode('register')
        setRegStep(2)
      }
    } catch {
      setUsernameError('网络错误，请重试')
    } finally {
      setUsernameChecking(false)
    }
  }

  // Handle login (existing user with password)
  const handleLogin = async () => {
    if (!password) {
      setPasswordError('请输入密码')
      return
    }
    if (password.length < 6) {
      setPasswordError('密码至少需要6个字符')
      return
    }

    setLogging(true)
    setError('')
    setPasswordError('')

    try {
      const res = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'login', username: username.trim(), password }),
      })
      const data = await res.json()

      if (res.ok) {
        setCurrentUser(data.user)
        resetDialog()
      } else {
        if (data.code === 'NOT_FOUND') {
          setError('用户不存在')
        } else if (data.code === 'WRONG_PASSWORD') {
          setPasswordError('密码错误')
        } else {
          setError(data.error || '登录失败')
        }
      }
    } catch {
      setError('网络错误，请重试')
    } finally {
      setLogging(false)
    }
  }

  // Step 3: Complete registration with password
  const handleCompleteRegistration = async () => {
    // Validate password
    if (!password) {
      setPasswordError('请设置密码')
      return
    }
    if (password.length < 6) {
      setPasswordError('密码至少需要6个字符')
      return
    }
    if (password !== confirmPassword) {
      setPasswordError('两次密码输入不一致')
      return
    }

    setLogging(true)
    setError('')
    setPasswordError('')

    try {
      const finalAvatar = avatarType === 'preset'
        ? selectedAvatarUrl
        : generateAvatarUrl(username.trim(), selectedColor)

      const res = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'register',
          username: username.trim(),
          password,
          avatar: finalAvatar,
          avatarColor: avatarType === 'generated' ? selectedColor : '',
          avatarType,
          bio: '',
        }),
      })
      const data = await res.json()

      if (res.ok) {
        setCurrentUser(data.user)
        resetDialog()
      } else {
        setError(data.error || '注册失败')
      }
    } catch {
      setError('网络错误，请重试')
    } finally {
      setLogging(false)
    }
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      navigate({ name: 'search', query: searchQuery.trim() })
      setSearchQuery('')
    }
  }

  const handleMobileSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (mobileSearchQuery.trim()) {
      navigate({ name: 'search', query: mobileSearchQuery.trim() })
      setMobileSearchQuery('')
      setMobileMenuOpen(false)
    }
  }

  const handleLogout = async () => {
    try { await fetch('/api/auth', { method: 'DELETE' }) } catch { /* ignore */ }
    setCurrentUser(null)
    setMobileMenuOpen(false)
  }

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark')
  }

  const handleMobileNav = (action: () => void) => {
    action()
    setMobileMenuOpen(false)
  }

  // Animation variants for step transitions
  const stepVariants = {
    enter: { opacity: 0, x: 40 },
    center: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: -40 },
  }

  const stepTransition = { duration: 0.25, ease: 'easeInOut' as const }

  // Dialog title and description based on mode and step
  const getDialogTitle = () => {
    if (dialogMode === 'login') return '登录「明天后」'
    if (regStep === 1) return '加入「明天后」'
    if (regStep === 2) return '选择你的头像'
    return '设置你的密码'
  }

  const getDialogDesc = () => {
    if (dialogMode === 'login') return `欢迎回来，${username.trim()}`
    if (regStep === 1) return '输入用户名开始你的旅程'
    if (regStep === 2) return `你好，${username.trim()}！选一个你喜欢的头像`
    return `最后一步，${username.trim()}！设置你的登录密码`
  }

  return (
    <>
      <header
        className={cn(
          'fixed top-0 left-0 right-0 z-40 transition-all duration-300',
          scrolled
            ? 'bg-white/90 dark:bg-gray-950/90 backdrop-blur-lg border-b border-gray-200 dark:border-gray-800 shadow-sm dark:shadow-none'
            : 'bg-white/80 dark:bg-gray-950/80 backdrop-blur-md border-b border-gray-100 dark:border-gray-800/50'
        )}
      >
        <div className="max-w-7xl mx-auto px-4 h-14 flex items-center gap-3">
          {/* Left: Hamburger (mobile) + Sidebar toggle (md) + Logo */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Mobile hamburger */}
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="md:hidden p-1.5 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              aria-label="打开菜单"
            >
              <motion.div
                animate={mobileMenuOpen ? { rotate: 90, scale: 0.8 } : { rotate: 0, scale: 1 }}
                transition={{ duration: 0.2 }}
              >
                <Menu className="size-5 text-gray-900 dark:text-gray-100" />
              </motion.div>
            </button>

            {/* Desktop sidebar collapse toggle */}
            <button
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              className="hidden md:flex p-1.5 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              aria-label={sidebarCollapsed ? '展开侧边栏' : '收起侧边栏'}
            >
              {sidebarCollapsed ? <PanelLeftOpen className="size-5 text-gray-900 dark:text-gray-100" /> : <PanelLeftClose className="size-5 text-gray-900 dark:text-gray-100" />}
            </button>

            <motion.button
              onClick={() => navigate({ name: 'home' })}
              className="flex items-center gap-2 group"
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              transition={{ type: 'spring', stiffness: 400, damping: 25 }}
            >
              <div className="size-8 rounded-lg bg-gray-900 dark:bg-gray-100 flex items-center justify-center group-hover:bg-gray-800 dark:group-hover:bg-gray-200 transition-colors">
                <PenSquare className="size-4 text-white dark:text-gray-900" />
              </div>
              <span className="text-lg font-bold tracking-tight hidden sm:block text-gray-900 dark:text-gray-100">
                明天后
              </span>
            </motion.button>
          </div>

          {/* Center: Search (desktop only) */}
          <form
            onSubmit={handleSearch}
            className="hidden sm:block flex-1 mx-auto"
          >
            <div className={cn(
              'relative transition-all duration-300 ease-out',
              searchFocused ? 'max-w-lg' : 'max-w-md',
              'focus-within:ring-2 focus-within:ring-gray-900/10 dark:focus-within:ring-gray-100/10 focus-within:rounded-md'
            )}>
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400 dark:text-gray-500" />
              <Input
                type="text"
                placeholder="搜索帖子..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => setSearchFocused(true)}
                onBlur={() => setSearchFocused(false)}
                className="pl-9 pr-9 h-9 bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 focus-visible:bg-white dark:focus-visible:bg-gray-900 focus-visible:border-gray-300 dark:focus-visible:border-gray-600 text-sm text-gray-900 dark:text-gray-100 placeholder:text-gray-400 dark:placeholder:text-gray-500"
              />
              <button
                type="submit"
                className="absolute right-2 top-1/2 -translate-y-1/2 p-1 rounded-md text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                aria-label="搜索"
              >
                <Search className="size-3.5" />
              </button>
            </div>
          </form>

          {/* Right: Actions (desktop) */}
          <div className="hidden md:flex items-center gap-2 shrink-0">
            {/* Theme Toggle */}
            {mounted && (
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                className="size-9 text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-800"
                aria-label={theme === 'dark' ? '切换到浅色模式' : '切换到深色模式'}
              >
                {theme === 'dark' ? (
                  <Sun className="size-4" />
                ) : (
                  <Moon className="size-4" />
                )}
              </Button>
            )}

            {/* Notification Bell */}
            <NotificationBell />

            <Button
              onClick={() => {
                if (!currentUser) {
                  setShowLoginDialog(true)
                  return
                }
                navigate({ name: 'create' })
              }}
              size="sm"
              className="bg-gray-900 dark:bg-gray-100 hover:bg-gray-800 dark:hover:bg-gray-200 text-white dark:text-gray-900 text-xs"
            >
              <PenSquare className="size-3.5" />
              <span className="hidden sm:inline">写帖子</span>
            </Button>

            {currentUser ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex items-center gap-1.5 p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
                    <Avatar className="size-7">
                      <AvatarImage src={currentUser.avatar} alt={currentUser.username} />
                      <AvatarFallback className="text-xs bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-gray-100">
                        {currentUser.username.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-sm font-medium hidden sm:block max-w-20 truncate text-gray-900 dark:text-gray-100">
                      {currentUser.username}
                    </span>
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem onClick={() => navigate({ name: 'user', userId: currentUser.id })}>
                    <User className="size-4" />
                    我的主页
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setEditProfileOpen(true)}>
                    <Settings className="size-4" />
                    编辑资料
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => setShowFriendsPanel(true)}>
                    <Users className="size-4" />
                    好友
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate({ name: 'messages' })}>
                    <MessageCircle className="size-4" />
                    私信
                  </DropdownMenuItem>
                  {currentUser.role === 'official' && (
                    <>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => navigate({ name: 'admin' })}>
                        <Shield className="size-4" />
                        管理后台
                      </DropdownMenuItem>
                    </>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} variant="destructive">
                    <LogOut className="size-4" />
                    退出登录
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowLoginDialog(true)}
                className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-800 text-xs"
              >
                <LogIn className="size-3.5" />
                <span className="hidden sm:inline">登录</span>
              </Button>
            )}
          </div>

          {/* Mobile right: just notification bell + write button */}
          <div className="flex md:hidden items-center gap-1.5 shrink-0">
            <NotificationBell />
            <Button
              size="icon"
              onClick={() => {
                if (!currentUser) {
                  setShowLoginDialog(true)
                  return
                }
                navigate({ name: 'create' })
              }}
              className="size-9 bg-gray-900 dark:bg-gray-100 hover:bg-gray-800 dark:hover:bg-gray-200 text-white dark:text-gray-900"
            >
              <PenSquare className="size-3.5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Mobile Menu Sheet */}
      <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
        <SheetContent side="left" className="w-72 p-0 bg-white dark:bg-gray-950 border-gray-200 dark:border-gray-800">
          <SheetHeader className="px-4 pt-5 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="size-8 rounded-lg bg-gray-900 dark:bg-gray-100 flex items-center justify-center">
                <PenSquare className="size-4 text-white dark:text-gray-900" />
              </div>
              <div>
                <SheetTitle className="text-base text-gray-900 dark:text-gray-100">明天后</SheetTitle>
                <SheetDescription className="text-xs text-gray-400 dark:text-gray-500">以黑白之名，书写明天</SheetDescription>
              </div>
            </div>
          </SheetHeader>

          <div className="px-4 pb-4">
            {/* Mobile search */}
            <form onSubmit={handleMobileSearch}>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400 dark:text-gray-500" />
                <Input
                  type="text"
                  placeholder="搜索帖子..."
                  value={mobileSearchQuery}
                  onChange={(e) => setMobileSearchQuery(e.target.value)}
                  className="pl-9 h-9 bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-sm text-gray-900 dark:text-gray-100 placeholder:text-gray-400 dark:placeholder:text-gray-500"
                />
              </div>
            </form>
          </div>

          <Separator />

          {/* Mobile nav items */}
          <div className="flex flex-col py-2">
            <button
              onClick={() => handleMobileNav(() => navigate({ name: 'home' }))}
              className="flex items-center gap-3 px-4 py-3 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors text-left"
            >
              <PenSquare className="size-4 text-gray-400" />
              首页
            </button>

            {currentUser && (
              <button
                onClick={() => handleMobileNav(() => navigate({ name: 'user', userId: currentUser.id }))}
                className="flex items-center gap-3 px-4 py-3 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors text-left"
              >
                <User className="size-4 text-gray-400" />
                我的主页
              </button>
            )}

            <button
              onClick={() => handleMobileNav(() => navigate({ name: 'create' }))}
              className="flex items-center gap-3 px-4 py-3 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors text-left"
            >
              <PenSquare className="size-4 text-gray-400" />
              写帖子
            </button>
          </div>

          <Separator />

          {/* Theme toggle */}
          <div className="py-2">
            <button
              onClick={() => handleMobileNav(toggleTheme)}
              className="flex items-center gap-3 px-4 py-3 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors text-left w-full"
            >
              {mounted && theme === 'dark' ? (
                <Sun className="size-4 text-gray-400" />
              ) : (
                <Moon className="size-4 text-gray-400" />
              )}
              {mounted ? (theme === 'dark' ? '浅色模式' : '深色模式') : '切换主题'}
            </button>
          </div>

          <Separator />

          {/* User section */}
          <div className="mt-auto px-4 py-4">
            {currentUser ? (
              <div className="flex items-center gap-3">
                <Avatar className="size-9">
                  <AvatarImage src={currentUser.avatar} alt={currentUser.username} />
                  <AvatarFallback className="text-xs bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-gray-100">
                    {currentUser.username.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">
                    {currentUser.username}
                  </p>
                </div>
                <button
                  onClick={handleLogout}
                  className="p-1.5 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  aria-label="退出登录"
                >
                  <LogOut className="size-4" />
                </button>
              </div>
            ) : (
              <Button
                onClick={() => {
                  setMobileMenuOpen(false)
                  setShowLoginDialog(true)
                }}
                className="w-full bg-gray-900 dark:bg-gray-100 hover:bg-gray-800 dark:hover:bg-gray-200 text-white dark:text-gray-900"
                size="sm"
              >
                <LogIn className="size-3.5" />
                登录 / 注册
              </Button>
            )}
          </div>
        </SheetContent>
      </Sheet>

      {/* Edit Profile Dialog */}
      <EditProfile open={editProfileOpen} onOpenChange={setEditProfileOpen} />

      {/* Registration / Login Dialog */}
      <Dialog
        open={showLoginDialog}
        onOpenChange={(open) => {
          if (!open) resetDialog()
        }}
      >
        <DialogContent className="sm:max-w-md overflow-hidden p-0">
          <div className="px-6 pt-6 pb-0 shrink-0">
            <DialogHeader>
              <DialogTitle className="text-center text-lg text-gray-900 dark:text-gray-100">
                {getDialogTitle()}
              </DialogTitle>
              <DialogDescription className="text-center text-gray-500 dark:text-gray-400">
                {getDialogDesc()}
              </DialogDescription>
            </DialogHeader>
          </div>

          <div className="px-6 pb-6 relative min-h-[240px] max-h-[75vh] overflow-y-auto scrollbar-thin">
            <AnimatePresence mode="wait">
              {/* Login mode: password entry for existing user */}
              {dialogMode === 'login' ? (
                <motion.div
                  key="login"
                  variants={stepVariants}
                  initial="enter"
                  animate="center"
                  exit="exit"
                  transition={stepTransition}
                  className="space-y-4 pt-4"
                >
                  {/* Username display (read-only) */}
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-gray-50 dark:bg-gray-800/50 border border-gray-100 dark:border-gray-800">
                    <div className="size-9 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                      <User className="size-4 text-gray-500 dark:text-gray-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">
                        {username.trim()}
                      </p>
                      <p className="text-xs text-gray-400 dark:text-gray-500">已注册用户</p>
                    </div>
                    <Check className="size-4 text-green-500 shrink-0" />
                  </div>

                  {/* Password input */}
                  <div>
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block">
                      密码
                    </label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400 dark:text-gray-500" />
                      <Input
                        type={showPassword ? 'text' : 'password'}
                        placeholder="请输入密码"
                        value={password}
                        onChange={(e) => {
                          setPassword(e.target.value)
                          setPasswordError('')
                          setError('')
                        }}
                        onKeyDown={(e) => e.key === 'Enter' && !logging && handleLogin()}
                        autoFocus
                        className="pl-9 pr-10 h-11 text-base text-gray-900 dark:text-gray-100"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
                        tabIndex={-1}
                      >
                        {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                      </button>
                    </div>
                    <AnimatePresence>
                      {(passwordError || error) && (
                        <motion.p
                          initial={{ opacity: 0, y: -4 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -4 }}
                          className="text-xs text-red-500 mt-1.5 pl-1"
                        >
                          {passwordError || error}
                        </motion.p>
                      )}
                    </AnimatePresence>
                  </div>

                  {/* Login button */}
                  <Button
                    onClick={handleLogin}
                    disabled={logging || !password}
                    className="w-full bg-gray-900 dark:bg-gray-100 hover:bg-gray-800 dark:hover:bg-gray-200 text-white dark:text-gray-900 h-11"
                  >
                    {logging ? (
                      <>
                        <div className="size-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                        登录中...
                      </>
                    ) : (
                      <>
                        <LogIn className="size-4 mr-2" />
                        登录
                      </>
                    )}
                  </Button>

                  {/* Switch to register */}
                  <p className="text-center text-xs text-gray-400 dark:text-gray-500">
                    不是你？
                    <button
                      onClick={() => {
                        setDialogMode('register')
                        setRegStep(1)
                        setUsername('')
                        setPassword('')
                        setPasswordError('')
                        setError('')
                      }}
                      className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 ml-1 underline underline-offset-2"
                    >
                      注册新账号
                    </button>
                  </p>
                </motion.div>
              ) : regStep === 1 ? (
                /* Step 1: Username Entry */
                <motion.div
                  key="step1"
                  variants={stepVariants}
                  initial="enter"
                  animate="center"
                  exit="exit"
                  transition={stepTransition}
                  className="space-y-4 pt-4"
                >
                  <div>
                    <Input
                      placeholder="请输入用户名（2-20个字符）"
                      value={username}
                      onChange={(e) => {
                        setUsername(e.target.value)
                        setUsernameError('')
                      }}
                      onKeyDown={(e) => e.key === 'Enter' && !usernameChecking && handleCheckUsername()}
                      autoFocus
                      maxLength={20}
                      disabled={usernameChecking}
                      className="text-gray-900 dark:text-gray-100 h-11 text-base"
                    />
                    <AnimatePresence>
                      {usernameError && (
                        <motion.p
                          initial={{ opacity: 0, y: -4 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -4 }}
                          className="text-xs text-red-500 mt-1.5 pl-1"
                        >
                          {usernameError}
                        </motion.p>
                      )}
                    </AnimatePresence>
                    {username.length > 0 && !usernameError && (
                      <p className="text-xs text-gray-400 dark:text-gray-500 mt-1.5 pl-1">
                        支持中文、字母、数字和下划线
                      </p>
                    )}
                  </div>
                  <Button
                    onClick={handleCheckUsername}
                    disabled={usernameChecking || !username.trim()}
                    className="w-full bg-gray-900 dark:bg-gray-100 hover:bg-gray-800 dark:hover:bg-gray-200 text-white dark:text-gray-900 h-11"
                  >
                    {usernameChecking ? (
                      <>
                        <div className="size-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                        检查中...
                      </>
                    ) : (
                      '下一步'
                    )}
                  </Button>
                </motion.div>
              ) : regStep === 2 ? (
                /* Step 2: Avatar Selection */
                <motion.div
                  key="step2"
                  variants={stepVariants}
                  initial="enter"
                  animate="center"
                  exit="exit"
                  transition={stepTransition}
                  className="space-y-5 pt-4"
                >
                  {/* Preset Avatars Grid */}
                  <div>
                    <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3 flex items-center gap-1.5">
                      <Sparkles className="size-3.5" />
                      预设头像
                    </p>
                    <div className="grid grid-cols-4 gap-2.5">
                      {PRESET_AVATARS.map((preset) => (
                        <button
                          key={preset.id}
                          type="button"
                          onClick={() => {
                            setSelectedAvatarId(preset.id)
                            setSelectedAvatarUrl(preset.url)
                            setAvatarType('preset')
                          }}
                          className={cn(
                            'relative group rounded-xl p-1.5 transition-all duration-200',
                            'border-2',
                            selectedAvatarId === preset.id
                              ? 'border-gray-900 dark:border-gray-100 bg-gray-50 dark:bg-gray-800 shadow-sm'
                              : 'border-transparent hover:border-gray-200 dark:hover:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800/50'
                          )}
                        >
                          <div className="relative aspect-square">
                            <img
                              src={preset.url}
                              alt={preset.name}
                              className="w-full h-full rounded-lg object-cover"
                              loading="lazy"
                            />
                            {selectedAvatarId === preset.id && (
                              <motion.div
                                initial={{ scale: 0 }}
                                animate={{ scale: 1 }}
                                className="absolute inset-0 flex items-center justify-center bg-black/20 rounded-lg"
                              >
                                <div className="size-6 rounded-full bg-gray-900 dark:bg-gray-100 flex items-center justify-center">
                                  <Check className="size-3.5 text-white dark:text-gray-900" strokeWidth={3} />
                                </div>
                              </motion.div>
                            )}
                          </div>
                          <p className="text-[10px] text-gray-400 dark:text-gray-500 text-center mt-1 truncate">
                            {preset.name}
                          </p>
                        </button>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  {/* Custom Avatar Section */}
                  <div>
                    <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3 flex items-center gap-1.5">
                      <Sparkles className="size-3.5" />
                      自定义头像
                    </p>

                    {/* Color picker */}
                    <div className="flex items-center gap-2 flex-wrap">
                      {PRESET_COLORS.map((color) => (
                        <button
                          key={color.value}
                          type="button"
                          title={color.name}
                          onClick={() => {
                            setSelectedColor(color.value)
                            setAvatarType('generated')
                          }}
                          className={cn(
                            'size-8 rounded-full transition-all duration-200',
                            'hover:scale-110 focus:outline-none',
                            avatarType === 'generated' && selectedColor === color.value
                              ? 'ring-2 ring-offset-2 ring-gray-900 dark:ring-gray-100 ring-offset-white dark:ring-offset-gray-950 scale-110'
                              : 'ring-1 ring-black/10 dark:ring-white/10'
                          )}
                          style={{ backgroundColor: color.value }}
                        />
                      ))}
                      <button
                        type="button"
                        onClick={() => {
                          const newColor = generateRandomColor()
                          setSelectedColor(newColor)
                          setAvatarType('generated')
                        }}
                        className="size-8 rounded-full bg-gray-100 dark:bg-gray-800 border border-dashed border-gray-300 dark:border-gray-600 flex items-center justify-center hover:bg-gray-200 dark:hover:bg-gray-700 hover:scale-110 transition-all duration-200"
                        title="随机颜色"
                      >
                        <Shuffle className="size-3.5 text-gray-500 dark:text-gray-400" />
                      </button>
                    </div>

                    {/* Live preview for generated avatar */}
                    {avatarType === 'generated' && (
                      <motion.div
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="mt-3 flex items-center gap-3 p-3 rounded-lg bg-gray-50 dark:bg-gray-800/50 border border-gray-100 dark:border-gray-800"
                      >
                        <img
                          src={generateAvatarUrl(username.trim(), selectedColor)}
                          alt="自定义头像预览"
                          className="size-12 rounded-lg"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-medium text-gray-700 dark:text-gray-300">预览效果</p>
                          <p className="text-[11px] text-gray-400 dark:text-gray-500 mt-0.5 flex items-center gap-1">
                            <span
                              className="inline-block size-3 rounded-sm"
                              style={{ backgroundColor: selectedColor }}
                            />
                            {selectedColor}
                          </p>
                        </div>
                      </motion.div>
                    )}
                  </div>

                  {/* Action buttons */}
                  <div className="flex gap-3">
                    <Button
                      variant="outline"
                      onClick={() => {
                        setRegStep(1)
                        setError('')
                      }}
                      className="flex-1 h-11 text-gray-600 dark:text-gray-400 border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800"
                    >
                      <ArrowLeft className="size-3.5" />
                      返回
                    </Button>
                    <Button
                      onClick={() => {
                        setError('')
                        setPasswordError('')
                        setPassword('')
                        setConfirmPassword('')
                        setShowPassword(false)
                        setShowConfirmPassword(false)
                        setRegStep(3)
                      }}
                      className="flex-[2] bg-gray-900 dark:bg-gray-100 hover:bg-gray-800 dark:hover:bg-gray-200 text-white dark:text-gray-900 h-11"
                    >
                      下一步
                    </Button>
                  </div>
                </motion.div>
              ) : (
                /* Step 3: Set Password */
                <motion.div
                  key="step3"
                  variants={stepVariants}
                  initial="enter"
                  animate="center"
                  exit="exit"
                  transition={stepTransition}
                  className="space-y-4 pt-4"
                >
                  {/* Password input */}
                  <div>
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block flex items-center gap-1.5">
                      <KeyRound className="size-3.5" />
                      设置密码
                    </label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400 dark:text-gray-500" />
                      <Input
                        type={showPassword ? 'text' : 'password'}
                        placeholder="请设置密码（至少6个字符）"
                        value={password}
                        onChange={(e) => {
                          setPassword(e.target.value)
                          setPasswordError('')
                          setError('')
                        }}
                        autoFocus
                        maxLength={64}
                        className="pl-9 pr-10 h-11 text-base text-gray-900 dark:text-gray-100"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
                        tabIndex={-1}
                      >
                        {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Confirm password input */}
                  <div>
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5 block flex items-center gap-1.5">
                      <Lock className="size-3.5" />
                      确认密码
                    </label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400 dark:text-gray-500" />
                      <Input
                        type={showConfirmPassword ? 'text' : 'password'}
                        placeholder="请再次输入密码"
                        value={confirmPassword}
                        onChange={(e) => {
                          setConfirmPassword(e.target.value)
                          setPasswordError('')
                          setError('')
                        }}
                        onKeyDown={(e) => e.key === 'Enter' && !logging && handleCompleteRegistration()}
                        maxLength={64}
                        className="pl-9 pr-10 h-11 text-base text-gray-900 dark:text-gray-100"
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
                        tabIndex={-1}
                      >
                        {showConfirmPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                      </button>
                    </div>
                    {/* Password hints / errors */}
                    <AnimatePresence>
                      {passwordError ? (
                        <motion.p
                          initial={{ opacity: 0, y: -4 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -4 }}
                          className="text-xs text-red-500 mt-1.5 pl-1"
                        >
                          {passwordError}
                        </motion.p>
                      ) : password.length > 0 && confirmPassword.length > 0 && password === confirmPassword ? (
                        <motion.p
                          initial={{ opacity: 0, y: -4 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -4 }}
                          className="text-xs text-green-500 mt-1.5 pl-1 flex items-center gap-1"
                        >
                          <Check className="size-3" />
                          密码一致
                        </motion.p>
                      ) : null}
                    </AnimatePresence>
                    {password.length > 0 && password.length < 6 && (
                      <p className="text-xs text-amber-500 mt-1.5 pl-1">
                        密码至少需要6个字符
                      </p>
                    )}
                  </div>

                  {/* Error message */}
                  <AnimatePresence>
                    {error && (
                      <motion.p
                        initial={{ opacity: 0, y: -4 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -4 }}
                        className="text-xs text-red-500 pl-1"
                      >
                        {error}
                      </motion.p>
                    )}
                  </AnimatePresence>

                  {/* Action buttons */}
                  <div className="flex gap-3">
                    <Button
                      variant="outline"
                      onClick={() => {
                        setRegStep(2)
                        setError('')
                        setPasswordError('')
                      }}
                      className="flex-1 h-11 text-gray-600 dark:text-gray-400 border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800"
                    >
                      <ArrowLeft className="size-3.5" />
                      返回
                    </Button>
                    <Button
                      onClick={handleCompleteRegistration}
                      disabled={logging || !password || password.length < 6 || !confirmPassword}
                      className="flex-[2] bg-gray-900 dark:bg-gray-100 hover:bg-gray-800 dark:hover:bg-gray-200 text-white dark:text-gray-900 h-11"
                    >
                      {logging ? (
                        <>
                          <div className="size-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                          注册中...
                        </>
                      ) : (
                        <>
                          <Sparkles className="size-3.5 mr-2" />
                          完成注册
                        </>
                      )}
                    </Button>
                  </div>

                  {/* Password tips */}
                  <div className="p-3 rounded-lg bg-gray-50 dark:bg-gray-800/30 border border-gray-100 dark:border-gray-800">
                    <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">
                      💡 密码安全提示：请使用6个字符以上的密码，建议混合字母、数字和符号以提高安全性。
                    </p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
