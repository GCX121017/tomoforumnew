'use client'

import { useState, useEffect, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { toast } from 'sonner'
import {
  Users,
  UserPlus,
  Bell,
  MessageCircle,
  Trash2,
  Check,
  X,
  Loader2,
  Clock,
} from 'lucide-react'
import { useForumStore, type Friend, type FriendRequest as FriendRequestType } from '@/store/forum'
import { cn, formatTimeAgo, getLevelInfo } from '@/components/forum/helpers'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog'

type TabType = 'list' | 'add' | 'requests'

export default function FriendPanel() {
  const {
    showFriendsPanel,
    setShowFriendsPanel,
    currentUser,
    navigate,
  } = useForumStore()

  const [activeTab, setActiveTab] = useState<TabType>('list')

  // Tab 1: Friends list
  const [friends, setFriends] = useState<Friend[]>([])
  const [friendsLoading, setFriendsLoading] = useState(false)
  const [deletingId, setDeletingId] = useState<string | null>(null)

  // Tab 2: Add friend
  const [targetUsername, setTargetUsername] = useState('')
  const [requestMessage, setRequestMessage] = useState('')
  const [sendingRequest, setSendingRequest] = useState(false)

  // Tab 3: Friend requests
  const [requests, setRequests] = useState<FriendRequestType[]>([])
  const [requestsLoading, setRequestsLoading] = useState(false)
  const [actingRequestId, setActingRequestId] = useState<string | null>(null)

  const fetchFriends = useCallback(async () => {
    if (!currentUser) return
    setFriendsLoading(true)
    try {
      const res = await fetch(`/api/friends?userId=${currentUser.id}`)
      if (res.ok) {
        const data = await res.json()
        setFriends(data.friends || [])
      }
    } catch {
      // silent fail
    } finally {
      setFriendsLoading(false)
    }
  }, [currentUser])

  const fetchRequests = useCallback(async () => {
    if (!currentUser) return
    setRequestsLoading(true)
    try {
      const res = await fetch(`/api/friends/requests?userId=${currentUser.id}`)
      if (res.ok) {
        const data = await res.json()
        setRequests(data.requests || [])
      }
    } catch {
      // silent fail
    } finally {
      setRequestsLoading(false)
    }
  }, [currentUser])

  // Auto-refresh when dialog opens
  useEffect(() => {
    if (showFriendsPanel && currentUser) {
      fetchFriends()
      fetchRequests()
      // Reset tab to list
      setActiveTab('list')
    }
  }, [showFriendsPanel, currentUser, fetchFriends, fetchRequests])

  // Handlers
  const handleMessage = (friend: Friend) => {
    setShowFriendsPanel(false)
    navigate({ name: 'messages', partnerId: friend.id })
  }

  const handleDelete = async (friendshipId: string, username: string) => {
    if (!currentUser) return
    if (!window.confirm(`确定要删除好友「${username}」吗？`)) return
    setDeletingId(friendshipId)
    try {
      const res = await fetch(`/api/friends/${friendshipId}?userId=${currentUser.id}`, {
        method: 'DELETE',
      })
      if (res.ok) {
        setFriends((prev) => prev.filter((f) => f.friendshipId !== friendshipId))
        toast.success('已删除好友')
      } else {
        toast.error('删除失败，请重试')
      }
    } catch {
      toast.error('网络错误，请重试')
    } finally {
      setDeletingId(null)
    }
  }

  const handleSendRequest = async () => {
    if (!currentUser) return
    const trimmed = targetUsername.trim()
    if (!trimmed) {
      toast.error('请输入用户名')
      return
    }
    if (trimmed === currentUser.username) {
      toast.error('不能添加自己为好友')
      return
    }

    setSendingRequest(true)
    try {
      const body: Record<string, string> = {
        userId: currentUser.id,
        targetUsername: trimmed,
      }
      if (requestMessage.trim()) {
        body.message = requestMessage.trim()
      }
      const res = await fetch('/api/friends', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      })
      if (res.ok) {
        toast.success('好友申请已发送！')
        setTargetUsername('')
        setRequestMessage('')
      } else {
        const data = await res.json().catch(() => ({}))
        const msg = data.error || data.message || '发送失败，请重试'
        toast.error(msg)
      }
    } catch {
      toast.error('网络错误，请重试')
    } finally {
      setSendingRequest(false)
    }
  }

  const handleAccept = async (requestId: string) => {
    if (!currentUser) return
    setActingRequestId(requestId)
    try {
      const res = await fetch(`/api/friends/${requestId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id, action: 'accept' }),
      })
      if (res.ok) {
        setRequests((prev) => prev.filter((r) => r.id !== requestId))
        fetchFriends()
        toast.success('已接受好友申请')
      } else {
        toast.error('操作失败，请重试')
      }
    } catch {
      toast.error('网络错误，请重试')
    } finally {
      setActingRequestId(null)
    }
  }

  const handleReject = async (requestId: string) => {
    if (!currentUser) return
    setActingRequestId(requestId)
    try {
      const res = await fetch(`/api/friends/${requestId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id, action: 'reject' }),
      })
      if (res.ok) {
        setRequests((prev) => prev.filter((r) => r.id !== requestId))
      } else {
        toast.error('操作失败，请重试')
      }
    } catch {
      toast.error('网络错误，请重试')
    } finally {
      setActingRequestId(null)
    }
  }

  const pendingRequestCount = requests.length

  const tabs: { key: TabType; label: string; icon: React.ReactNode }[] = [
    { key: 'list', label: '好友列表', icon: <Users className="size-4" /> },
    { key: 'add', label: '添加好友', icon: <UserPlus className="size-4" /> },
    {
      key: 'requests',
      label: '好友申请',
      icon: <Bell className="size-4" />,
    },
  ]

  // Tab transition variants
  const tabVariants = {
    enter: { opacity: 0, x: 12 },
    center: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: -12 },
  }

  return (
    <Dialog open={showFriendsPanel} onOpenChange={setShowFriendsPanel}>
      <DialogContent className="sm:max-w-md overflow-hidden p-0 gap-0">
        {/* Header */}
        <DialogHeader className="px-6 pt-6 pb-4">
          <DialogTitle className="text-center text-lg font-semibold">
            好友
          </DialogTitle>
          <DialogDescription className="text-center text-gray-500 dark:text-gray-400">
            管理你的好友和好友申请
          </DialogDescription>
        </DialogHeader>

        {/* Tabs */}
        <div className="flex items-center gap-0 px-4 pb-0">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                'flex items-center justify-center gap-1.5 px-3 py-2.5 text-sm font-medium transition-colors relative border-b-2 flex-1',
                activeTab === tab.key
                  ? 'text-gray-900 dark:text-gray-100 border-gray-900 dark:border-gray-100'
                  : 'text-gray-500 dark:text-gray-400 border-transparent hover:text-gray-700 dark:hover:text-gray-300'
              )}
            >
              {tab.icon}
              {tab.label}
              {tab.key === 'requests' && pendingRequestCount > 0 && (
                <Badge
                  variant="destructive"
                  className="size-4 min-w-4 p-0 text-[10px] flex items-center justify-center rounded-full"
                >
                  {pendingRequestCount > 9 ? '9+' : pendingRequestCount}
                </Badge>
              )}
            </button>
          ))}
        </div>

        <Separator />

        {/* Tab Content */}
        <div className="relative min-h-[320px] max-h-[420px]">
          <AnimatePresence mode="wait">
            {activeTab === 'list' && (
              <motion.div
                key="list"
                variants={tabVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.15, ease: 'easeInOut' }}
                className="absolute inset-0"
              >
                {friendsLoading ? (
                  <div className="flex items-center justify-center h-full">
                    <Loader2 className="size-5 animate-spin text-gray-400" />
                  </div>
                ) : friends.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full gap-3 text-gray-400 dark:text-gray-500">
                    <UserPlus className="size-10 opacity-50" />
                    <p className="text-sm">还没有好友</p>
                    <button
                      onClick={() => setActiveTab('add')}
                      className="text-xs text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 transition-colors underline underline-offset-2"
                    >
                      去添加好友
                    </button>
                  </div>
                ) : (
                  <ScrollArea className="h-full max-h-[420px]">
                    <div className="px-4 py-3 space-y-1">
                      {friends.map((friend) => {
                        const levelInfo = getLevelInfo(friend.points)
                        return (
                          <motion.div
                            key={friend.friendshipId}
                            initial={{ opacity: 0, y: 4 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.15 }}
                            className="flex items-center gap-3 rounded-lg p-2.5 hover:bg-gray-50 dark:hover:bg-gray-800/60 transition-colors group"
                          >
                            {/* Online indicator + Avatar */}
                            <div className="relative shrink-0">
                              <Avatar className="size-9">
                                <AvatarImage
                                  src={friend.avatar}
                                  alt={friend.username}
                                />
                                <AvatarFallback className="text-xs bg-gray-100 dark:bg-gray-800">
                                  {friend.username.charAt(0).toUpperCase()}
                                </AvatarFallback>
                              </Avatar>
                              <span
                                className={cn(
                                  'absolute -bottom-0.5 -right-0.5 size-3 rounded-full border-2 border-white dark:border-gray-900',
                                  friend.online
                                    ? 'bg-emerald-500'
                                    : 'bg-gray-300 dark:bg-gray-600'
                                )}
                              />
                            </div>

                            {/* User info */}
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-1.5">
                                <span className="text-sm font-medium truncate">
                                  {friend.username}
                                </span>
                                <span className="text-xs shrink-0" title={levelInfo.name}>
                                  {levelInfo.icon}
                                </span>
                              </div>
                              <p className="text-[11px] text-gray-400 dark:text-gray-500">
                                {friend.online ? '在线' : '离线'}
                              </p>
                            </div>

                            {/* Actions */}
                            <div className="flex items-center gap-1 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="size-8 p-0 text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100"
                                onClick={() => handleMessage(friend)}
                                title="发消息"
                              >
                                <MessageCircle className="size-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="size-8 p-0 text-gray-400 dark:text-gray-500 hover:text-red-600 dark:hover:text-red-400"
                                onClick={() =>
                                  handleDelete(friend.friendshipId, friend.username)
                                }
                                disabled={deletingId === friend.friendshipId}
                                title="删除好友"
                              >
                                {deletingId === friend.friendshipId ? (
                                  <Loader2 className="size-3.5 animate-spin" />
                                ) : (
                                  <Trash2 className="size-3.5" />
                                )}
                              </Button>
                            </div>
                          </motion.div>
                        )
                      })}
                    </div>
                  </ScrollArea>
                )}
              </motion.div>
            )}

            {activeTab === 'add' && (
              <motion.div
                key="add"
                variants={tabVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.15, ease: 'easeInOut' }}
                className="absolute inset-0"
              >
                <div className="px-6 py-5 space-y-4">
                  {/* Username input */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-gray-500 dark:text-gray-400">
                      用户名
                    </label>
                    <Input
                      placeholder="输入要添加的用户名"
                      value={targetUsername}
                      onChange={(e) => setTargetUsername(e.target.value)}
                      className="text-sm"
                      maxLength={20}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !sendingRequest) {
                          handleSendRequest()
                        }
                      }}
                    />
                  </div>

                  {/* Optional message */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-gray-500 dark:text-gray-400">
                      附言（可选）
                    </label>
                    <Textarea
                      placeholder="写一段简短的介绍..."
                      value={requestMessage}
                      onChange={(e) => {
                        if (e.target.value.length <= 100) {
                          setRequestMessage(e.target.value)
                        }
                      }}
                      className="text-sm resize-none"
                      rows={3}
                      maxLength={100}
                    />
                    <p className="text-[11px] text-gray-400 dark:text-gray-500 text-right">
                      {requestMessage.length}/100
                    </p>
                  </div>

                  {/* Submit */}
                  <Button
                    onClick={handleSendRequest}
                    className="w-full bg-gray-900 hover:bg-gray-800 text-sm"
                    disabled={sendingRequest || !targetUsername.trim()}
                  >
                    {sendingRequest ? (
                      <>
                        <Loader2 className="size-3.5 animate-spin mr-1.5" />
                        发送中...
                      </>
                    ) : (
                      <>
                        <UserPlus className="size-3.5 mr-1.5" />
                        发送申请
                      </>
                    )}
                  </Button>
                </div>
              </motion.div>
            )}

            {activeTab === 'requests' && (
              <motion.div
                key="requests"
                variants={tabVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.15, ease: 'easeInOut' }}
                className="absolute inset-0"
              >
                {requestsLoading ? (
                  <div className="flex items-center justify-center h-full">
                    <Loader2 className="size-5 animate-spin text-gray-400" />
                  </div>
                ) : requests.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full gap-3 text-gray-400 dark:text-gray-500">
                    <Bell className="size-10 opacity-50" />
                    <p className="text-sm">暂无好友申请</p>
                  </div>
                ) : (
                  <ScrollArea className="h-full max-h-[420px]">
                    <div className="px-4 py-3 space-y-2">
                      {requests.map((request) => {
                        const levelInfo = getLevelInfo(request.fromUser.points)
                        return (
                          <motion.div
                            key={request.id}
                            initial={{ opacity: 0, y: 4 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.15 }}
                            className="rounded-lg border border-gray-100 dark:border-gray-800 p-3 space-y-2.5"
                          >
                            {/* User info row */}
                            <div className="flex items-start gap-3">
                              <Avatar className="size-9 shrink-0">
                                <AvatarImage
                                  src={request.fromUser.avatar}
                                  alt={request.fromUser.username}
                                />
                                <AvatarFallback className="text-xs bg-gray-100 dark:bg-gray-800">
                                  {request.fromUser.username.charAt(0).toUpperCase()}
                                </AvatarFallback>
                              </Avatar>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-1.5">
                                  <span className="text-sm font-medium truncate">
                                    {request.fromUser.username}
                                  </span>
                                  <span className="text-xs shrink-0" title={levelInfo.name}>
                                    {levelInfo.icon}
                                  </span>
                                </div>
                                {request.fromUser.bio && (
                                  <p className="text-xs text-gray-400 dark:text-gray-500 truncate mt-0.5">
                                    {request.fromUser.bio}
                                  </p>
                                )}
                                <div className="flex items-center gap-1 mt-1 text-[11px] text-gray-400 dark:text-gray-500">
                                  <Clock className="size-3" />
                                  {formatTimeAgo(request.createdAt)}
                                </div>
                              </div>
                            </div>

                            {/* Request message */}
                            {request.message && (
                              <div className="ml-12 pl-3 border-l-2 border-gray-200 dark:border-gray-700">
                                <p className="text-xs text-gray-500 dark:text-gray-400 italic">
                                  &ldquo;{request.message}&rdquo;
                                </p>
                              </div>
                            )}

                            {/* Action buttons */}
                            <div className="flex items-center gap-2 ml-12">
                              <Button
                                size="sm"
                                className="h-7 px-3 text-xs bg-emerald-600 hover:bg-emerald-700 text-white"
                                onClick={() => handleAccept(request.id)}
                                disabled={actingRequestId === request.id}
                              >
                                {actingRequestId === request.id ? (
                                  <Loader2 className="size-3 animate-spin" />
                                ) : (
                                  <Check className="size-3 mr-1" />
                                )}
                                接受
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="h-7 px-3 text-xs text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
                                onClick={() => handleReject(request.id)}
                                disabled={actingRequestId === request.id}
                              >
                                {actingRequestId === request.id ? (
                                  <Loader2 className="size-3 animate-spin" />
                                ) : (
                                  <X className="size-3 mr-1" />
                                )}
                                拒绝
                              </Button>
                            </div>
                          </motion.div>
                        )
                      })}
                    </div>
                  </ScrollArea>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </DialogContent>
    </Dialog>
  )
}
