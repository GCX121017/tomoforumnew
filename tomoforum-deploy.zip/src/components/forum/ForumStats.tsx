'use client'

import { useEffect, useState } from 'react'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { Skeleton } from '@/components/ui/skeleton'
import { Separator } from '@/components/ui/separator'
import { Trophy, FileText, MessageSquare, Users } from 'lucide-react'
import { cn } from '@/components/forum/helpers'
import { useForumStore } from '@/store/forum'

interface AuthorStats {
  id: string
  username: string
  avatar: string
  postCount: number
}

interface Stats {
  totalPosts: number
  totalComments: number
  totalUsers: number
}

export default function ForumStats() {
  const { navigate } = useForumStore()
  const [stats, setStats] = useState<Stats>({ totalPosts: 0, totalComments: 0, totalUsers: 0 })
  const [topAuthors, setTopAuthors] = useState<AuthorStats[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch('/api/posts?limit=100&sort=latest')
        if (res.ok) {
          const data = await res.json()
          const posts = data.posts || []

          const authorMap = new Map<string, { username: string; avatar: string; count: number }>()
          let totalComments = 0
          const userSet = new Set<string>()

          posts.forEach((post: {
            authorId: string
            author?: { username: string; avatar: string }
            commentCount?: number
          }) => {
            if (post.authorId && post.author) {
              userSet.add(post.authorId)
              const existing = authorMap.get(post.authorId)
              if (existing) {
                existing.count++
              } else {
                authorMap.set(post.authorId, {
                  username: post.author.username,
                  avatar: post.author.avatar,
                  count: 1,
                })
              }
            }
            totalComments += post.commentCount || 0
          })

          const sorted = Array.from(authorMap.entries())
            .sort((a, b) => b[1].count - a[1].count)
            .slice(0, 3)
            .map(([id, info]) => ({
              id,
              username: info.username,
              avatar: info.avatar,
              postCount: info.count,
            }))

          setStats({
            totalPosts: data.total || posts.length,
            totalComments,
            totalUsers: userSet.size,
          })
          setTopAuthors(sorted)
        }
      } catch { /* ignore */ }
      setLoading(false)
    }

    fetchData()
  }, [])

  const statItems = [
    { icon: FileText, label: '帖子', value: stats.totalPosts },
    { icon: MessageSquare, label: '评论', value: stats.totalComments },
    { icon: Users, label: '用户', value: stats.totalUsers },
  ]

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="rounded-lg bg-gray-50 dark:bg-gray-800/50 p-3 space-y-3">
          <Skeleton className="h-3 w-16" />
          <div className="flex gap-2">
            <Skeleton className="h-12 flex-1" />
            <Skeleton className="h-12 flex-1" />
            <Skeleton className="h-12 flex-1" />
          </div>
        </div>
        <Skeleton className="h-32 rounded-lg" />
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* Community Stats */}
      <div className="rounded-lg bg-gray-50 dark:bg-gray-800/50 p-3">
        <h3 className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-3">
          社区统计
        </h3>
        <div className="grid grid-cols-3 gap-2">
          {statItems.map((item) => (
            <div
              key={item.label}
              className="text-center p-2 rounded-md bg-white dark:bg-gray-900"
            >
              <item.icon className="size-4 mx-auto text-gray-400 dark:text-gray-500 mb-1" />
              <p className="text-sm font-bold text-gray-800 dark:text-gray-100">{item.value}</p>
              <p className="text-[10px] text-gray-400 dark:text-gray-500">{item.label}</p>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      {/* Active Leaderboard */}
      {topAuthors.length > 0 && (
        <div>
          <h3 className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-3 flex items-center gap-1.5">
            <Trophy className="size-3.5" />
            活跃排行
          </h3>
          <div className="space-y-1.5">
            {topAuthors.map((author, index) => (
              <button
                key={author.id}
                onClick={() => navigate({ name: 'user', userId: author.id })}
                className="flex items-center gap-2.5 w-full px-2 py-1.5 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
              >
                <span className={cn(
                  'size-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0',
                  index === 0 ? 'bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900' :
                  index === 1 ? 'bg-gray-400 text-white dark:bg-gray-600 dark:text-white' :
                  'bg-gray-200 text-gray-600 dark:bg-gray-700 dark:text-gray-300'
                )}>
                  {index + 1}
                </span>
                <Avatar className="size-6">
                  <AvatarImage src={author.avatar} alt={author.username} />
                  <AvatarFallback className="text-[10px] bg-gray-100 dark:bg-gray-800">
                    {author.username.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <span className="text-sm text-gray-700 dark:text-gray-300 truncate flex-1 text-left">
                  {author.username}
                </span>
                <span className="text-xs text-gray-400 dark:text-gray-500">{author.postCount} 篇</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
